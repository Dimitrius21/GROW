import java.util.ArrayList;

/* 
1. Создать объект класса Текст, используя классы Предложение, Слово. 
Методы: дополнить текст, вывести на консоль текст, заголовок текста.
*/

public class Text {
 String title;    
 ArrayList<Sentence> sentences;
 ArrayList<Word> words;

 Text(String title){
     this.title = title;
     sentences = new ArrayList<Sentence>();
     words =  new ArrayList<Word>();
 }
 Text(String title, Sentence st){
    this.title = title;
    words =  new ArrayList<Word>();
    sentences = new ArrayList<Sentence>();
    sentences.add(st);
}
Text(String title, String str){
    this.title = title;
    words =  new ArrayList<Word>();
    sentences = new ArrayList<Sentence>();
    Sentence st = new Sentence(str);
    sentences.add(st);
}
 public void add(Sentence st){
    sentences.add(st);
 }
 public void add(Word w){
    words.add(w);
 }
 public void printTitle(){
     System.out.println("Заголовок - "+title);
 }
 public void printText(){
    for (Sentence st : sentences){
        System.out.println(st.getSentence());
    }
    for (Word w : words){
        System.out.print(w.getWord()+" ");
    }
}
public static void main(String[] args) {
    Text tx = new Text("Example", "Hello");
    String str = "This class has been writed by Java";
    Sentence st = new Sentence(str);
    tx.add(st);
    str = "Exercise 4.2.1";
    st = new Sentence(str);
    tx.add(st);
    Word wd = new Word("By");
    tx.add(wd);

    tx.printTitle();
    tx.printText();
}
}

class Sentence{
    String sentence;
    Sentence(String st){
        sentence = new String(st);
    }
    public void setSentence(String st){
        sentence = new String(st);
    }
    public String getSentence(){
        return sentence;
    }
}
class Word{
    String word;
    Word(String st){
        word = new String(st);
    }
    public void setWord(String st){
        word = new String(st);
    }
    public String getWord(){
        return word;
    }
}