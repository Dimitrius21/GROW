/* 9. Создать класс Book, спецификация которого приведена ниже. Определить конструкторы, set- и get- методы и метод toString(). 
Создать второй класс, агрегирующий массив типа Book, с подходящими конструкторами и методами. 
Задать критерии выбора данных и вывести эти данные на консоль.
Book: id, название, автор(ы), издательство, год издания, количество страниц, цена, тип переплета.
Найти и вывести:
a) список книг заданного автора;
b) список книг, выпущенных заданным издательством;
c) список книг, выпущенных после заданного года.
*/

import java.util.ArrayList;
import java.util.*;

public class BookList {
    private ArrayList<Book> bList;
    public BookList(){
        bList= new ArrayList<Book>();                   // Конструктор с пустым списком
    }
    public BookList(Book bk){                           // Конструктор с одной книгой
        bList= new ArrayList<Book>();
        bList.add(bk);
    }
    public BookList(ArrayList<Book> bks){                   // Конструктор с входным списком
        bList= new ArrayList<Book>();
        bList.addAll(bks);
    }
    public BookList(Book[] bks){                            // Конструктор с входным списком ввиде массива
        bList= new ArrayList<Book>();
        bList.addAll(Arrays.asList(bks));
    }
    public void addBook(Book bk){                           // Добавить книгу
        bList.add(bk);
    }

    public ArrayList<Book> getBooksByAuthor(String st){    //Поиск книг по автору
        ArrayList<Book> list = new ArrayList<Book>();        
        for (Book b : bList){
            if (b.getAuthor().compareToIgnoreCase(st)==0){
                list.add(b);
            }
        }
        return list;
    }
    public ArrayList<Book> getBooksByPublisher(String st){   // Поиск книг по издательству
        ArrayList<Book> list = new ArrayList<Book>();        
        for (Book b : bList){
            if (b.getPublisher().compareToIgnoreCase(st)==0){
                list.add(b);
            }
        }
        return list;
    }
    public ArrayList<Book> getBooksAfteryear(int year){         // Поиск книг выданных после указанного года
        ArrayList<Book> list = new ArrayList<Book>();        
        for (Book b : bList){
            if (b.getPublishYear() > year){
                list.add(b);
            }
        }
        return list;
    }
    public void printAllBooks(){                   //вывести список всех книг  
        for (Book b : bList){       
         System.out.println(b);         
        }
    }
    public void printBooks(ArrayList<Book> bks){   //вывести переданный список книг        
        for (Book b : bks){       
         System.out.println(b.toString());         
        }
    }
    public String Input() {
        Scanner sc = new Scanner(System.in);
        return sc.nextLine();
    }

    public void f1(){                     // интерфейсная функция зад.1
        ArrayList<Book> list=null;
        String st="";     
        System.out.println("Введите имя автора, список книг которого хотите получить");
        System.out.print("? - ");
        st=Input();                 //В консоли windows при чтении на русском, возвращается пустая строка((  !!
        //System.out.println(st);        
        st="Михаил Булгаков";
        list = getBooksByAuthor(st);        
        if (list.size()==0) System.out.println("Книг автора "+st+" не найдено");
         else printBooks(list);
    }
    public void f2(){                     // интерфейсная функция зад.2
        ArrayList<Book> list;
        String st;
        System.out.println("Введите название издательства, список книг которого хотите получить");
        System.out.print("? - ");        
        st=Input();                         //В консоли windows при чтении на русском, возвращается пустая строка((  !!
        //System.out.println(st);        
        st="Азбука";
        list = getBooksByPublisher(st);
        if (list.size()==0) System.out.println("Книг издательства "+st+" не найдено");
        else printBooks(list);
    }
    public void f3(Scanner sc){                 // интерфейсная функция зад.3
        ArrayList<Book> list;
        int year;
        System.out.println("Введите год, список книг выпущенных после которого хотите получить");
        System.out.print("? - ");
        year=sc.nextInt();
        sc.nextLine();
        list = getBooksAfteryear(year); 
        if (list.size()==0) System.out.println("Книг изданных после "+year+" не найдено");
        else printBooks(list);
    }
    public static void main(String[] args) {        
        Book[] bk = new Book[4];
        bk[0] = new Book(1, "Война и мир т.1-2", "Лев Толстой", "Азбука", "твердый", 2014, 700, 7.60);
        bk[1] = new Book(2, "Война и мир т.3-4", "Лев Толстой", "Азбука", "твердый", 2014, 710, 7.60);
        bk[2] = new Book(3, "Анна Каренина", "Лев Толстой", "Эксмо", "твердый", 2021, 600, 6.60);
        bk[3] = new Book(4, "Мастер и маргарита", "Михаил Булгаков", "Азбука", "твердый", 2012, 480, 9.44);
        BookList bl = new BookList(bk);
        bl.go();
    }
    public void go(){
        Scanner sc = new Scanner(System.in);        
        int choise;
        addBook(new Book(5, "Собачье сердце", "Михаил Булгаков", "Азбука", 8.50));
        while (true){
            System.out.println("Выберите (введите номер) действия, которое хотите выполнить:");
            System.out.println("1 - вывести список книг заданного автора");
            System.out.println("2 - вывести список книг, выпущенных заданным издательством;");
            System.out.println("3 - вывести список книг, выпущенных после заданного года");
            System.out.println("4 - показать все книги");
            System.out.println("5 - выход из программы");
            System.out.print("? : ");
            choise=sc.nextInt();
            sc.nextLine();
            switch (choise) {
                case 1 : f1(); break;
                case 2 : f2(); break;
                case 3 : f3(sc); break;
                case 4 : printAllBooks(); break;
                case 5 : sc.close(); System.exit(0);
            }
        }        
    }
}
