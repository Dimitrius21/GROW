/*10. Создать класс Airline, спецификация которого приведена ниже. Определить конструкторы, set- и get- методы и метод toString().
 Создать второй класс, агрегирующий массив типа Airline, с подходящими конструкторами и методами. 
 Задать критерии выбора данных и вывести эти данные на консоль.
 Airline: пункт назначения, номер рейса, тип самолета, время вылета, дни недели.
 Найти и вывести:
  a) список рейсов для заданного пункта назначения;
  b) список рейсов для заданного дня недели;
  c) список рейсов для заданного дня недели, время вылета для которых больше заданного.
*/
import java.util.*;


public class Flights{
    ArrayList<Airline> fList;

    Flights(){
        fList=new ArrayList<Airline>();
    }
    Flights(Airline pl){
        fList=new ArrayList<Airline>();
        fList.add(pl);
    }
    Flights(ArrayList<Airline> pls){
        fList=new ArrayList<Airline>();
        fList=pls;        
    }
    Flights(Airline[] pls){
        fList=new ArrayList<Airline>();
        fList.addAll(Arrays.asList(pls));        
    }

    public void findFlightByDestination(String dest){    // Поиск полетов по пункту назначения
        int i=0;
        for (Airline item : fList){
            if (dest.compareTo(item.getDestination())==0){
                System.out.println(item.toString());
                i++;
            }
        }
        if (i==0) System.out.println("Рейсов не найдено");
    }
    public void findFlightByDay(int day){                   // Поиск полетов по дню вылета
        char d;
        if (day<1 || day>7) {
            System.out.println("Веденный день вне диапазона 1-7");
            return;
        } 
        int i=0;
        for (Airline item : fList){
            d=item.getFlightDays()[day-1];
            if (d!='-') {
                System.out.println(item.toString()); 
                i++;
            }          
        }
        if (i==0) System.out.println("Рейсов не найдено");
    }
    public void findFlightByDayTime(int day, String time){      //Поиск полетов по дню вылета после указанного времени
        char d;
        int t=Airline.transformTime(time);
        if (t<0) { return; }        
        if (day<1 || day>7) {
            System.out.println("Введенный день вне диапазона 1-7");
            return;
        }       
        int i=0; 
        for (Airline item : fList){
            d=item.getFlightDays()[day-1];
            if (d!='-') {
                if (Airline.transformTime(item.getFlightTime()) >=t) {
                     System.out.println(item.toString());            
                     i++;
                    }
            }
        }
        if (i==0) System.out.println("Рейсов не найдено");
    }
    public void  add(Airline pl){                 // Добавить полет в список
        fList.add(pl);
    }
    public void showAllFlights(){                   // Вывести все полеты
        for (Airline pl : fList){
            System.out.println(pl.toString());
        }
    }
    public void f1(Scanner sc){                     // интерфейсная функция зад.1        
        String st="";     
        System.out.println("Введите название пукта назначения, список в который хотите получить");
        System.out.print("? - ");
        st=sc.nextLine().trim();
        System.out.println(st);                
        findFlightByDestination(st);
    }
    public void f2(Scanner sc){                     // интерфейсная функция зад.2
        int day;        
        System.out.println("Введите день недели (от 1-пнд до 7-вскр) список полетов на который хотите получить");
        System.out.print("? - ");                
        day=sc.nextInt();
        sc.nextLine();
        findFlightByDay(day);        
    }
    public void f3(Scanner sc){                 // интерфейсная функция зад.3
        int day;        
        String time;
        System.out.println("Введите день недели (от 1-пнд до 7-вскр) список полетов на который хотите получить");
        System.out.print("? - ");                
        day=sc.nextInt();
        sc.nextLine();        
        System.out.println("Введите время в формате час:минуты, список полетов после которого хотите получить");
        System.out.print("? - ");                
        time = sc.nextLine().trim();
        findFlightByDayTime(day, time);
    }

    public static void main(String[] args) {
        char[] d= {'1','2','-','4','5','-','7'};
        Airline[] pl = new Airline[3];
        pl[0] = new Airline(35, "Paris", "Boeing737-800", "08:30", d);
        //System.out.println(pl[0]);
        pl[1] = new Airline(69, "London", "Boeing737-800", 10,30, 1,3,5);
        //System.out.println(pl[1]);
        pl[2] = new Airline(55, "Madrid", "Airbus-A210", 9,25, 1,3,5,6);
        Flights f = new Flights(pl);
        f.go();
    }
    public void go(){
        Scanner sc = new Scanner(System.in);
        int choise;
        Airline pl = new Airline(38, "Paris", "Boeing737-800", 15,30, 1,5);
        add(pl);
        while (true){
            System.out.println("Выберите (введите номер), какое действие хотите выполнить:");
            System.out.println("1 -список рейсов для заданного пункта назначения");
            System.out.println("2 - список рейсов для заданного дня недели");
            System.out.println("3 - список рейсов для заданного дня недели, время вылета для которых больше заданного");
            System.out.println("4 - показать все рейсы");
            System.out.println("5 - выход из программы");
            System.out.print("? : ");
            choise=sc.nextInt();
            sc.nextLine();
            switch (choise) {
                case 1 : f1(sc); break;
                case 2 : f2(sc); break;
                case 3 : f3(sc); break;
                case 4 : showAllFlights(); break;
                case 5 :  System.exit(0) ; break;
            }
        }
    }
}