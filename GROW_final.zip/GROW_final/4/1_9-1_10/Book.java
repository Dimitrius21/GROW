/* 9. Создать класс Book, спецификация которого приведена ниже. Определить конструкторы, set- и get- методы и метод toString().
Book: id, название, автор(ы), издательство, год издания, количество страниц, цена, тип переплета.
*/
public class Book {
    private int id;
    private String name, author, publisher, binding;
    private int publishYear, pageQt; 
    private double price;
    //полный конструктор
    Book(int id, String name, String author, String publisher, String binding, int publishYear, int pageQt, double price){
        this.id=id;
        this.name=name;
        this.author=author;
        this.publisher = publisher;
        this.binding = binding;
        this.publishYear=publishYear;
        this.pageQt=pageQt;
        this.price=price;
    }
    //сокращенный конструктор
    Book(int id, String name, String author, String publisher, double price){
        this.id=id;
        this.name=name;
        this.author=author;
        this.publisher = publisher;    
        this.price=price;
        this.publishYear=0;
        this.pageQt=0;
    }

    public void setName(String st){
        this.name=st;
    }
    public void setAuthor(String st){
        this.author=st;
    }
    public void setPublisher(String st){
        this.publisher=st;
    }
    public void setBinding(String st){
        this.binding=st;
    }
    public void setPublishYear(int year){
        this.publishYear=year;
    }
    public void setPageQt(int qt){
        this.pageQt=qt;
    }
    public void setPrise(double price){
        this.price=price;
    }

    public String getName(){
        return name;
    }
    public String getAuthor(){
        return author;
    }
    public String getPublisher(){
        return publisher;
    }
    public String getBinding(){
        return binding;
    }
    public int getPublishYear(){
        return publishYear;
    }
    public int getPageQt(){
        return pageQt;
    }
    public double getPrice(){
        return price;
    }    

    public String toString(){
        return "Книга \""+name+",\" автор : "+author+". Цена : "+price+" руб. "+"Издательство - "+ publisher;
    }
}
