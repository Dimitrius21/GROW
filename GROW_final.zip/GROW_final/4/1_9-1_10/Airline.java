/*
Создать класс Airline, спецификация которого приведена ниже. Определить конструкторы, set- и get- методы и метод toString().
Airline: пункт назначения, номер рейса, тип самолета, время вылета, дни недели.
*/

public class Airline {
 private String dest;
 private int number;
 private String type;
 private int time;
 private char[] days = {'-','-','-','-','-','-','-'};

 Airline(int num, String dest, String type, String time, char[] days){
     int t;
     this.number = num;
     this.dest = dest;
     this.type = type;  
     t=transformTime(time);
     if ( t<0) this.time = 0;
      else this.time=t;
     this.days = days;     
 } 
 Airline(int num, String dest, String type, int hour,int min, int ...d){
    this.number = num;
    this.dest = dest;
    this.type = type;   
    if (hour<0 || hour>23) hour=0;
    if (min<0 || min>59) min=0;
    this.time=hour*60+min;
    int j;    
    for(int i=0; i<d.length; i++){
        j=d[i];
        if (j>0 && j<8) {
            this.days[j-1]=Integer.valueOf(j).toString().charAt(0);
        }
    }    
 }
 public static int transformTime(String time){    
    int h, m;
    String[] st=time.split(":");
    try {
        h=Integer.parseInt(st[0]);
        m=Integer.parseInt(st[1]);
    } catch (Exception e) {
        System.out.println("Неправильно введено время. Формат час:мин.");
        return -1;
    }
    if ((h<0 || h>23)||(m<0 || m>59)) {
        System.out.println("Неправильно введено время.");
        return -1;
    }
    return h*60+m;
 }

 public void setDestination(String dest){
    this.dest = dest;
 }
 public void setFlightNum(int num){
    this.number = num;
 }
 public void setTyFlightDays(char[] days){
    this.days = days;
 }
 public void setFlightTime(String time){     
    int t=transformTime(time);
    if ( t<0) this.time = 0;
     else this.time=t;    
 }

 public void setPlaneType(String type){
    this.type = type;  
 }

 public String getDestination(){
     return dest;
 }
 public String getFlightTime(){
    int h,m;
    h= (int) time/60;
    m = time%60;
    return String.format("%02d:%02d", h,m);
 }
 public int getFlightNum(){
    return number;
 }
 public char[] getFlightDays(){
    return days;
 }

public String toString(){
    String str, st= new String(days);
    str=getFlightTime();
    return String.format("Рейс № %d в %s, время вылета %s. Дни недели %s. Самолет %s", number, dest,str, st,type);
}
/*
public static void main(String[] args) {
    char[] d= {'1','2','-','4','5','-','7'};
    Airline pl1 = new Airline(35, "Paris", "Boeng737-800", "08:30", d);
    System.out.println(pl1);
    Airline pl2 = new Airline(69, "London", "Boeng737-800", 10,30, 1,3,5);
    System.out.println(pl2);
}*/
    
}
