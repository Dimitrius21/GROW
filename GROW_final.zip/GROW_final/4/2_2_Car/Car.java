// Создать объект класса Автомобиль, используя классы Колесо, Двигатель. 
// Методы: ехать, заправляться, менять колесо, вывести на консоль марку автомобиля.

public class Car {
    String mark;
    String model;
    int fuelQt;
   // Wheel wheels;
    Motor engine;
    Wheel[] wheels = new Wheel[4];
    Car(String mark, String model ){
        this.mark=mark;
        this.model=model;
        engine = new Motor(150, 4);
        fuelQt=0;
        for (int i=0; i<4; i++){
            wheels[i] = new Wheel("Michelin", "215x70");
        }
    }
    public String getMark(){                                    //вывести на консоль марку автомобиля.
        return mark+" "+model;
    }
    public void chargeFuel(int vol){                            //заправляться
        engine.Off();
        fuelQt+=vol;
        System.out.println("Fuel volume is "+fuelQt+"l");       
    }
    public void drive(){                                        //ехать
        if (fuelQt==0) { System.out.println("Tank is empty (("); return; }
        engine.On();
        System.out.println("Driving");
    }
    public void replaceWheel(int i, Wheel wheel){               //менять колесо
        if (i>=1 && i<=4) {
            wheels[i-1]=null;
            wheels[i-1]=wheel;
        }
    }
    public static void main(String[] args) {
        Car car = new Car("Peugeot", "3008");
        car.chargeFuel(30);
        car.drive();
    }
}




