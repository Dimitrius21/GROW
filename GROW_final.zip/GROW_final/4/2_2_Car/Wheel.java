public class Wheel {
    String model;
    String size;
    Wheel(String model, String size){
        this.size=size;
        this.model=model;
    }
}
