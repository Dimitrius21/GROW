public class Motor {
    private int power;
    private boolean working=false;
    private int cylinders;    
    Motor(int power, int cylQt){
        this.power=power;
        this.cylinders=cylQt;
    }
    public void On() {              //Запустить двигатель
        working=true;
    }
    public void Off() {             // Выключить двигатель
        working=false;
    }    
    public int getMotorPower() {
        return power;
    }    
    public boolean isMotorWork() {      
        return working;
    }
    public int getCylQt() {
        return cylinders;
    }    
}