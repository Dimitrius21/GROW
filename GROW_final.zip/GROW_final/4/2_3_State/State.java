/*
3. Создать объект класса Государство, используя классы Область, Район, Город. 
Методы: вывести на консоль столицу, количество областей, площадь, областные центры.
*/
import java.util.ArrayList;

public class State {
    private String capital;
    private String name;
    private ArrayList<Region> regions = new ArrayList<Region>();
    private ArrayList<City> cities = new ArrayList<City>();

    State(String name, String capital){
        this.name=name;
        this.capital=capital;
    }  
    State(String name, String capital, ArrayList<Region> reg, ArrayList<City> ct){
        this.name=name;
        this.capital=capital;
        cities.addAll(ct);
        regions.addAll(reg);
    } 

    public String getCapital(){
        return capital;
    }    
    public void addCiti(City ct){
        cities.add(ct);
    }
    public void addRegion(Region rg){
        regions.add(rg);
    }
    public void addRegion(ArrayList<Region> rg){
        regions.addAll(rg);
    }

    public void printCapital(){
        System.out.println("Столица государства: "+ capital);
    }
    public void printArea() {
        double sum=0;
        for (Region reg : regions) sum+=reg.getArea();
        for (City ct : cities) sum+=ct.getArea();
        System.out.println("Площадь государства: "+sum);
    }
    public void printRegionCenter() {    
        System.out.println("\nОбластные центры: ");
        for (Region reg : regions) System.out.print(reg.getCenter()+", ");
    }
    public void printQtOfRegion(){
        System.out.println("Количество областей: "+regions.size());
    }
    public static void main(String[] args) {
        State ct = new State("Country", "Bigcity");
        City st = new City("Bigcity", 400, 1000000);
        ct.addCiti(st);
        Region rg = new Region("Reg1", 5000, 900000, "City1");
        ct.addRegion(rg);
        rg = new Region("Reg2", 8000, 2000000, "City2");
        ct.addRegion(rg);
        rg = new Region("Reg3", 6000, 1500000, "City3");
        ct.addRegion(rg);
        ct.printCapital();
        ct.printArea();
        ct.printQtOfRegion();
        ct.printRegionCenter();
    }
}
