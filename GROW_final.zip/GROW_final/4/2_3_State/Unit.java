// Базовый класс
public class Unit {
    protected String name;
    protected double area;
    protected int population; 

    public Unit(String name, double area, int qt){
        this.name = name;
        this.area=area;
        this.population=qt;
    }
    public double getArea(){
        return area;
    }
    public int getPopulation(){
        return population;
    }            
}
