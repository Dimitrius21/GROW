import java.util.*;

public class Region extends Unit{
    ArrayList<District> districts = new ArrayList<District>();
    
    private String center;
    public Region(String name, double area, int qt, String center){
        super(name, area, qt);
        this.center=center;
    }

    public String getCenter(){
        return center;
    }

    public void addDistrict(District ds){
        districts.add(ds);
    }
    public void addDistrict(ArrayList<District> ds){
        districts.addAll(ds);
    }

}
