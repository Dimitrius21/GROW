public class City extends Unit{
    
    public City(String name, double area, int qt){
        super(name, area, qt);        
    }

}
