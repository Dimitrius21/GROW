import java.util.*;

public class District extends Unit{

    private String center;
    private ArrayList<City> cities = new ArrayList<City>();

    public District(String name, double area, int qt, String center){
        super(name, area, qt);
        this.center=center;
    }
    public void addCiti(City ct){
        cities.add(ct);
    }
    public String getCenter(){
        return center;
    }
}
