public class Account {
    private boolean blocked = false;
    private long acNumber;
    private double balance;
    private double creditLimit;

    Account(long number, double limit) {
        this.acNumber= number;
        balance = 0;
        this.creditLimit = limit;
    }
    public long getNumber(){
        return acNumber;
    }
    public double getBalance(){
        return balance;
    }
    public void addBalance(double sum){
        balance+=sum;
    }
    public boolean subBalance(double sum){
        double check=balance-sum;
        if ((check < (0-creditLimit)) || blocked) return false; 
        balance-=sum;
        return true;
    }
    public void balanceBlocked(){
        blocked = true;
    }
    public void balanceUnBlocked(){
        blocked = false;
    }    
}
