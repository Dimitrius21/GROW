import java.util.ArrayList;

public class Client {
    private String name;
    private double balance;
    ArrayList<Account> accounts = new ArrayList<Account>();
    
    Client(String name, Account ac){
        this.name=name;
        accounts.add(ac);
    }
    public void addAccount(Account ac){          // Добывить клиенту счет
        accounts.add(ac);
    }

    public boolean getBalance(long num){          // Проверяет номер счета и если существует, возвращает его баланс
        for (Account ac : accounts){
            if (num == ac.getNumber()) {
                balance=ac.getBalance();
                return true;
            }            
        }
        return false;
    }

    public double totalSum(){               // сумма по всем счетам 
        double sum=0;
        for (Account ac : accounts) sum+=ac.getBalance();  
        return sum;
    }
    public double totalPosAc(){             // сумма по счетам с положительным балансом
        double s, sum=0;
        for (Account ac : accounts) {
            s=ac.getBalance();        
            if ( s >= 0) sum+=s;        
        } 
        return sum;
    }
    public double totalNegAc(){             // сумма по счетам с отрицатеьным балансом
        double s, sum=0;
        for (Account ac : accounts) {
            s=ac.getBalance();
            if (s < 0) sum+=s;        
        } 
        return sum;
    }

    public void sortAccounts(){                         // сортировка счетов по возрастанию номеров
        Account ac;
        int l = accounts.size();
        for (int i=0; i<l; i++){
            for (int j=0; j<l-i-1; j++){
                if (accounts.get(j).getNumber() > accounts.get(j+1).getNumber()){
                    ac=accounts.get(j);                     
                    accounts.set(j, accounts.get(j+1)); 
                    accounts.set(j+1,ac);                    
                }
            }
        }
    }

    public void showAccounts(){                             //вывод информации по всем счетам
        Account ac;
        int l=accounts.size();
        for (int i=0; i<l; i++){
            ac=accounts.get(i);
            System.out.printf("Счет %10s имеет баланс %.2f %n", ac.getNumber(), ac.getBalance());
        }    
    }

    public static void main(String[] args) {
        Account ac = new Account (305, 0);
        ac.addBalance(200);
        Client cl1 = new Client("Ivanov", ac);
        cl1.go();
    }

    public void go(){
        Account ac = new Account (210, 0);
        ac.addBalance(300);
        addAccount(ac);
        ac = new Account (1010, 100);
        ac.subBalance(50);
        addAccount(ac);
        ac = new Account (301, 300);
        ac.subBalance(150);
        addAccount(ac);   

        showAccounts();
        System.out.println("Суммарный баланс по счетам = "+totalSum());
        System.out.println("Суммарный баланс по положительным счетам = "+totalPosAc());
        System.out.println("Суммарный баланс по отрицательным счетам = "+totalNegAc());        
        sortAccounts();
        showAccounts();

    }

}
