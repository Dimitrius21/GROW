import java.util.ArrayList;
import java.util.Scanner;

public class Choise {
    static Scanner sc = new Scanner(System.in);
    public static void showTours(ArrayList<Tour> trs){
        for (Tour t : trs){
            System.out.println(t.toString());
        }
    }
    public static void main(String[] args) {

        ArrayList<Tour> trs;
        int choise, choiseTr, choiseFd, choiseD, choiseS, s, l;
        char[] type = {'a', 'e', 'r', 't','s','b'};
        Tours t = Tours.createTours();
        while (true){
            choise=choiseType();                                                //определяем тип выбираемых путевок
            if (choise<0 || choise>6) continue; 
            if (choise==6) {sc.close(); System.exit(0);} 
            choiseD=choiseDays();                                               // определяем длительность поездки
            choiseTr=choiseTransport();                                         // определяем тип транспорта
            choiseFd=choiseFood();                                              // определяем тип питания
            trs=t.getSelectedTours(type[choise]);   //выбираем путевки по типу
            s=choiseD+choiseFd+choiseTr;            //определяем, есть ли дополнительный параметры выбора путевок, 0 - нету
            if (s!=0) {            
                if (choiseFd>0 && choiseFd<5) trs=t.getChosenFood(trs, choiseFd);       //доп. выбор по типу питания
                if (choiseD>0 && choiseD<4) trs=t.getChosenDay(trs, choiseD);           //доп. выбор по длительности
                if (choiseTr>0 && choiseD<4) trs=t.getChosenTransport(trs, choiseTr);   //доп. выбор по типу транспорта
             }          
            l=trs.size();      
            if (l==0) System.out.println("Путевок соответствующих заданным условиям не найдено");
             else {   
                 choiseS=choiseSort();                                  // выбрать способ сортировки
                 switch (choiseS) {
                     case 1: costSort(trs, 0, l-1); break;
                     case 2: daysSort(trs, 0, l-1); break;                 
                 }                  
                 showTours(trs);                                            // вывести итоговый список
                }
            System.out.println("Нажмите Ввод для продолжения");
            sc.nextLine();
        }    
    }    

        public static int choiseType(){
            int i;
            System.out.println("Выберете тип путевки, введите соответствующий номер:");
            System.out.println("0 - все");
            System.out.println("1 - экскурсии");
            System.out.println("2 - отдых");        
            System.out.println("3 - лечение");
            System.out.println("4 - морской круиз");
            System.out.println("5 - шоппинг");
            System.out.println("6 - выйти из программы");
            System.out.print("? -");
            i=sc.nextInt();
            sc.nextLine();
            return i;
        }
        public static int choiseTransport(){
            int i;
            System.out.println("Выберете тип транспорта, введите соответствующий номер (для морского круиза вариант доставки до порта отплытия и обратно):");
            System.out.println("0 - любой");
            System.out.println("1 - автобус");
            System.out.println("2 - самолет");        
            System.out.println("3 - самостоятельно");
            System.out.print("? -");
            i=sc.nextInt();
            sc.nextLine();
            return i;
        }
        public static int choiseFood(){
            int i;
            System.out.println("Выберете тип питания:");
            System.out.println("0 - любой");
            System.out.println("1 - завтраки");
            System.out.println("2 - завтрак+ужин");        
            System.out.println("3 - 3-х разовое");
            System.out.println("4 - все включено");
            System.out.print("? -");
            i=sc.nextInt();
            sc.nextLine();
            return i;
        }
        public static int choiseDays(){
            int i;
            System.out.println("Выберете длительность поездки, дней:");
            System.out.println("0 - все");
            System.out.println("1 - меньше 8 дней");
            System.out.println("2 - 8-14 дней");        
            System.out.println("3 - больше 14 дней");        
            System.out.print("? -");
            i=sc.nextInt();
            sc.nextLine();
            return i;
        }    
        public static int choiseSort(){
            int i;
            System.out.println("Выберете способ сортировки:");
            System.out.println("0 - без сортировки");        
            System.out.println("1 - сортировать по цене");
            System.out.println("2 - сортировать по длительности+цена");    
            System.out.print("? -");
            i=sc.nextInt();
            sc.nextLine();
            return i;
        } 

        public static void costSort(ArrayList<Tour> trs, int start, int end){               //Сортировка по стоимости
            Tour tr;        
            int l=end-start;
            for (int i=0; i<l; i++){
                for (int j=start; j<end-i; j++){
                    if(trs.get(j).getCost()>trs.get(j+1).getCost()){
                        tr=trs.get(j+1);
                        trs.set(j+1, trs.get(j));
                        trs.set(j,tr); 
                    }                    
                }
            }
        }
        public static void daysSort(ArrayList<Tour> trs, int start, int end){            //Сортировка по длительности
            Tour tr;            
            int l=end-start;
            int s,e;
            for (int i=0; i<l; i++){
                for (int j=start; j<end-i; j++){
                    if(trs.get(j).getDuration()>trs.get(j+1).getDuration()){
                        tr=trs.get(j+1);
                        trs.set(j+1, trs.get(j));
                        trs.set(j,tr); 
                    }                    
                }
            }                                                                                //закончили сортировку по длительности
            int d=trs.get(start).getDuration();
            s=start;
            boolean pr=false;
            for(int i=start+1; i<=end; i++){                                                 //Дополнительная сортировка по цене
                if (trs.get(i).getDuration()==d){
                    pr=true;                    
                }
                else {
                    if (pr){
                        e=i-1;
                        pr=false;
                        costSort(trs, s, e);                        
                    }
                    s=i;
                    d=trs.get(i).getDuration();
                }
            }     
        }

}
