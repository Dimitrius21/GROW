import java.util.ArrayList;

public class Tours {
    private ArrayList<Tour> tours;
    Tours(){
        tours = new ArrayList<Tour>();
    }    
    Tours(ArrayList<Tour> ts){
        tours = new ArrayList<Tour>();
        tours.addAll(ts);
    }
    public void add(Tour tr){                                           //добавить тур
        tours.add(tr);
    }
    public void add(ArrayList<Tour> trs){                               //добавить несколько туров
        tours.addAll(trs);
    }
    public static Tours createTours(){                                  // создаем список путевок
        Tour tr;
        Tours trs = new Tours();
        tr = new Tour(Tour.TourType.EXCURSION, Tour.FoodType.BR, 7, Tour.TrType.BUS, 400);
        trs.add(tr);
        tr = new Tour(Tour.TourType.EXCURSION, Tour.FoodType.BR, 10, Tour.TrType.BUS, 550);
        trs.add(tr);
        tr = new Tour(Tour.TourType.EXCURSION, Tour.FoodType.BR, 6, Tour.TrType.PLANE, 990);
        trs.add(tr);
        tr = new Tour(Tour.TourType.EXCURSION, Tour.FoodType.BR_DN, 6, Tour.TrType.PLANE, 1100);
        trs.add(tr);
        tr = new Tour(Tour.TourType.EXCURSION, Tour.FoodType.BR_DN, 7, Tour.TrType.BUS, 490);
        trs.add(tr);
        
        tr = new Tour(Tour.TourType.REST, Tour.FoodType.BR, 10, Tour.TrType.BUS, 650);
        trs.add(tr);
        tr = new Tour(Tour.TourType.REST, Tour.FoodType.BR_DN, 10, Tour.TrType.BUS, 750);
        trs.add(tr);
        tr = new Tour(Tour.TourType.REST, Tour.FoodType.BR_DN, 14, Tour.TrType.BUS, 999);        
        trs.add(tr);
        tr = new Tour(Tour.TourType.REST, Tour.FoodType.BR_DN, 10, Tour.TrType.PLANE, 850 );        
        trs.add(tr);
        tr = new Tour(Tour.TourType.REST, Tour.FoodType.ALL_INCL, 10, Tour.TrType.PLANE, 980);        
        trs.add(tr);
        tr = new Tour(Tour.TourType.REST, Tour.FoodType.ALL_INCL, 14, Tour.TrType.PLANE, 1200);        
        trs.add(tr);

        tr = new Tour(Tour.TourType.TREATMENT, Tour.FoodType.BR_DN, 14, Tour.TrType.BUS, 1200);
        trs.add(tr);
        tr = new Tour(Tour.TourType.TREATMENT, Tour.FoodType.BR_DN, 21, Tour.TrType.BUS, 1400);
        trs.add(tr);

        tr = new Tour(Tour.TourType.SEA_CRUISE, Tour.FoodType.ALL_INCL, 14, Tour.TrType.BUS, 950);
        trs.add(tr);
        tr = new Tour(Tour.TourType.SEA_CRUISE, Tour.FoodType.ALL_INCL, 10, Tour.TrType.PLANE, 1300);
        trs.add(tr);
        tr = new Tour(Tour.TourType.SEA_CRUISE, Tour.FoodType.ALL_INCL, 9, Tour.TrType.SELF, 880);
        trs.add(tr);
        
        return trs;
    }
    public ArrayList<Tour> getSelectedTours(char c){
       // ArrayList<Tour> trs = new ArrayList<Tour>();
        switch (c) {
            case 'a' : return tours;
            case 'e' : return getExcursion();
            case 't' : return getTreatment();
            case 'r' : return getRest();
            case 's' : return getSeaCruise();
            case 'b' : return getShopping();
        }
        return null;
    }

    public ArrayList<Tour> getExcursion(){                                  //Выбор экскурсионных путевок
        ArrayList<Tour> trs = new ArrayList<Tour>();
        for (Tour t : tours) {
            if (t.getType().compareTo(Tour.TourType.EXCURSION)==0) {
                trs.add(t);
            }
        }
        return trs;
    }
    public ArrayList<Tour> getTreatment(){                                       //Выбор путевок с лечением
        ArrayList<Tour> trs = new ArrayList<Tour>();
        for (Tour t : tours) {
            if (t.getType().compareTo(Tour.TourType.TREATMENT)==0) {
                trs.add(t);
            }
        }
        return trs;
    }
    public ArrayList<Tour> getRest(){                                            //Выбор путевок одыха
        ArrayList<Tour> trs = new ArrayList<Tour>();
        for (Tour t : tours) {
            if (t.getType().compareTo(Tour.TourType.REST)==0) {
                trs.add(t);
            }
        }
        return trs;
    }
    public ArrayList<Tour> getSeaCruise(){                                          //Выбор путевок с морским круизом
        ArrayList<Tour> trs = new ArrayList<Tour>();
        for (Tour t : tours) {
            if (t.getType().compareTo(Tour.TourType.SEA_CRUISE)==0) {
                trs.add(t);
            }
        }
        return trs;
    }
    public ArrayList<Tour> getShopping(){                                           //выбор путевок на закупки
        ArrayList<Tour> trs = new ArrayList<Tour>();
        for (Tour t : tours) {
            if (t.getType().compareTo(Tour.TourType.SHOPPING)==0) {
                trs.add(t);
            }
        }
        return trs;
    }
    public ArrayList<Tour> getChosenFood(ArrayList<Tour> tourList, int ch ){    //Выбор путевок по типу питания
        ArrayList<Tour> trs = new ArrayList<Tour>();
        String[] fds = {"BR", "BR_DN", "T3", "ALL_INCL"}; 
            for (Tour t : tourList) {
                if (t.getFood().compareTo(fds[ch-1])==0) {
                    trs.add(t);
                }
            }
        return trs;            
    }
    public ArrayList<Tour> getChosenTransport(ArrayList<Tour> tourList, int ch ){    //Выбор путевок по типу транспорта
        ArrayList<Tour> trs = new ArrayList<Tour>();
        String[] transport = {"BUS", "PLANE", "SELF"};         
            for (Tour t : tourList) {
                if (t.getTrasnsport().compareTo(transport[ch-1])==0) {
                    trs.add(t);
                }
            }
        return trs;            
    }
    public ArrayList<Tour> getChosenDay(ArrayList<Tour> tourList, int ch ){      //Выбор путвок по длительности
        ArrayList<Tour> trs = new ArrayList<Tour>();
        int[][] days = {{0,7}, {8,14}, {15, 10000}};         
            for (Tour t : tourList) {
                int d=t.getDuration();
                if (d>=days[ch-1][0] && d<=days[ch-1][1]) {
                    trs.add(t);
                }
            }
        return trs;            
    }
}
