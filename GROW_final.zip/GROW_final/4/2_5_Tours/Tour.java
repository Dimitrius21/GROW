public class Tour {
    public static enum TourType {REST, TREATMENT, SHOPPING, EXCURSION, SEA_CRUISE};
    public static enum TrType {PLANE, BUS, RW, SELF, VESSEL};
    public static enum FoodType {BR, BR_DN, T3, ALL_INCL};    
    //static final String[] TR_TYPE = {"plane", "bus","rw","self", "vessel"};
    //static final String[] FOOD_TYPE ={"breakfast", "breakfast+dinner", "3 times", "all incl"};
    //static final String[] TOUR_TYPE = {"rest", "treatment", "shopping", "excursions", "sea cruise"};
    private TourType type;
    private int days;
    private int cost;
    private String food;
    private String transport;

    Tour(TourType type, FoodType food, int days, TrType trt, int cost){
        this.type=type;
        this.days=days;
        this.food=food.name();
        this.transport=trt.name();
        this.cost=cost;
    }
    public TourType getType(){
        return type;
    }
    public String getFood(){
        return food;
    }
    public String getTrasnsport(){
        return transport;
    }
    public int getDuration(){
        return days;
    }
    public int getCost(){
        return cost;
    }
    public String toString(){
      return String.format("Вид - %s, длительность, дней - %d, стоимость - %d, тип транспорт - %s, тип питания - %s", type.name(), days, cost, transport, food);      
    }
}
