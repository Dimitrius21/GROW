/*
2. Создйте класс Test2 двумя переменными. Добавьте конструктор с входными параметрами. 
Добавьте конструктор, инициализирующий члены класса по умолчанию. Добавьте set- и get- методы для полей экземпляра класса.
*/
public class Test2 {
    private int A;
    private int B;
    Test2(){
        A=5;
        B=55;
    };
    Test2(int A, int B){
        this.A=A;
        this.B=B;
    }

    public void setA(int A){
        this.A=A;
    }
    public void setB(int B){
        this.B=B;
    }    
    public int getA(){
        return A;
    }
    public int getB(){
        return B;
    }
    public static void main(String[] args){
        Test2 t = new Test2();
        System.out.println(t.getA());
        System.out.println(t.getB());        
    }
}
