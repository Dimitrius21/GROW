/* 6. Составьте описание класса для представления времени. 
Предусмотрте возможности установки времени и изменения его отдельных полей (час, минута, секунда) с проверкой допустимости вводимых значений. 
В случае недопустимых значений полей поле устанавливается в значение 0. Создать методы изменения времени на заданное количество часов, минут и секунд.*/

public class MyTime {
    int hour;
    int minute;
    int sec;
    MyTime(int h, int m, int s){
        setTime(h,m,s);
    }

    public void setTime(int h, int m, int s){
        setHour(h);
        setMin(m);
        setSec(s);         
    }
    public void setHour(int h){
        if (h<0 && h>23) hour=0;
        else hour=h;
    }
    public void setMin(int m){
        if (m<0 && m>59) minute=0;
        else minute=m;
    }
    public void setSec(int s){
        if (s<0 && s>59) s=0;
        else sec=s;  
    }
    public void addSec(int s){
        int t=timeSec();
        t=t+s;
        if (t<=0) setTime(0, 0, 0);
         else convert(t);
    }
    public void addMin(int m){
        int t=timeSec();
        t=t+m*60;
        if (t<=0) setTime(0, 0, 0);
         else convert(t);    
    }
    public void addHour(int h){        
        int t=timeSec();
        t=t+h*3600;
        if (t<=0) setTime(0, 0, 0);
         else convert(t);
    }
    public void convert(int t){                 // преобразовать общее кол секунд в h:m:s и присвоить соответсвующим полям
        hour= (int) t/3600;        
        t=t-hour*3600;  
        if (hour>23) hour=hour%24;
        minute=(int) t/60;
        sec=t%60;             
    }

    public int timeSec(){                       // перевести уствновленное время в количесвто секунд
        return hour*3600+minute*60+sec;
    }

    public String getTime(){                    // вернуть строку установленного времени в формате час:минуты:секунды
        return String.format("%02d:%02d:%02d", hour, minute, sec);        
    }


    public static void main(String[] args) {
        MyTime time = new MyTime(5, 8, 15);
        time.addSec(3662);
        System.out.println(time.getTime());
    }
    
}
