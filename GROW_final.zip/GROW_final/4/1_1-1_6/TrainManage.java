import java.util.Scanner;

/* 4. Создайте класс Train, содержащий поля: название пункта назначения, номер поезда, время отправления. 
Создайте данные в массив из пяти элементов типа Train, добавьте возможность сортировки элементов массива 
по номерам поездов.
Добавьте возможность вывода информации о поезде, номер которого введен пользователем.
Добавьте возможность сортировки массив по пункту назначения, 
причем поезда с одинаковыми пунктами назначения должны быть упорядочены по времени отправления.
*/
public class TrainManage{
    Train[] trains;
    public static void main(String[] args){
        TrainManage tm = new TrainManage();
        tm.go();
    }
    public void go(){
        trains = new Train[6];
        trains[0]=new Train(35, "Брест",7,50);
        trains[1]=new Train(15, "Могилев", 14, 30);
        trains[2]=new Train(93, "Гомель", 12,20);
        trains[3]=new Train(62, "Могилев", 11, 45);
        trains[4]=new Train(74, "Гродно", 7,40);
        trains[5]=new Train(46, "Брест",6,40);
        
        showInfByNumber();
        System.out.println("\nСортировка по номеру поезда");
        sortByNumber();
        showAllTrains();
        System.out.println("\nСортировка по станции назначения");
        sortByDest();
        showAllTrains();
    }
    public void showAllTrains(){                        // Вывод списка всех поездов
        for(Train i : trains ){
            System.out.println(i.getInfo());            
        }
    }    

    public void showInfByNumber(){                          //Поиск поезда по номеру
        Scanner sc = new Scanner(System.in);
        boolean pr = true;
        System.out.print("Введите номер поезда : ");
        int num = sc.nextInt();
        for(Train i : trains ){
            if (i.getTrainNumber()==num){
                System.out.println(i.getInfo());
                pr=false; break;
            }
        }
        if (pr) System.out.println("Поезд с таким номером не существует");
        sc.close();
    }
    public void sortByNumber(){                 // Сортировка по станции номеру поезда  
        Train tr;        
        int l=trains.length;
        for (int i=0; i<l;i++){   
            for(int j=0; j<l-i-1; j++){
                if(trains[j].getTrainNumber()>
                trains[j+1].getTrainNumber()){
                    tr = trains[j];
                    trains[j]=trains[j+1];
                    trains[j+1]=tr;
                }
            }
        }        
    }
    public void sortByDest(){                       // Сортировка по станции назначния
        Train tr;   
        int pr = 0;
        int start=0, end=0;
        boolean pr1=false;
        int c;
        int l=trains.length;
        for (int i=0; i<l;i++){
            for(int j=0; j<l-i-1; j++){
                c=trains[j].getDest().compareTo(trains[j+1].getDest());                
                if(c>0){
                    tr = trains[j];
                    trains[j]=trains[j+1];
                    trains[j+1]=tr;
                } else if (c==0){pr++;}                
            }
        }
        if (pr==0) return;               // Если есть совпадения по станции назначения, дальнейшая сортировка по времени
        for (int i=0; i<l-1;i++){
            if (trains[i].getDest().compareTo(trains[i+1].getDest())==0) {
                if (!pr1) { start=i; pr1=true;}
                end=i+1;
            } else {
                if (pr1) { pr1=false; sortByTime(start, end);}
                }         
        }
        if (pr1) { pr1=false; sortByTime(start, end);}
    }
    public void sortByTime(int start, int end){        //сортировка по времени отправления
        Train tr;
        for (int i=start; i<end;i++){
            for(int j=start; j<end-(i-start); j++){                
                if(trains[j].getTimeDep().compareTo(trains[j+1].getTimeDep())>0){
                    tr = trains[j];
                    trains[j]=trains[j+1];
                    trains[j+1]=tr;
                }              
            }
        }
    }

}

class Train {
    String destination;
    int trainNumber;
    int hourD;
    int minD;
    
    Train(int num, String dest, int hour, int min){
        this.trainNumber=num;
        this.destination=dest;
        if (hour <0 || hour>23) {
            this.hourD=0; 
            System.out.println("Ошибка задания часа отправления. Установлено 00");
        } else this.hourD=hour;
        if (min <0 || min>59) {
            this.minD=0; 
            System.out.println("Ошибка задания минуты отправления. Установлено 00");
        } else this.minD=min;  
    }
    public String getInfo(){        
        return "Поезд №"+trainNumber+", концевая станция : "+destination+", время отправления : "+hourD+":"+minD;
    }
    public int getTrainNumber(){
        return trainNumber;
    }
    public String getDest(){
        return destination;
    }
    public String getTimeDep(){
        return hourD+"."+minD;
    }
}
