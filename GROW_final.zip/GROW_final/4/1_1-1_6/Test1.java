/*
1. Создайте класс Test1 двумя переменными. Добавьте метод вывода на экран и методы изменения этих переменных. 
Добавьте метод, который находит сумму значений этих переменных, и метод, который находит наибольшее значение из этих двух переменных.
*/
public class Test1 {
    private int A;
    private int B;
    public void setA(int A){
        this.A=A;
    }
    public void setB(int B){
        this.B=B;
    }
    public void print(){
     System.out.println("A="+A);
     System.out.println("B="+B);
    } 
    public long sum(){
        return A+B;
    }
    public void max(){        
        if (A==B) System.out.println("Значения равны");           
         else if (A>B) System.out.println("Наибольшее значение имеет переменная А : "+A);
               else System.out.println("Наибольшее значение имеет переменная B : "+B); 
    }
    public static void main(String[] args){
        Test1 t = new Test1();
        t.setA(50);
        t.setB(68);
        t.print();
        long s=t.sum();
        System.out.println("Сумма переменных ="+s);
        t.max();
    }

}
