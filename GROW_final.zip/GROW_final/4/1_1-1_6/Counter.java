/*5. Опишите класс, реализующий десятичный счетчик, который может увеличивать или уменьшать свое значение на единицу в заданном диапазоне. 
Предусмотрите инициализацию счетчика значениями по умолчанию и произвольными значениями. 
Счетчик имеет методы увеличения и уменьшения состояния, и метод позволяющее получить его текущее состояние. 
Написать код, демонстрирующий все возможности класса.
*/
class Counter {
    private int pos, min, max;
    Counter(){
        min=0;
        max=10;
        pos=0;
    }
    Counter(int pos, int min, int max){
        this.min=min;
        this.max=max;
        this.pos=pos;
    };
    public void Increment(){
        if (pos<max) pos++;
    }
    public void Decrement(){
        if (pos>min)pos--;
    }
    public int getValue(){
        return pos;
    }
    public static void main(String[] args) {
        Counter counter = new Counter (5,0,20);
        System.out.println("Значение счетчика равно : "+counter.getValue());
        counter.Increment();
        System.out.println("Значение счетчика равно : "+counter.getValue());
        counter.Decrement();
        System.out.println("Значение счетчика равно : "+counter.getValue());        
    }
}