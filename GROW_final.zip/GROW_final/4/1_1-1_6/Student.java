/*
3. Создайте класс с именем Student, содержащий поля: фамилия и инициалы, номер группы, успеваемость (массив из пяти элементов). 
Создайте массив из десяти элементов такого типа. Добавьте возможность вывода фамилий и номеров групп студентов, имеющих оценки, равные только 9 или 10.
*/
public class Student {
    String FIO;
    int groupNum;
    int[] marks = new int[5];
    public String getStudent(){
        return FIO;
    }
    public int getGroup(){
        return groupNum ;
    }
    public int[] getMArks(){
        return marks;
    }

    public static void main(String[] args) {
        Student[] students = new Student[10];
        
        System.out.println("Студенты имеющие оценки 9 и 10 :");
            for(int i=0; i<10; i++){
                if ( students[i] == null) continue;
                int sum=0, j=0;
                int[] marksOfStudent=students[i].getMArks();
                for (int k : marksOfStudent) { 
                    if (k!=0) { sum+=k; j++;}
                }    
                if (sum>=9*j) {
                    System.out.print(students[i].getStudent()+" группа - "+ students[i].getGroup());
                }
            }
        
    }
}
