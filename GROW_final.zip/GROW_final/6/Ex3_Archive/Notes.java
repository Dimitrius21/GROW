import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Calendar;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
//import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Notes {
    private static final String NOTESFILE="noteslist.txt";                                  //имя файла, где хранится список имеющихся Дел студентов
    private static String[] list={"surname","name","birthday","faculty","course","address"}; // список узлов xml файла, где сохраняется информация о студенте       
    private ArrayList<StudentNote> notes;                                                   //массив(список) всех Дел студентов
    Notes(){
        String str;
        String[] items;
        StudentNote studentNote;
        notes= new ArrayList<StudentNote>();
        File file = new File(NOTESFILE);
        if (file.exists()) {
         try {
          BufferedReader br = new BufferedReader(new FileReader(file));
          while ((str=br.readLine())!=null){                                    //читаем из файла и формируем список Дел студентов
            items=str.split(";");
            studentNote = new StudentNote(items[0], items[1]);
            notes.add(studentNote);
          }
          br.close();
         } catch (Exception e) {
            e.printStackTrace();        
         }                
        }        
    }

    public ArrayList<StudentNote> getList() {
        return notes;
    }
    //Получить список всех записей о студентах которые можно редактировать
    public ArrayList<String> getStudentList() {
        ArrayList<String> students = new ArrayList<String>();
        for( StudentNote note : notes ){             
            if (!(note.getUsing().contains("d") || note.getUsing().contains("m"))) students.add(note.getName()); 
        } 
        return students;
    }
    //Найти Дело (запись о студенте/студентах) по фамилии 
    public ArrayList<String> searchByName(String name){
        ArrayList<String> findedStudents = new ArrayList<String>();        
        for(StudentNote note : notes ){
           if (note.getName().toLowerCase().contains(name.toLowerCase()) && !note.getUsing().contains("d")   ) findedStudents.add(note.getName());
        }              
        return findedStudents;
    }
    //Получить имя файла по имени студента
    public String getStudentFileName(String name){        
        for(StudentNote note : notes ){
           if (note.getName().toLowerCase().contains(name.toLowerCase()))  return note.getFileName();
        }              
        return "";
    }

    //найти в Списке дело студента, которое будет редактироваться/удаляться и пометить его соответствующим образом. Вернуть ссылку на данное "Дело"
    public synchronized StudentNote markNote(String name,  String m) {
        String mark;
        for(StudentNote noteIt : notes ){
            if (noteIt.getName().toLowerCase().contains(name.toLowerCase())) {
                mark=noteIt.getUsing();
                if (mark.compareTo("e")==0){      
                    noteIt.setUsing(m);                    
                    return noteIt;
                }
                return null;
            } 
        }   
        return null;       
    }

    //Сохранить в файл список Дел
    public synchronized boolean saveNotesList() {
        //String fileName=file.getName();        
        String[] partFileName=NOTESFILE.split("\\.");              
        File fileTemp = new File(partFileName[0]+".tmp");                               //Формируем имя временного файла
        File file =new File(NOTESFILE);
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(fileTemp));    
            for( StudentNote note : notes){                                             // Сохраняем измененный список Дел во временном файле
                String noteName=note.getName()+";"+note.getFileName()+"\n";
                bw.write(noteName);       
            }
            bw.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        file.delete();                                              // Удаляем файл с первоначальным списком
        if (fileTemp.renameTo(file)) return true;                   // Переименовываем временный файл        
        return false;        
    }

    // Добавить запись описания(Дела) студента в список
    public synchronized boolean saveNote(String noteStr, String fileName){        
        String[] items=noteStr.split(";");
        String noteName=items[0]+"."+items[1].charAt(0)+" - "+items[3];         //Формируем имя студента для записи Дело 
        StudentNote sn = new StudentNote(noteName, fileName);                   //Создаем новую запись о Деле 
        notes.add(sn);                                                          //Добавляем новую запись в список Дел
        noteName=noteName+";"+fileName+"\n";                                    //Подготавливаем строку файла со списком Дел 
        try {
            BufferedWriter wr = new BufferedWriter(new FileWriter(NOTESFILE, true));
            wr.write(noteName);                                                 //Дописываем в конец файла подговленную строку
            wr.close();
            return true;
        } catch (Exception e) {            
            e.printStackTrace();
            return false;
        }
    }
    // Записать информацию о студенте в файл на диск. Возвращаем имя файла, где сохранена информация
    public String saveData(String noteStr) {        
        long name= Calendar.getInstance().getTimeInMillis();

        String fileName="f"+name+".xml";
        String[] item=noteStr.split(";");
        String st;
        try {
            BufferedWriter wr = new BufferedWriter(new FileWriter(fileName));
            wr.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
            wr.write("<student>\n");
            for(int i=0; i<list.length; i++){
                st="<"+list[i]+">%s</"+list[i]+">";
                wr.write(String.format(st, item[i]));    
            }
            wr.write("</student>");
            wr.close();
            return fileName;
        } catch (Exception e) {            
            e.printStackTrace();
            return "";
        }      
    }
    // Прочитать Дело(данные о студенте) из файла
    public synchronized String loadData(String fileName) {    

        return readXML(fileName);
    }
    //Чтение xml файла и формирование строки с информацией
    public String readXML(String fileName) {
        StringBuilder str = new StringBuilder();        
            try {
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder = factory.newDocumentBuilder();            
                Document document = builder.parse(new File(fileName));              //Создаем DOM по информации из xml файла
                for(int i=0; i<list.length; i++){
                    NodeList nodelist = document.getElementsByTagName(list[i]);     //получаем тэг из DOM по его имени
                    if (nodelist.getLength()!=1) {return "";}                       //Если информация в файле некорректна, возращаем пустую строку
                    str.append(nodelist.item(0).getTextContent());                  //извлекаем содержимое тэга и добавляем в строку
                    str.append(";");                                                //разделяем информацию ;
                }
                str.deleteCharAt(str.length()-1);
                return new String(str);    
            } catch (Exception e) {
                e.printStackTrace();
                return "";
            }           
    }



}
