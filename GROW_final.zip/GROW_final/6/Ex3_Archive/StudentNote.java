public class StudentNote {
    private String name;
    private String fileName;
    private String using;
    
    StudentNote(String name, String fileName) {
        this.name=name;                                 //строка, идентифицирующая студента
        this.fileName =fileName;                        //имя файла, в коором храниться информация о студенте
        this.using="e";                                 // признак возможности использования "Дела" для редактирования/удаления
    }
    public String getUsing(){
        return using;
    } 
    public String getName(){
        return name;
    }
    public String getFileName(){
        return fileName;
    }

    public void setUsing(String st) {
        using=st;   
    }
    public void setFileName(String fn) {
        fileName=fn;   
    }
    public void setName(String nm) {
        name=nm;   
    }
    
}
