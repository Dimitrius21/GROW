import java.io.*;
import java.net.*;
import java.util.*;
import java.net.SocketException;
import java.security.SecureRandom;

public class Server {    
    public static final String FILEPSW = "sys.set";
    PrintWriter pw;
    BufferedReader br;
    Notes notes;                                                                //Список(массив) Дел 
    //    String sID;                                                                 
    //    StudentNote modifyedNote;

    Server(){
        notes = new Notes();
    }
    public static void main(String[] args) {
        Server sv = new Server();
        sv.go();
    }
    
    public void go(){                        
        try {
            ServerSocket servSoc = new ServerSocket(5555);    
            while (true) {
                Socket soc = servSoc.accept();
                pw = new PrintWriter(soc.getOutputStream());
                br = new BufferedReader(new InputStreamReader(soc.getInputStream()));
                System.out.println("New Connect establish");    
            
                Thread rdTh = new Thread(new ServerAction(pw, br));
                rdTh.start();    
            }
        } catch (Exception e) {
            e.printStackTrace();            
                //servSoc.close();
        }     
    }
//----------------------------


public class ServerAction implements Runnable {    
    PrintWriter pw;
    BufferedReader br;
    String sID;
    StudentNote modifyedNote;

    ServerAction(PrintWriter pw, BufferedReader br){
        this.pw=pw;
        this.br=br;
    } 
    public void run() {
            String mes;
            String[] request;
            int num;
           
            try {
                while((mes=br.readLine())!=null){                     
                    System.out.println("Request - "+mes);           //Контрольный вывод текста запроса о клиента
                    request=toArString(mes);                        //Разбираем запрос на поля
                    try {
                        num=Integer.parseInt(request[0]);
                    } catch (Exception e) {
                        num=0;
                    }
                    switch (num) {
                        //case 0 : mes=toSend(2, "0", "Illegal kod"); break;
                        case 10 : checkUser(request); break;
                        case 20 : saveFile(request); break;
                        case 30 : showList(request); break;
                        case 40 : sendStudents(request); break;
                        case 50 : sendStudentFile(request); break;
                        case 60 : deleteStudentFile(request); break;
                        case 70 : modifyStudentData(request); break;
                        case 90 : blockStudentNote(request); break;
                        default : sendMessage(toSend(2, "0", "Illegal kod"));
                    }
                }
                System.out.println("close connection");   
            } catch (SocketException e) {
                //e.printStackTrace();
                System.out.println("unplug");
            }catch (Exception e) {
                e.printStackTrace();
                System.out.println("iterrupt connection");
            }   
    }    

    public void modifyStudentData(String[] request) {
        String mes;
        boolean pr=false;
        String oldNoteName, oldNoteFileName;        
        if(!checkSID(request[1])) {mes=toSend(2, "NO", "Неизвестный пользователь. Отказ");}
        else {
            //StudentNote note = notes.markNote(request[2], "m");                            //Поиск и помечаем запись на изменение
            oldNoteFileName=modifyedNote.getFileName();                                     //Запоминаем имя файла с прежним Делом(информацией о студенте)            
            oldNoteName=modifyedNote.getName();
            String fileNameNew=notes.saveData(request[3]);                                  //сохраняем новый файл с Делом(информацией о студенте)
            if (!fileNameNew.isEmpty()){                                                    //Если сохранение успешно
                modifyedNote.setFileName(fileNameNew);                                      //Меняем информацию в записи о деле
                String[] items=request[3].split(";");
                String noteName=items[0]+"."+items[1].charAt(0)+" - "+items[3]; 
                modifyedNote.setName(noteName);
                pr=notes.saveNotesList();                                                   //Сохраняем в файл список Дел
                if (pr) {                                                                   
                    modifyedNote.setUsing("e");
                    File file =new File(oldNoteFileName);                                   //удаляем старый файл с информацией
                    file.delete();
                    mes=toSend(2, "OK", "Данные изменены");}
                else {                                                                      //Востанавливаем в списке Дел старые значения
                    modifyedNote.setName(oldNoteName);
                    modifyedNote.setFileName(oldNoteFileName);
                    modifyedNote.setUsing("e");
                    mes=toSend(2, "NO", "Модификация информации не выполнена");  
                }
            } else mes=toSend(2, "NO", "Модификация информации не выполнена");  
        }
        sendMessage(mes);
    }

    public void blockStudentNote(String[] request) {
        String mes;        
        if(!checkSID(request[1])) {mes=toSend(2, "NO", "Неизвестный пользователь. Отказ");}
         else{
            //long time=Calendar.getInstance().getTimeInMillis();  
            modifyedNote = notes.markNote(request[2], "m");                                     //Помечаем запись на изменение (блокируем)
            mes=toSend(2, "OK", "Запись блокирована");            
         }
         sendMessage(mes);
    }

    //Удаление файла(Дела) и записи
    public void deleteStudentFile(String[] request) {
        String mes;
        boolean pr=false;
        if(!checkSID(request[1])) {mes=toSend(2, "NO", "Неизвестный пользователь. Отказ");}
        else {        
            StudentNote note = notes.markNote(request[2], "d");                                     //Помечаем запись на удаление
            if (note==null) {mes=toSend(2, "NO", "Запись(Дело) не может быть удалена");}            //null если запись не найдена или находится на редактровании
             else{
                String fileName=note.getFileName();                                                 //Получаем имя файла, где храниться Дело студента
                notes.getList().remove(note);                                                       //Удаляем запись о Деле из списка Дел
                pr=notes.saveNotesList();                                                           //пересохраняем в файле список Дел 
                try {
                    File file = new File(fileName);
                    if (file.exists()) {
                        pr=file.delete();                                                           //Удаляем файл с делом Студента
                    }   
                } catch (Exception e) {
                     e.printStackTrace();                 
                }
                if (pr) {mes=toSend(2, "OK", "Запись удалена");}
                  else {mes=toSend(2, "NO", "Ошибка при удалении записи(Дела)");}
             }
        } 
        sendMessage(mes);
    }

    //Найти и отправивить Дело по запрошенному студенту
    public void sendStudentFile(String[] request) {
        String mes;
        if(!checkSID(request[1])) {mes=toSend(2, "NO", "Неизвестный пользователь. Отказ");}
         else {
            String fileName=notes.getStudentFileName(request[2]);           //получить имя файла по записи о студенте
            if (!fileName.isEmpty()) {
                String data=notes.loadData(fileName);                       //загрузить данные с файла
                if (!data.isEmpty()) {
                    mes=toSend(2, "OK", data);
                    sendMessage(mes);                                       //отправить данные клиенту
                    return;
                }                
            }
            mes=toSend(2, "NO", "Дело по данному студенту не найдено");
         }
        sendMessage(mes);  
    }    

    //Отправить список Дел (записей о студентах) на основе запрошенной фамилии
    public void sendStudents(String[] request) {
        String mes;
        if(!checkSID(request[1])) {mes=toSend(2, "NO", "Неизвестный пользователь. Отказ");}
         else {
            ArrayList<String> student = notes.searchByName(request[2]);        
            String strList=arrlistToString(student);     
            mes=toSend(2, "OK", strList);
         }
        sendMessage(mes);                
    }

    //Отправить список всех Дел (записей о студентах)
    public void showList(String[] request) {        
        String mes;
        if(!checkSID(request[1])) {mes=toSend(2, "NO", "Неизвестный пользователь. Отказ");}
         else {    
            ArrayList<String> list = notes.getStudentList();        
            String strList=arrlistToString(list);    
            mes=toSend(2, "OK", strList);
         }
        sendMessage(mes);
    }
    //Преобразовать список имеющихся дел студентов в строку для отправки клиенту
    public String arrlistToString(ArrayList<String> list ) {
        StringBuilder str= new StringBuilder();
        String strList="";
        for(String s : list) {
            str.append(s);
            str.append(';');
        }
        int l=str.length();
        if (l!=0) strList=str.substring(0,l-1);       
        return strList;        
    }

    // Сохранение Дела нового пользователя
    public void saveFile(String[] request) {
        String mes;
        String fileName="";        
        System.out.println(request[2]);
        if(!checkSID(request[1])) {mes=toSend(2, "NO", "Неизвестный пользователь. Отказ");}
         else { 
            fileName=notes.saveData(request[2]);
            if (!fileName.isEmpty()) {
                notes.saveNote(request[2], fileName);
                mes=toSend(2, "OK", "Data Save");
            } else {mes=toSend(2, "NO", "Ошибка сохранения файла");}            
          }                         
        sendMessage(mes);        
    }

    // Проверка идентификатора сеанса
    public boolean checkSID(String getSID) {        
        if (sID.compareTo(getSID)==0) {            
            return true;}
         else return false;         
    }
    // Проверка, зарегистрирован ли такоой пользователь
    public void checkUser(String[] request) {
        String mes;
        do {
        SecureRandom random = new SecureRandom();           //Сгенерировать код сеанса
        byte[] bytes = new byte[20];
        random.nextBytes(bytes);
        sID=new String(bytes);
        } while (sID.contains("\n")||sID.contains("}"));      //если в преобразованном в строку коде есть символ перевода строки или } - заново генерируем

        boolean pr=Authentication.checkUser(FILEPSW, request[1], request[2]);       //Проверить, есть ли такой пользователь        
        //Сформировать соответствующий ответ. В случае аутентификации пользователя, отправить клиентской части логин, код сеанса и "роль" поьльзователя
        if (pr) { mes=toSend(4, "OK", request[1], sID, Integer.toString(Authentication.getRole()));}  
         else  { mes=toSend(2, "NO", request[1]);}       
        sendMessage(mes);    
    }
    // Отправить сообщение клиенту
    public boolean sendMessage(String mes) {
        System.out.println("Answer - "+mes);                    //Контрольный вывод на экран   !!!!
        try {
            pw.println(mes);
            pw.flush();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }            
        return true;
    }
    //Преобразование полученной строки запроса в массив полей
    public String[] toArString(String mes) {
        String[] result=mes.split("\\}\\{");
        return result;    
    }   
    //Преобразование полей ответа в строку для отправки
    public String toSend(int qt, String ... param) {
        String str="";
        switch (qt) {
            case 2 :  str=String.format("%s}{%s", param[0], param[1]); break;
            case 3 :  str=String.format("%s}{%s}{%s", param[0], param[1], param[2]); break;
            case 4 :  str=String.format("%s}{%s}{%s}{%s", param[0], param[1], param[2],param[3]); break;
        }        
        return str;
    }
}       //внутренний класс ServerAction


//-----------------------
}
