import java.io.*;
import java.net.*;
import java.util.*;
import java.util.HashMap;

public class ActionArch {
    HashMap<String, String> user = new HashMap<String, String>(3);
    Socket clSoc;
    String serverIp = "127.0.0.1";
    int serverPort = 5555;
    BufferedReader sReader;
    PrintWriter sWriter;    
  

    public static void main(String[] args) {
        new ActionArch().go();
    }

    public void go() {     
        int choise;        
        boolean pr=false;        
        //int rdAble, chAble, crAble, dlAble;
        ArrayList<String> choiseList = new ArrayList<String>();        
        if (!setConnection()){                                          //Пытаемся соединиться с сервером. Если ошибка - пауза на 1 секунду
            try {
                Thread.sleep(1000);
                if (!setConnection()){                                  //Если и повторно не подключились - выходим из программы
                    System.out.println("Нет связи с сервером. Работа программы прекращена");
                    System.exit(0);
                }    
            } catch (Exception e) {                
            }            
        }
        while(true){
            choise=Input.InpInt("Выберите действие:", "0 - Выйти из программы", "1 - Войти в систему");
            switch (choise){
                case 0 : System.exit(0);
                case 1 : pr=Auth(); break;                
            }
            if (pr) break;
        }           
        choiseList.add("Выберите действие:");
        choiseList.add("0 - Выйти из программы");
        int access=Integer.parseInt(user.get("role"));
        if ((access & 8)>0) {choiseList.add("1 - Просмотреть Дело");}
        if ((access & 4)>0) {choiseList.add("2 - Внести изменение в дело");}
        if ((access & 2)>0) {choiseList.add("3 - Добавить Дело");}
        if ((access & 1)>0) {choiseList.add("4 - Удалить Дело");}
        while(true){
            pr=false;
            choise=Input.InpInt(choiseList);
            switch (choise) {
                case 0 : System.exit(0);
                case 1 : if ((access & 8)>0) { System.out.println("Просмотр Дела"); findOneStudent(1); pr=true;} break;
                case 2 : if ((access & 4)>0) { System.out.println("Внесение изменений в Дело"); findOneStudent(2);  pr=true; } break;
                case 3 : if ((access & 2)>0) { System.out.println("Добавление нового Дела"); createFie(); pr=true; } break;
                case 4 : if ((access & 1)>0) { System.out.println("Удаление Дела"); findOneStudent(3);pr=true; } break;                
            }
            if (!pr) System.out.println("Действие запрещено");
        }
    }
    //Просмотр дела студента по введенной фамилии
    public void findOneStudent(int i) {
        int choise=Input.InpInt("Выберите действие", "1 - Ввести фамилию ","2 - Вывести список студентов");
        if (choise==2) { 
            if (!showStudentsList()) { System.out.println("Список дел пуст");  return; }
        }               // Вывести список всех студентов. Если пуст - выйти из метода
        if (!(choise==1 || choise==2)) return;
         String surname=Input.InpString("Введите фамилию студента");
         String mes=toSend(3, "40", user.get("sID"), surname);
         String answer=sendMes(mes);                            //Запросить студента по введенной фамилии 
         if (answer.compareTo("er")==0) { return;}              // Если ошибка связи с серверов - выйти
         String[] result=toArString(answer);                    //Преобразовать ответ в массив строк
         if (result[0].compareTo("OK")==0) {                    // Если ответ от сервера положительный, продолжить
            if (result.length==1) { System.out.println("Студент "+surname+" не найден"); return;}
            String[] str=result[1].split(";");                     
            if (str.length==1) {                                // Если возвращенный список содержит одну фамилию, то выполнить с Делом действие
                switch (i){
                    case 1 : showStudentInfo(str[0]); break;
                    case 2 : modifStudentFile(str[0]); break;
                    case 3 : deleteStudentFile(str[0]); break;                    
                }                
            }                  
             else {
                System.out.println("Найден более чем один студент"); 
                 for (String st : str) System.out.println(st);  
                }             
         }        
    }

    //Редактирование Дела студента
    public void modifStudentFile(String longSurname) {
        String[] str=getStudentInfo(longSurname);         
        if (str.length==0) return;
        boolean pr=true;
        if (str.length!=6) { System.out.println("Полученные данные с сервера не верны"); pr=false; }  
        
        String mes=toSend(3, "90", user.get("sID"), longSurname);  //ОТправить сообщение на сервер о блокировке изменяемого дела
        String answer=sendMes(mes);
        if (answer.compareTo("er")==0) { return;}
        String[] result=toArString(answer); 
        if (result[0].compareTo("OK")==0) {
            System.out.println("Редактируемая информация о "+longSurname);         
            if (pr) System.out.println("Дата рождения - "+str[2] );
            String birthDay="";
            while(true) {
                birthDay=Input.InpString("Введите новую информацию о дате рождения студента в формате дд.мм.гггг");
                if (Input.checkDate(birthDay)) break;
                System.out.println("Неправильно введена дата");
            }
            if (pr) System.out.println("Факультет - "+str[3]);
            String faculty=Input.InpString("Введите новое название факультета");
            if (pr) System.out.println("Курс - "+str[4]);  
            String course=Input.InpString("Введите новую информацию о курсе");
            if (pr) System.out.println("Адрес - "+str[5]);  
            String address=Input.InpString("Введите новую информацию об адресе");
            String description = String.format("%s;%s;%s;%s;%s;%s", str[0], str[1],  birthDay, faculty, course, address);                
            mes=toSend(4, "70", user.get("sID"), longSurname, description);  //ОТправить на сервер новые данные измененного дела
            answer=sendMes(mes);            
            if (answer.compareTo("er")==0) { return;}
            result=toArString(answer);
            System.out.println(result[1]);
        }        
    }
    
    // Удаление Дела 
    public void deleteStudentFile(String surname) {
        String mes=toSend(3, "60", user.get("sID"), surname);
        String answer=sendMes(mes);
        if (answer.compareTo("er")==0) { return;}
        String[] result=toArString(answer); 
        if (result[0].compareTo("OK")==0) {
            System.out.println("Запись удалена");
        } else System.out.println(result[1]);
    }

    //Получить и отобразить информацию Дела студента
    public void showStudentInfo(String surname) {
        String[] str=getStudentInfo(surname);         
        if (str.length!=6) { System.out.println("Полученные данные с сервера не верны"); return; }                
            System.out.println("Фамилия - "+str[0]);
            System.out.println("Name - "+str[1]);
            System.out.println("Дата рождения - "+str[2] );
            System.out.println("Факультет - "+str[3]);
            System.out.println("Курс - "+str[4]);          
            System.out.println("Адрес - "+str[5]);                        
            Input.InpStop("Нажмите ввод для продолжения");
    }
    // Получить Дело студента
    public String[] getStudentInfo(String surname) {
        String[] str = new String[0];
        String mes=toSend(3, "50", user.get("sID"), surname);
        String answer=sendMes(mes);
        if (answer.compareTo("er")!=0) { 
            String[] result=toArString(answer); 
            if (result[0].compareTo("OK")==0) {            
                str=result[1].split(";");                  
            } else System.out.println(result[1]);
        }
        return str;
    }   


    //Получить и отобразить список всех студентов. Если список пуст, вернуть false, иначе true
    public boolean showStudentsList() {      
        String mes=toSend(2, "30", user.get("sID"));
        String answer=sendMes(mes);
        if (answer.compareTo("er")==0) { return false;}
        String[] result=toArString(answer);
        if (result[0].compareTo("OK")==0) {
            if (result.length==1) { System.out.println("Список пуст"); return false;}
            String[] str=result[1].split(";");            
            for (String st : str) System.out.println(st); 
            Input.InpStop("Нажмите ввод для продолжения");
        }         
        return true;
    }

    // Создание Дела нового пользователя
    public void createFie() {
        String birthDay="";
        String surname=Input.InpString("Введите фамилию студента");
        String name=Input.InpString("Введите имя студента");
        //String secName=Input.InpString("Введите отчество студента");        
        while(true) {
            birthDay=Input.InpString("Введите дату рождения студента в формате дд.мм.гггг");
            if (Input.checkDate(birthDay)) break;
            System.out.println("Неправильно введена дата");
        }
        String faculty=Input.InpString("Введите название факультета");
        String course=Input.InpString("Введите курс");
        String address=Input.InpString("Введите адрес проживания");
        String description = String.format("%s;%s;%s;%s;%s;%s", surname, name,  birthDay, faculty, course, address);        
        String mes=toSend(3, "20", user.get("sID"), description);
        String answer=sendMes(mes);
        if (answer.compareTo("er")==0) { return;}
        String[] result=toArString(answer);
        if (result[0].compareTo("OK")==0) {System.out.println("Дело сохранено"); }
         else System.out.println("Ошибка сохранения");
    }

    // Аутентификация пользователя
    public boolean Auth() {       
        String log=Input.InpString("Введите логин");
        String psw=Input.InpString("Ввидите пароль");      
        String mes=toSend(3, "10", log, psw);
        String answer=sendMes(mes);
        if (answer.compareTo("er")==0) { return false;}
        String[] result=toArString(answer);
        if ((result[0].compareTo("OK")==0)&&(result[1].compareTo(log)==0)) {
            user.put("login", result[1]);
            user.put("sID", result[2]);
            user.put("role", result[3]);
            System.out.println("User "+result[1]+" has confirmed");
            return true;            
        } else {
            System.out.println("User hasn't found");
            return false;}        
    }
    //отправить сообщение на сервер и получить ответ
    public String sendMes(String mes) {
        try {
            sWriter.println(mes);
            sWriter.flush();
            mes=sReader.readLine(); 
        } catch (Exception e) {
            //e.printStackTrace();
            System.out.println("Ошибка связи с сервером");
            return "er";         
        }
        return mes;        
    }

    //установка соеиения с сервером
    public boolean setConnection() {        
        try {
            clSoc = new Socket(serverIp, serverPort) ; 
            InputStreamReader stream = new InputStreamReader(clSoc.getInputStream());
            sReader = new BufferedReader(stream);
            sWriter= new PrintWriter(clSoc.getOutputStream());    
            return true;
        } catch (Exception e) {
            System.out.println("Server is off");
            //e.printStackTrace();
            return false;
        }
    }
    // Преобразование входных данных в строку для отправки на сервер
    public static String toSend(int qt, String ... param) {
        String str="";
        switch (qt) {
            case 2 :  str=String.format("%s}{%s", param[0], param[1]); break;
            case 3 :  str=String.format("%s}{%s}{%s", param[0], param[1], param[2]); break;
            case 4 :  str=String.format("%s}{%s}{%s}{%s", param[0], param[1], param[2],param[3]); break;
        }        
        return str;
    }
    public static String[] toArString(String mes) {
        String[] result=mes.split("\\}\\{");
        return result;    
    }    
}
