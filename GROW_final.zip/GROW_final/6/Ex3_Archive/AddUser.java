public class AddUser {
     
    public static void main(String[] args) {
        String file=Server.FILEPSW;
        addNewUser(file);
    }    
    public static boolean addNewUser(String file) {                             
        String login=Authentication.loginInp();
        String psw=Authentication.pswInp();
        String email=Authentication.emailInp();
        int readable = Input.InpInt("Введите 1 если пользователь имеет право на просмотр дел в архиве, 0 - если нет");
        if (readable!=1) readable=0;        
        int changeable = Input.InpInt("Введите 1 если пользователь имеет право изменять дело в архиве, 0 - если нет");        
        if (changeable!=1) changeable=0;
        int createable = Input.InpInt("Введите 1 если пользователь имеет право на создание нового дела в архиве, 0 - если нет");
        if (createable!=1) createable=0;
        int removeable = Input.InpInt("Введите 1 если пользователь имеет право на удаление дела из архива, 0 - если нет");
        if (removeable!=1) removeable=0;
        int access = readable*8+changeable*4+createable*2+removeable;                   
        return Authentication.saveUser(login, psw, email, access, file);
    }
}
