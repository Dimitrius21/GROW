import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.*;

public class Books {
    private ArrayList<Book> bList;                          //Массив(список) с параметрами "книги"
    private File file;                                      

    Books(String fileName){                                //   Создаем список книг, чтением данных из файла. На входе имя файла
        Book book;
        bList=new ArrayList<Book>();
        file = new File(fileName);
        if (file.exists()){                                 //Если существует файл, где храняться записи о "книгах"
            try {
                Scanner sc = new Scanner(file);             //читаем построчно файл
                while (sc.hasNext()){
                    String st=sc.nextLine();
                    book=loadBook(st);                      //и создаем объект - "книгу"  из полученной строки
                    if (book!=null) bList.add(book);                    
                }
                sc.close();
            } catch (Exception e) { 
                e.printStackTrace();            
            }           
        }
    }

    //Вернуть имеющийся список книг
    public ArrayList<Book> getBookList(){                       
        return bList;
    }
    // Добавить новую "книгу" в список    
    public int addBook(){                                       
        Book book;
        String name, author, description;
        int pageQt, type, issue, num;                
        name=Input.InpString("Введите название книги");        
        author=Input.InpString("Введите автора/авторов книги");        
        issue=Input.InpInt("Введите год издания книги");        
        pageQt=Input.InpInt("Введите количество страниц в книге");        
        type=Input.InpInt("Введите тип представления книги: 1 - в бумажном виде, 2 - в электоронном виде");        
        description=Input.InpString("Введите краткой описание книги (не допускается использовать символ ;)");        
        book = new Book(name, author, description, issue, type, pageQt);
        num=bList.size();
        bList.add(num, book);   
        if (saveBook(book.getstrBook())) return num;                    // если все ок, возвращаем номер в списке добавленной "книги"
        return -1;                                                      // еслии нет, возвращаем -1
    }
    // Удаляем "книгу" из списка 
    public boolean deleteBook(Book book){          
        bList.remove(book);                                             //удаляем "книгу" из списка в оперативной памяти          
        String fileName=file.getName();                                 //Сохраняем измененный список на "жестком диске"
        String[] partFileName=fileName.split("\\.");              
        File fileTemp = new File(partFileName[0]+".tmp");
        if (saveBooks(fileTemp)) {                                      // Сохраняем список во временном файле
            file.delete();                                              // Удаляем файл с первоначальным списком
            if (fileTemp.renameTo(file)) return true;                   // Переименовываем временный файл
        }
        return false;
    }
    //Записать списка "книг" в файл 
    public boolean saveBooks(File file){                                            
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(file));    
            for(Book book : bList){
                bw.write(book.getstrBook());                
            }
            bw.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }
    //Записать(добавить) данные о "книге" в файл
    public boolean saveBook(String bk){                                     
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));    
            bw.write(bk);
            bw.close();
        } catch (Exception e) {
            e.printStackTrace();            
            return false;
        }       
        return true;
    }

    //Возвращаем созданную из строки "книгу"
    public Book loadBook(String strBook){                                   
        return Book.create(strBook);           
    }
}
