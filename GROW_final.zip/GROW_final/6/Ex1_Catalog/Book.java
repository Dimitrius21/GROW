public class Book {
    private String name;                        //Название книги
    private String author;                      //Имя автора книги
    private int issueYear;                      //Год издания
    private String description;                 //Краткое описание
    private int type;                           //тип книги - бумажный вариант, в электронном виде или оба
    private int pageQt;                         //Количество страниц в книге
    private String place;                       //место хранение книги (не используется в данной задаче )

    Book(String name, String author, String description, int issue, int type, int page){
        this.name=name;
        this.author=author;
        this.description=description;
        this.pageQt=page;
        this.type=type;
        this.issueYear=issue;
        this.place="";
    }
    public String getName() {
        return name;
    }
    public String getAuthor() {
        return author;
    }
    public String getDescription() {
        return description;
    }
    public int getPageQt() {
        return pageQt;
    }
    public int getIssue() {
        return issueYear;
    }
    public int getType() {
        return type;
    }
    public int getPlase() {
        return type;
    }
    public void setPlace(String place) {
        this.place=place;        
    }
    public void setPageQt(int page) {
        this.pageQt=page;        
    }
    public void setType(int type) {
        this.type=type;        
    }
    //Создание экземпляра "книги" путем задания всех полей/параметров
    public static Book create(String name, String author, String description, int issue, int type, int page) {        
        return new Book(name, author, description, issue, type, page);        
    }
    //Создание экземпляра "книги" из переданной строки параметров
    public static Book create(String bk) {        
        int page, type, issue;
        String[] fields = bk.split(";");        
        if (fields.length!=7) return null;

        try {
            issue=Integer.parseInt(fields[2]);                
        } catch (Exception e) {
            return null;                         //issue=0;
        }
        try {
            type=Integer.parseInt(fields[3]);    
        } catch (Exception e) {
            return null;                        //type=0; 
        }
        try {
             page=Integer.parseInt(fields[4]);                
        } catch (Exception e) {
            return null;                        //page=0;
        }               
        return new Book(fields[0].trim(), fields[1].trim(), fields[6].trim(), issue, type, page);        
    }
    //Сформировать строку содержащие параметры "книги"
    public String getstrBook(){        
        return String.format("%s;%s;%d;%d;%d;%s;%s\n", name, author, issueYear, type, pageQt, " ", description);
    }
    public String toString(){        
        String[] descr = {"бумажный вариант", "в электронном виде", "в бумажном и электронном вариантах"};
        return String.format("Книга: название - \"%s\", автор/(ы)-%s, год издания - %d, количество страниц-%d, тип представления - %s", name, author, pageQt, issueYear, descr[type-1]);        
    }
}
