import java.util.*;
//import java.util.Collection;

public class BookAction {  
    // Выводит список "книг" на экран. qt - при 0 слошной вывод полного списка, иначе частями по заданному количеству
    public static void printBook(ArrayList<Book> books, int qt) {        
        int i=1;
        if (qt==0){
            for (Book book : books) System.out.println(book.toString());                                          
        } else {
            for (Book book : books){
                System.out.println(book.toString());
                if (i%qt==0) {
                    Input.InpStop("Нажмите ввод для продолжения вывода");                 
                }
                i++;
            }                        
          }        
        Input.InpStop("Нажмите ввод для продолжения");
    }
    // Поиск "книги" по названию
    public static ArrayList<Book> searchBookByName(ArrayList<Book> books){
        ArrayList<Book> findedBook = new ArrayList<Book>();
        String name = Input.InpString("Введите название книги");                
        for(Book book : books){
            if (book.getName().toLowerCase().contains(name.toLowerCase())) findedBook.add(book);
        }              
        return findedBook;
    }
    // Поиск "книги" по автору
    public static ArrayList<Book> searchBookAuthor(ArrayList<Book> books){
        ArrayList<Book> findedBook = new ArrayList<Book>();
        String name = Input.InpString("Введите автора книги");        
        for(Book book : books){
            if (book.getAuthor().toLowerCase().contains(name.toLowerCase())) findedBook.add(book);
        }              
        return findedBook;
    }
    // Поиск списка по названию
    public static void sortByName(ArrayList<Book> books){
        Comparator<Book> nameCompare = new Comparator<Book>(){
            public int compare(Book b1, Book b2){
                return b1.getName().compareTo(b2.getName());
            }
        };
        Collections.sort(books, nameCompare);    
    }
    // Поиск списка по автору
    public static void sortByAuthor(ArrayList<Book> books){        
        Collections.sort(books, (Book b1, Book b2)-> b1.getAuthor().compareTo(b2.getAuthor()));    
    }

    
    
}
