import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.io.*;

public class Authentication {
    private static HashMap<String, String> user = new HashMap<String, String>(3);    

    //получить "роль" аутифицированного пользователя
    public static int getRole() {
      if (user.isEmpty()) return -1;
      return Integer.parseInt(user.get("Role"));      
    }
    // Хэширование пароля
    public static byte[] hash(String psw) {           
        byte[] digest = {};
        try {
            MessageDigest digester = MessageDigest.getInstance("SHA-512");
            byte[] input = psw.getBytes();
            digest = digester.digest(input);            
          } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
          }      
        return digest;
    }

    //проверка введенного пароля 
    public static boolean checkPsw(String psw, byte[] h) {    
        byte[] pswHash = hash(psw);
        int res=Arrays.compare(h,pswHash);
        if (res==0) return true;
         else return false;
    }
    //Ввод логина
    public static String loginInp() {
      String log=Input.InpString("Введите логин");
      return log;
    }  
    // Ввод пароля
    public static String pswInp() {
      String psw=Input.InpString("Ввидите пароль");      
      return psw;
    }
    //Ввод адреса электронной почты
    public static String emailInp() {
      String email=Input.InpString("Ввидите адрес электронной почты");      
      return email;
    }    
    //Сохраняет данные пользователя в файле
    public static boolean saveUser(String login, String psw, String email, int role, String filename) {
      File file = new File(filename);
      byte[] logByte = login.getBytes();
      int lLogin = logByte.length;
      byte[] emailByte = email.getBytes();
      int lEmail = emailByte.length;
      byte[] pswByte = hash(psw);
      try {                                                           //Записываем последовательно информацию о пользователе
        BufferedOutputStream bw = new BufferedOutputStream(new FileOutputStream(file, true));
        bw.write(pswByte);                                            //хэш пароля
        bw.write(role);                                               //"роль" пользователя
        bw.write(lLogin);                                             // Длину логина в байтах
        bw.write(logByte);                                            //сам логин преобразованный в полследовательность байт
        bw.write(lEmail);                                             // длину адреса электронной почты
        bw.write(emailByte);                                          // сам адрес электронной почты
        bw.close();
        System.out.println("Пользователь успешно сохранен в системе");
        return true;
      } catch (Exception e) {
        System.out.println("Ошибка записи данных");
        //e.printStackTrace(); 
        return false;
      }      
    }

    //Проверяем, существует ли такой пользователь и если да, то тот ли пароль
    public static boolean checkUser(String filename, String login, String password){                
      File file = new File(filename);      
      String[] userMain = new String[2];
      Boolean pr=false;
      byte[] psw = new byte[64];       
      int role;
      try {
        BufferedInputStream br = new BufferedInputStream(new FileInputStream(file));
        while(br.available()>0){
          role=loadUser(br, userMain, psw);                 //Загружаем с файла информацию об пользователе
          if (role>0 && userMain[0].compareTo(login)==0){   //Проверяем не было ли ошибки при чтении из файла и сравниваем логины сохраненного пользователя и текущий введенный
            if (Authentication.checkPsw(password, psw)) {   // Если пароли совпадают, аутентифицируем  пользователя               
              user.put("User", userMain[0]);                //сохраняем данные в список инф. о текущем пользователе  
              user.put("Email", userMain[1]);
              user.put("Role", Integer.toString(role));
              pr=true;            
              break; 
            }
          }
        }   
        br.close();
      } catch (Exception e) {
        e.printStackTrace();        
      }      
      return pr;
    }
    //Читаем с файла запись об очередном пользователе. Возвращаем номер(тип) роли данного пользователя или -1 при ошибке чтения
    public static int loadUser(BufferedInputStream br, String[] userMain, byte[] psw) {     
      byte[] logByte, emailByte;      
      int lLogin, lEmail, role;
      try {                                                                           
        br.read(psw);  
        role=br.read();
        lLogin=br.read();
        logByte = new byte[lLogin]; 
        br.read(logByte);
        lEmail=br.read();
        emailByte = new byte[lEmail]; 
        br.read(emailByte);          
        userMain[0]=new String(logByte);  
        userMain[1]=new String(emailByte);  
        return role;
      } catch (Exception e) {
        return -1;
      }      
    }
}
