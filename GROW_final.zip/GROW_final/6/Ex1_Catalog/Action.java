import java.util.Arrays;
import java.util.*;
import java.io.*;

public class Action {
    static String authFile = "sys.set";                     //имя файла, хранящего данные о пользователях
    public static void main(String[] args) {        
        String[] listOfChoise1 = {"Выберите действие:", "0 - Выйти из программы", "1 - Вывести список книг", "2 - Поиск книги по названию","3 - Поиск книги по имени автора"};
        String[] listOfChoise2 = Arrays.copyOf(listOfChoise1, listOfChoise1.length+3); 
        listOfChoise2[listOfChoise1.length]=(listOfChoise1.length-1)+" - Добавить книгу в список";
        listOfChoise2[listOfChoise1.length+1]=(listOfChoise1.length)+" - Удалить книгу из списка";
        listOfChoise2[listOfChoise1.length+2]=(listOfChoise1.length+1)+" - Редактиовать запись о книге";
        int choise;
        boolean pr=false; 

        while(true){
            choise=Input.InpInt("Выберите действие:", "0 - Выйти из программы", "1 - Войти в систему", "2 - Зарегистрироваться");
            switch (choise){
                case 0 : System.exit(0);
                case 1 : pr=Auth(); break;
                case 2 : pr=addNewUser(authFile);  break;
            }
            if (pr) break;
        }

        Books books = new Books("books.cvs");                       //Создаем(загружаем из файла) список книг
                
        while(true){
            choise=Authentication.getRole();                            //Проверяем, аутенцифицирован ли пользователь
            switch (choise) {                                           // в зависимости от "роли" разные варианты действий со списком "книг"
                case 1: choise=Input.InpInt(listOfChoise2); break;      //для "простого" пользователя
                case 2: choise=Input.InpInt(listOfChoise1); break;      //для "администратора"
                default: System.out.println("Пользователь не аутентифицирован"); System.exit(0);
            }
            switch (choise){
                case 0 : System.exit(0);
                case 1 : printBookList(books.getBookList()); break;
                case 2 : searchBy(books.getBookList(), 1); break;
                case 3 : searchBy(books.getBookList(), 2); break;
                case 4 : addBook(books); break;
                case 5 : deleteBook(books); break;
            }            
        }
    } //main

    //Функция аутентификации пользователя
    public static boolean Auth() {
        String login, psw;
        login=Authentication.loginInp();       
        psw=Authentication.pswInp();        
        boolean isUser =Authentication.checkUser(authFile, login, psw);
        if (isUser) { System.out.println("Пользователь "+login+" идентифицирован");  return true;}
        else {System.out.println("Пользователь не найден"); return false;}
    }
    //Функция добавления нового пользователя в список - по умолчанию создается "простой" пользователь (1 в методе saveUser, для создания "администратора" нужно использовать 2 )
    public static boolean addNewUser(String file) {                             
        String login=Authentication.loginInp();
        String psw=Authentication.pswInp();
        String email=Authentication.emailInp();
        return Authentication.saveUser(login, psw, email, 1, file);
    }

    //Функция поиска книги/книг по заданному критерию
    public static ArrayList<Book> searchBy(ArrayList<Book> bList, int c) {        
        ArrayList<Book> fBooks=null;
        switch (c){
            case 1 : fBooks=BookAction.searchBookByName(bList); break;
            case 2 : fBooks =BookAction.searchBookAuthor(bList);break;
        }        
        if (fBooks.size()==1) {
            System.out.println(fBooks.get(0).toString());
            System.out.println(fBooks.get(0).getDescription());            
            Input.InpStop("Нажмите ввод для продолжения"); 
        } else { 
            if (fBooks.size()==0) System.out.println("Книг не найдено"); 
              else BookAction.printBook(fBooks, 0); 
            }        
        return fBooks;
    }

    // Функция вывода на экран списка книг
    public static void printBookList(ArrayList<Book> books) {
        int ch=Input.InpInt("Вывести список", "0 - без сортировки","1 - отсортированный по названию книги","2 - отсортированный по имени автора");
        switch (ch) {
            case 1 : BookAction.sortByName(books);  break;
            case 2 : BookAction.sortByAuthor(books); break;
        } 
        ch=Input.InpInt("Введите число отображаемых записей за раз");
        BookAction.printBook(books, ch);
    }    
    
    // Функция удаления книги из списка
    public static void deleteBook(Books books) {                                
        ArrayList<Book> fBooks=null;
        if (Authentication.getRole()!=1) {                                      //проверяем, имеет ли пользователь права на данную операцию
            System.out.println("Нет прав на данную операцию");
            return;
        }
        while(true)    {                                                        // Ищем книгу для удаления
            int choise=Input.InpInt("УДАЛЕНИЕ КНИГИ ИЗ СПИСКА", "Найти книгу по:", "1 - названию","2 - по автору");
            fBooks=searchBy(books.getBookList(), choise);
            if (fBooks.size()==0) { System.out.println("Книг не найдено"); return; }                
             else { 
                if (fBooks.size()>1) { 
                    System.out.println("Найдена более чем одна книга, продолжение поиска"); 
                    BookAction.printBook(fBooks, 0);                                         
                 } else break;  
            }                        
        }
        int ch=Input.InpInt("Удаляем книгу из списка. 1 - подтверждаю 2 = ОТМЕНА");
        if (ch==1) {
            if (books.deleteBook(fBooks.get(0))) { System.out.println("Запись о книге удалена");}
             else { System.out.println("Ошибка. Запись о книге не удалена из списка");}
        }   
    }
    
    //Функция добавления описания книги в список
    public static void addBook(Books books) {                   
        int num;
        if (Authentication.getRole()!=1) {                      // проверяем, имеет ли пользователь права на данную операцию
            System.out.println("Нет прав на данную операцию");
            return;
        }
        num=books.addBook();  
        if (num>=0) mailingList(books.getBookList().get(num));  //Если книга успешно добавилась - сделать рассылку
    }

    //Функция рассылки сообщения о добавлении книги всем пользователям, зарегистрированным в системе
    public static void mailingList(Book book) {      
      String[] userMain = new String[2];    
      byte[] psw = new byte[64];       
      int role;
      try {
        BufferedInputStream br = new BufferedInputStream(new FileInputStream(authFile));
        while(br.available()>0){
          role=Authentication.loadUser(br, userMain, psw);
          if (role>0){ 
            sendEmail(userMain[1], "Добавление новой книги", book.toString() );              
          }
        }           
        br.close();
      } catch (Exception e) {
        e.printStackTrace();   
        System.out.println("Ошибка рассылки");     
      }              
    }
    // Функция отправки email (пустая заглушка)
    public static void sendEmail(String reseiver, String subject, String text) {
        
    }
}
