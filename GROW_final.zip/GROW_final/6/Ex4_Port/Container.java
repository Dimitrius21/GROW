public class Container {
    private int number;                                         //Номер контейнера
    private String description;                                 //Описание контейнера - в данном проекте не используется
    
    Container(){
        this.number=(int)Math.ceil(Math.random()*100000);        
    }
    Container(int num, String descr){
        this.number=num;
        this.description=descr; 
    }

    public int getNumber() {
        return number;        
    }
    public String getDecription() {
        return description;        
    }
    public void setDescription(String desc) {
        this.description=desc; 
    }

    public static Container createContainer() {
        Container container=new Container();
        return container;        
    }
}
