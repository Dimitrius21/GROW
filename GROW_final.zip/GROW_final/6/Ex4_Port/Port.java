import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class Port {
    private int maxCapacity;                                        //Максимальное количество контейнеров в порту
    private int containerQt;                                        //Текущее количество контейнеров в порту
    private ConcurrentLinkedQueue<Vessel> vessels;                  //массив судов на рейде порта, ожидающих обработки
    private ArrayList<Pier> piers;                                  //Список причалов порта
    int piersQt;
    private ArrayBlockingQueue<Container> portStore;                //массив - хранилище контейнеров в порту
    private static int[][] piersAction;                             //массив состояния работы каждого причала (работает/свободен)
    private static ConcurrentLinkedQueue<Integer> piersFree;        //список свободных пирсов 
    static long time;                                               //время начала работы 


    Port(int maxCap, int piersQt){
        this.maxCapacity=maxCap;
        portStore = new ArrayBlockingQueue<Container>(maxCapacity);    
        this.containerQt=0;
        piersAction = new int[piersQt][2];
        this.piersQt=piersQt;
        piersFree= new ConcurrentLinkedQueue<Integer>();
        piers = new ArrayList<Pier>(piersQt);
        for (int i=0; i<piersQt; i++){
            piers.add(new Pier(i, portStore));
            piersFree.add(i);            
        }        
        containerQt=(int) Math.ceil(Math.random()*maxCapacity);             //задаем начальное количество контейнеров в хранилище порта
        for(int i=0;i<containerQt;i++){
            try {
                portStore.put(Container.createContainer());                 //Создаем и добавляем контейнеры в хранилище порта
            } catch (Exception e) {
                
            }            
        }
        vessels = new ConcurrentLinkedQueue<Vessel>();                        //Создаем рейд порта        
    }
    
    Port(){
        maxCapacity=(int) Math.ceil(Math.random()*200)+200;                 //задаем вместимость порта (200-400 контейнеров)
        portStore = new ArrayBlockingQueue<Container>(maxCapacity);        
        piersQt=(int) Math.ceil(Math.random()*3)+3;                         //задаем количество причалов для обработки судн (3-6)
        piersAction = new int[piersQt][2];
        piersFree= new ConcurrentLinkedQueue<Integer>();
        piers = new ArrayList<Pier>(piersQt);
        for (int i=0; i<piersQt; i++){                                      //создаем причалы и добавляем их в список 
            piers.add(new Pier(i, portStore));
            piersFree.add(i);                                               //добавляем созданный причал в число свободных
        }
        containerQt=(int) Math.ceil(Math.random()*maxCapacity);             //задаем начальное количество контейнеров в хранилище порта
        for(int i=0;i<containerQt;i++){
            try {
                portStore.put(Container.createContainer());                 //Создаем и добавляем контейнеры в хранилище порта
            } catch (Exception e) {
                
            }            
        }
        containerQt=portStore.size();                                       //уточняем количество контейнеров в хранилище порта
        vessels = new ConcurrentLinkedQueue<Vessel>();                      //Создаем рейд порта (корабли ожидающие обработки)
    }
    //Информация о состоянии порта
    public void portInfo() {       
        System.out.println("Емкость хранилища контейнеров порта - "+maxCapacity);
        System.out.println("Количество контейнерв в порту - "+containerQt);
        System.out.println("Количество причалов в порту - "+piersQt);
        System.out.println("Количество кораблей на входе в порт - " +vessels.size());        
    }

    //Действия по завершении обработки корабля
    public static synchronized  void endPiesrAct(int num) {
        if (num < piersAction.length){
            piersAction[num][0]=0;
            piersAction[num][1]++;
            piersFree.add(num);                                                         //Вносим причал в список свободных
            System.out.println("---- Причал "+num+" завершил обработку судна ----");
        }        
    }
    //Первоначальное создание кораблей 
    public void prepare() {
        int vesselQt=(int) Math.ceil(Math.random()*7)+3;                            //создаем суда (от 3 до 10) и помещаем их на рейде порта
        for(int i=0;i<vesselQt;i++){        
            if (i%2==0) vessels.add(Vessel.createVessel('u'));            
             else vessels.add(Vessel.createVessel('l'));            
        }
    }

    public void go() {             
        prepare();   
        time=System.currentTimeMillis();
        System.out.println("Сформированные исходные данные. ");
        time+=20000;                                                            //Задает время в течение которого будет проверяться появление новых кораблей на входе
        portInfo();
        while(true) {                                                           // Первоначальное распределение кораблей по причалам
            if (!vessels.isEmpty()){                                            //если есть суда на рейде, ожидающие обработки
                if (piersFree.isEmpty()) break;                                 //если нет свободного пирса выходим                                                             
                piers.get(piersFree.poll()).startAction(vessels.poll());        //иначе передаем корабль на обработку первому свободному пирсу
            }
            else break;
        }
        new Thread(){                                                                // Поток обработки входящих кораблей 
            public void run() {
                while(true) {
                    if (!vessels.isEmpty()){                                          //если есть суда на рейде, ожидающие обработки
                        if (piersFree.isEmpty()) {                                    //если нет свободного пирса 
                            try {                                                     // пауза на 1 секунду 
                                Thread.sleep(1000);
                            } catch (Exception e) {   
                            }
                        }                                                                                              
                        else {                                                          //иначе передаем корабль на обработку первому свободному пирсу
                            int num=piersFree.poll();
                            System.out.println("---- Причалу "+num+" поставлено в обработку новое судно ----");
                            piers.get(num).startAction(vessels.poll());  
                        }  
                    }
                    else {
                        if (System.currentTimeMillis()>time) break;                       //если на входе в порт ничего нет и время работы (time) вышло - выходим
                    }                    
                }   
                System.out.println("---!!---КОРАБЛЕЙ НА ВХОДЕ В ПОРТ БОЛЬШЕ НЕТ---!!---");
            }
        }.start(); 

        new Thread(){                                                           // Поток добавления некотрого дополнительного кол. судов 
            Vessel vessel;
            public void run() {
                int newVesselQt=(int)Math.floor(Math.random()*3)+1;             //Определяем случайным образом доп.кол. кораблей которые прибудут в порт
                
                int sleepping=15000/newVesselQt;                                //определяем промежутки, через которые будут появляться новые суда
                for(int i=0;i<newVesselQt; i++) {
                    try {                   
                        Thread.sleep(sleepping);
                        vessel=Vessel.createVessel();
                        vessels.add(vessel);
                        System.out.println("---- На рейд встало новое судно ----");
                    } catch (Exception e) {                    
                    }                
                }
            }
        }.start(); 
    }

    public static void main(String[] args) {
        Port port = new Port();
        port.go();
    }

}
