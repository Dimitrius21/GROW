import java.util.ArrayDeque;
import java.util.ArrayList;

public class Vessel {
    private int maxCapacity;                                    //Максимальное количество контейнеров на корабле
    private int containerQt;                                    //Текущее количество контейнеров на корабле
    private char type;                                          //ТИп операции (разгрузк/загрузка) которая должна выполниться с судном
    private ArrayDeque<Container> containers;                   //Массив контейнеров

    Vessel(int maxCapacity){
        this.maxCapacity=maxCapacity;
        this.containers = new ArrayDeque<Container>();
    }

    Vessel(int maxCapacity, char type, ArrayList<Container> containers) {
        this.maxCapacity=maxCapacity;
        this.containers = new ArrayDeque<Container>();
        this.containers.addAll(containers);
        containerQt=this.containers.size();
        this.type=type;
    };

    public int getmaxCapasity() {
        return maxCapacity;    
    } 
    public int getContainerQt() {
        return containerQt;    
    } 
    public char getType() {
        return type;    
    } 

    public void setType(char typeAct) {
        type=typeAct;        
    }
    // Выгрузка контейнера с корабля
    public Container unloadContainer() {        
        if (containerQt>0) {
            containerQt--;
            return containers.poll();                                
        }
        else return null;
    }
    // Загрузка контейнера на корабль
    public int loadContainer(Container container) {
        if (containerQt<maxCapacity) {
            containerQt++;                
            containers.add(container);            
            return containerQt;
        }
        else {             
            return -1;}
    }
    // Создать произвольное судно
    public static Vessel createVessel() {
        char type;
        int maxCapacity = (int) Math.ceil(Math.random()*100);
        int qt=(int) Math.ceil(Math.random()*maxCapacity);        
        ArrayList<Container> containers = new ArrayList<Container>(qt);
        if (Math.random()<0.5) type='u';
         else type='l';
        for(int i=0; i<qt; i++){
            containers.add(Container.createContainer());
        }
        return new Vessel(maxCapacity, type, containers);        
    }
    public static Vessel createVessel(char type) {    
        int maxCapacity = (int) Math.ceil(Math.random()*100);
        int qt=(int) Math.ceil(Math.random()*maxCapacity);        
        ArrayList<Container> containers = new ArrayList<Container>(qt);    
        for(int i=0; i<qt; i++){
            containers.add(Container.createContainer());
        }
        return new Vessel(maxCapacity, type, containers);        
    }
}
