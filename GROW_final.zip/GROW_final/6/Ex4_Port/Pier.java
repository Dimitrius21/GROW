
import java.util.concurrent.ArrayBlockingQueue;

public class Pier {
    ArrayBlockingQueue<Container> store;                            //Ссылка на склад(хранилище контейнеров) порта
    Vessel vessel;                                                  //Ссылка на кораль, который обрабатывается 
    int number;                                                     //Номер причала

        Pier(int num, ArrayBlockingQueue<Container> store){
            this.number=num;
            this.store=store;
        }
    //Окончание операции(загрузка/разгрузка) судна
    public void endAction() {
        Port.endPiesrAct(number);
    }

    //Перемещение контейнера на склад порта
    public boolean putContainer(Container cn) {
        try {
            store.put(cn);      
            return true;
        } catch (Exception e) {
            return false;
        }              
    }
    //Взять контейнер со склада порта
    public Container takeContainer() {
        try {
            return store.take();    
        } catch (Exception e) {
            System.out.println("No containers");
            return null;
        }
        
    }
    //начало обработки судна (выбор необходимого действия - загрузка/разгрузка)
    public void startAction(Vessel curentVessel) {
        vessel=curentVessel;
        Thread action=null;
        char act=curentVessel.getType();
        switch (act){
            case 'l' : action = new Thread(new loading()); break;
            case 'u' : action = new Thread(new unloading()); break;
        }
        action.start();                        
    }
    //класс запускающий поток загрузки контейнеров на корабль
    class loading implements Runnable{
        Container cn;
        public void run(){
            int i=1;
            int max=vessel.getmaxCapasity();
            while (vessel.getContainerQt()<max){
                cn=takeContainer();
                if (cn!=null) { vessel.loadContainer(cn);
                    try {
                        System.out.println("Причал номер "+number+". Загружен контейнер "+i+" на судно, номер контейнера"+cn.getNumber());
                        i++;
                        Thread.sleep(400);                        
                    } catch (Exception e) {
                        System.out.println("Error sleep ");
                    }
                }                
            }
            endAction();
        }
    }
    //класс запускающий поток разгрузки контейнеров с корабля
    class unloading implements Runnable{
        Container cn; //= new Container();
        public void run(){            
            cn=vessel.unloadContainer();
            while(cn!=null) {                    
                    putContainer(cn);
                    System.out.println("Причал номер "+number+". Разгружен контейнер "+(vessel.getContainerQt()+1)+" с судна. Номер контейнера"+cn.getNumber());
                    cn=vessel.unloadContainer();
                    try {
                        Thread.sleep(400);    
                    } catch (Exception e) {                    
                    }
            }            
            endAction();        
        }
    }

}
