//Каждая Заметка это: Заметка (тема, дата создания, e-mail, сообщение).

public class Note implements Comparable<Note> {
    String theme;                                                       //Тема заметки
    String date;                                                        //Дата заметки
    String email;                                                       //адрес электронной почты
    String text;                                                        //основной текст заметки

    Note(String theme, String date, String email, String text){
        this.theme=theme;
        this.date=date;
        this.email=email;
        this.text=text;        
    }
    public String getTheme() {
        return theme;    
    }
    public String getDate() {
        return date;    
    }
    public String getEmail() {
        return email;    
    }
    public String getText() {
        return text;    
    }

    public String toString() {
        return String.format("Заметка: Тема - %s, Дата - %s, email - %s", theme, date, email);        
    }

    @Override
    public int compareTo(Note nt) {
        String[] dtSec=nt.getDate().split("\\.");
        String[] dtMain=date.split("\\.");
        int yDif =Integer.parseInt(dtMain[2])-Integer.parseInt(dtSec[2]);        
        if (yDif!=0) return yDif;
        int mDif=Integer.parseInt(dtMain[1])-Integer.parseInt(dtSec[1]);
        if (mDif!=0) return mDif;
        int dDif=Integer.parseInt(dtMain[0])-Integer.parseInt(dtSec[0]);
        return dDif;
    }
     
}
