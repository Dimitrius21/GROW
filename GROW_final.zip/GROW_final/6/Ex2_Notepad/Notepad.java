import java.io.*;
import java.util.ArrayList;
import java.util.regex.*;

public class Notepad  {
    private static String NOTEPADFILE = "notes.txt";                //Имя файла, в котором храняться заметки
    private ArrayList<Note> notes;                                  //Массив, содержащий заметки
    
    Notepad(){
        //notes = new ArrayList<Note>();
        notes=loadNotes();        
    }

    public ArrayList<Note> getNoteList() {
        return notes;
    }
    //Сортировка списка Заметок по дате
    public void sortByDate(ArrayList<Note> noteList, int start, int end) {        
        Note note;
        int l=end-start;
        for(int i=0; i<l; i++){
            for (int j=start; j<end-i; j++){
                if (noteList.get(j).compareTo(noteList.get(j+1))>0) {
                    note=noteList.get(j+1);
                    noteList.set(j+1, noteList.get(j));
                    noteList.set(j, note);
                    System.out.println(note.getDate());
                }
            }
        }        
    }
    
    //Поиск по адресу Теме
    public ArrayList<Note> findByTheme(String theme) {            
            ArrayList<Note> noteList = new ArrayList<Note>();
            for (Note note : notes ){
                if (note.getTheme().toLowerCase().contains(theme.toLowerCase())) {noteList.add(note);}
            }        
            return noteList; 
        }
    // Поиск по слову в основном тексте Заметки
    public ArrayList<Note> findByWord(String word) {        
        ArrayList<Note> noteList = new ArrayList<Note>();
        for (Note note : notes ){
            if (note.getText().contains(word)) {noteList.add(note);}
        }        
        return noteList;        
    }
    // Поиск Заметок по дате
    public ArrayList<Note> findByDate(String date) {
        String reg=date.replaceAll("\\.","\\\\.");
        ArrayList<Note> fList = new ArrayList<Note>();
        for (Note note : notes ){
            if (note.getDate().matches(reg)) {fList.add(note);}
        }        
        return fList;        
    }
    public ArrayList<Note> findByDate(ArrayList<Note> noteList, String date) {
            ArrayList<Note> fList = new ArrayList<Note>();
            String reg=date.replaceAll("\\.","\\\\.");            
            for (Note note : noteList ){                            
                if (note.getDate().matches(reg)) {fList.add(note);}
            }  
            return fList;        
    }
    //Поиск Заметок по адресу электоронной почты
    public ArrayList<Note> findByEmail(String email) {
        ArrayList<Note> fList = new ArrayList<Note>();
        String emailNew=changeEmail(email);
        for (Note note : notes ){
            if (note.getEmail().matches(emailNew)) {fList.add(note);}
        }        
        return fList;          
    }
    public ArrayList<Note> findByEmail(ArrayList<Note> noteList, String email) {
            ArrayList<Note> fList = new ArrayList<Note>();
            for (Note note : noteList ){
                if (note.getEmail().contains(email)) {fList.add(note);}
            }        
            return fList;        
    }
    //Преобразование адреса электорнной почты для вида, подходящего для использованияв качестве регулярного выражения (экранируем все спец.символы)
    public static String changeEmail(String email) {
        String reg ="([\\w!#%&\\$\\'\\*\\+-/=\\?\\^\\{\\|\\}\\~\\.]+)@(\\w+\\.[a-z]+)$";
        Pattern p = Pattern.compile(reg);
        Matcher m = p.matcher(email);     
        //System.out.println(m.matches());        
        String lp1=m.group(1);
        String lp2=m.group(2);        
        String[] changes = {"\\$","\\'","\\*","\\+","\\?","\\^","\\{","\\|","\\}","\\~","\\."};        
        for (int i=0; i<changes.length; i++) lp1=lp1.replaceAll(changes[i], "\\"+changes[i]);
        String emailNew=lp1+"@"+lp2;
        //System.out.println(emailNew);    
        return emailNew; 
    }

    // Добавить новую Заметку 
    public void addNewNote(){
        StringBuilder text = new StringBuilder();
        String theme = Input.InpString("Введите тему заметки");
        String date = Input.InpString("Введите дату заметки в формате дд.мм.гггг");
        String email = Input.InpString("Введите адрес электронной почты");        
        System.out.println("Введите основной текст заметки, после последнего предложения дополнительно нажмите клавишу Ввод");
        String st;
        while (true) {
            st=Input.Inp();
            if (st.compareTo("")==0) break;
            text.append(st+"}{");
        }
        while (!Input.checkDate(date)) {
            date = Input.InpString("Дата введена неверно (формат дд.мм.гггг). Повторите ввод");
        }
        while (!Input.checkEmail(email)) {
            email = Input.InpString("Адрес электронной почты указан неверно, повторите ввод");
        }
        Note note = new Note(theme, date, email, new String(text.substring(0, text.length()-2)));
        notes.add(note);        
    }

    //Сохранить список Записей в файл
    public boolean saveNotes(ArrayList<Note> noteList) {
        try {
            BufferedWriter br = new BufferedWriter(new FileWriter(NOTEPADFILE));
            for (Note note : noteList){
                String noteForSave=String.format("%s}{%s}{%s}{%s", note.getTheme(), note.getDate(), note.getEmail(), note.getText());
                br.write(noteForSave);                
                br.newLine();      
            }
            br.close();
            return true;
        } catch (Exception e) {
            return false;
        }        
    }
    //загрузить список Записей из файла
    public ArrayList<Note> loadNotes() {
        ArrayList<Note> noteList = new ArrayList<Note>();
        String it;        
        try {
            File file = new File (NOTEPADFILE);
            if (!file.exists()) return noteList;
            BufferedReader br = new BufferedReader(new FileReader(new File(NOTEPADFILE)));    
            it=br.readLine();
            //while (!it.isEmpty()){
            while (it!=null ){    
                String[] arrNote = it.split("\\}\\{");
                StringBuilder st = new StringBuilder();
                for (int i=3; i<arrNote.length; i++){
                    st.append(arrNote[i]+"}{");
                }            
                Note note = new Note(arrNote[0], arrNote[1], arrNote[2], new String(st));
                noteList.add(note);            
                it=br.readLine();
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();                        
        }
        return noteList;
    }
    // Вывести на экран полученный список Заметок
    public void printNotes(ArrayList<Note> noteList) {
        if (noteList.size()==0) {    System.out.println("Список пуст"); return;}
        System.out.println("Найдено:");
        for (Note note : noteList){
            System.out.println("Тема заметки - "+note.getTheme());
            System.out.println("Дата заметки - "+note.getDate());
            System.out.println("Email заметки - "+note.getEmail());
            System.out.println("Текст заметки:");
            String[] arrNote = note.getText().split("\\}\\{");
            for (int i=0; i<arrNote.length; i++){
                System.out.println(arrNote[i]);
            }
        }        
    }

}
