import java.util.*;
import java.util.regex.*;


public class Input {
    private static Scanner sc =new Scanner(System.in);
  
    public static String Inp() {          
      return sc.nextLine();
} 
    public static String InpString(String text) {
        String str="";
        System.out.println(text); 
        System.out.print("?: ");
        do {
          str = sc.nextLine().trim();
        } while (str.isEmpty()); 
        return str;        
    }
    public static int InpInt(String text) {
        int i=0;
        System.out.println(text); 
        System.out.print("?: ");
          i=sc.nextInt();        
          sc.nextLine();        
        return i;        
    }
  public static int InpInt(String ... text) {
    int i=0;
    for(String st : text) System.out.println(st); 
    System.out.print("?: ");
      i=sc.nextInt();        
      sc.nextLine();        
    return i;        
  }
  public static int InpInt(ArrayList<String> text) {
    int i=0;
    for(String st : text) System.out.println(st); 
    System.out.print("?: ");
      i=sc.nextInt();        
      sc.nextLine();        
    return i;        
  }
  public static void InpStop(String text) {    
        System.out.println(text);
        sc.nextLine();
  }      
  //Проверка правильности введенной даты
  public static boolean checkDate(String date) {           
    try {
        if (!date.matches("[0-3]?\\d\\.[0-1]\\d\\.[1-2]\\d\\d\\d")) return false;
        String[]dateAr = date.split("\\.");
        int day=Integer.parseInt(dateAr[0]);
        int month=Integer.parseInt(dateAr[1]);
        int year=Integer.parseInt(dateAr[2]);
        if (day>31 || month>12) return false; 
        if(month==2 && day>29) return false;
        boolean v=(year%4==0)&&(year%100!=0);
        if (year%400==0) v=true;
        if(!v && month==2 && day>28) return false;         
        if (day>30 && (month==4 || month==6 || month==9 || month==11 )) return false;
        return true;    
    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
  /* Вариант стандартными средствами Java
    Calendar calendar = new Calendar();
    calendar.set(year, month, day);
    return calendar.isLenient();        
  */        
  }
  public static boolean checkEmail(String email) {           
    try {
      String reg ="([\\w!#%&\\$\\'\\*\\+-/=\\?\\^\\{\\|\\}\\~\\.]+)@\\w+\\.[a-z]+$";
      Pattern p = Pattern.compile(reg);
      Matcher m = p.matcher(email);     
      if (!m.matches()) return false;
      String lp=m.group(1);      
      reg="^\\..*|.*\\.$|.*\\.{2,}.*";
      boolean r=lp.matches(reg);          
      return !r;
    } catch (Exception e) {
      e.printStackTrace();
      return false;
    }   
  }
}
