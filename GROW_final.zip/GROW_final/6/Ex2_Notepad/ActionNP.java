import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ActionNP {
    private Notepad np = new  Notepad();
    public static void main(String[] args) {
        new ActionNP().go();   
    }

    public void go() {
        int choise;
        while(true){
            choise=Input.InpInt("Выберите действие:", "0 - Выйти из программы", "1 - Добавить Заметку", "2 - Вывести список всех Заметок", "3 - Поиск Заметки");
            switch (choise){
                case 0 : np.saveNotes(np.getNoteList());  System.exit(0);
                case 1 : add(); break;
                case 2 : printAllNote(); break;
                case 3 : searchNote(); break;
            }            
        }   
    }
    // Добавить заметку
    public void add() {
        np.addNewNote();        
    }
    //Вывести список всех Заметок
    public void printAllNote() {
        for (Note note : np.getNoteList()){
            System.out.println(note.toString());            
        }
        Input.InpStop("Нажмите ввод для продолжения");
    }

    //Выбор варианта поиска заметки
    public void searchNote() {        
        int choise=Input.InpInt("Выберите действие:", "0 - Поиск по Теме заметки", "1 - Поиск по дате", "2 - Поиск по адресу эл.почты",
         "3 - Поиск по дате и адресу электронной почты", "4 - Поиск по теме Заметки и адресу электронной почты", "5 - Поиск в основном тексте");
            switch (choise){
                case 0 :  searchByTheme(); break;
                case 1 :  searchByDate(); break;
                case 2 :  searchByEmail(); break;
                case 3 :  searchByDateAndEmail(); break;
                case 4 :  searchByThemeAndEmail(); break;
                case 5 :  searchInText(); break;
            }                    
    }

    //Поиск Заметок по теме 
    public void searchByTheme() {
        ArrayList<Note> notes; 
        String theme = Input.InpString("Введите искомую тему Заметки");        
        notes=np.findByTheme(theme);        //Получаем найденный список
        sortChoise(notes);                  // Сортируем        
        np.printNotes(notes);               //Выводим на экран
    }

    //Поиск Заметок по дате 
    public void searchByDate () {
        ArrayList<Note> notes; 
        String date = Input.InpString("Введите дату заметки в формате дд.мм.гггг");
        while (!Input.checkDate(date)) {
            date = Input.InpString("Дата введена неверно (формат дд.мм.гггг). Повторите ввод");
        }
        notes=np.findByDate(date);          //Получаем найденный список
        sortChoise(notes);                  // Сортируем
        np.printNotes(notes);               //Выводим на экран
    }
    //Поиск Заметок по адресу электоронной почты
    public void searchByEmail() {
        ArrayList<Note> notes; 
        String email = Input.InpString("Введите адрес электронной почты");
        while (!Input.checkEmail(email)) {
            email = Input.InpString("Адрес электронной почты указан неверно, повторите ввод");
        }
        notes=np.findByEmail(email);
        sortChoise(notes);
        np.printNotes(notes);
    }
    //Поиск Заметок по дате и адресу электронной почты
    public void searchByDateAndEmail () {
        ArrayList<Note> notes; 
        String date = Input.InpString("Введите дату заметки в формате дд.мм.гггг");
        while (!Input.checkDate(date)) {
            date = Input.InpString("Дата введена неверно (формат дд.мм.гггг). Повторите ввод");
        }        
        String email = Input.InpString("Введите адрес электронной почты");
        while (!Input.checkEmail(email)) {
            email = Input.InpString("Адрес электронной почты указан неверно, повторите ввод");
        }
        notes=np.findByDate(date);                  //Получаем найденный список        
        notes=np.findByEmail(notes, email);         //Получаем найденный список
        sortChoise(notes);                          // Сортируем
        np.printNotes(notes);                       //Выводим на экран
    }
    //Поиск Заметок по теме и адресу электронной почты
    public void searchByThemeAndEmail () {
        ArrayList<Note> notes; 
        String theme = Input.InpString("Введите искомую тему Заметки");          
        String email = Input.InpString("Введите адрес электронной почты");   
        while (!Input.checkEmail(email)) {
            email = Input.InpString("Адрес электронной почты указан неверно, повторите ввод");
        }     
        notes=np.findByTheme(theme);            //Получаем найденный список
        notes=np.findByEmail(notes, email);
        sortChoise(notes);                      // Сортируем
        np.printNotes(notes);                   //Выводим на экран
    }
    //Поиск Заметок по слову в тексте 
    public void searchInText() {        
        ArrayList<Note> notes; 
        String word = Input.InpString("Введите искомое слово в тексте сообщения");                  
        notes=np.findByWord(word);              //Получаем найденный список
        sortChoise(notes);                      // Сортируем
        np.printNotes(notes);                   //Выводим на экран
    }

    //Выбор метода сортировки
    public void sortChoise(ArrayList<Note> noteList) {            
        int choise;
        choise=Input.InpInt("Отсортировать найденный список :", "0 - без сортировки", "1 - по дате", "2 - по адресу электронной почты",
         "3 - по адресу эл.почты и затем по дате ");
        switch (choise){
            case 0 : break;
            case 1 : sortByDate(noteList); break;
            case 2 : sortByEmail(noteList); break;
            case 3 : sortByEmailAndDate(noteList);break;
        }                      
    }
    //Сортировка списка по дате
    public void sortByDate(ArrayList<Note> noteList) {
        Collections.sort(noteList);        
    }
    //Сортировка списка по адресу электронной почты
    public void sortByEmail(ArrayList<Note> noteList) {
        Comparator<Note> emailCompare = new Comparator<Note>(){
            public int compare(Note n1, Note n2) {
                return n1.getEmail().compareTo(n2.getEmail());
            }            
        };
        Collections.sort(noteList, emailCompare);        
    }
    //Сортировка списка по адресу электронной почты и затем по дате
    public void sortByEmailAndDate(ArrayList<Note> noteList) {
        sortByEmail(noteList);        
        String email;        
        int l=noteList.size();        
        int end=0, start=0;
        email=noteList.get(0).getEmail();
        for (int i=1; i<l; i++){
            if (email.compareTo(noteList.get(i).getEmail())==0) {
                end=i;
            } else {
                email=noteList.get(i).getEmail();
                start=i;
                np.sortByDate(noteList, start, end);
            }
        }
        np.sortByDate(noteList, start, end);
    }
}
