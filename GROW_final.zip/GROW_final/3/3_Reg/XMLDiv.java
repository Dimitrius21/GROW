/*
Напишите анализатор, позволяющий последовательно возвращать содержимое узлов xml-документа и его тип 
(открывающий тег, закрывающий тег, содержимое тега, тег без тела).
*/

import java.util.regex.Pattern;
import java.util.regex.*;

public class XMLDiv {    

    public static void main(String[] args) {
        String part1;
        String part2;        
        
        String str="<notes>"+
                        "<note id = \"1\">"+
                            "<to>Вася</to>"+
                            "<from>Света</from>"+
                            "<heading>Напоминание</heading>"+
                            "<body>Позвони мне завтра!</body>"+
                        "</note>"+
                        "<note id = \"2\">"+
                            "<to>Петя</to>"+
                            "<from>Маша</from>"+
                            "<heading>Важное напоминание</heading>"+
                            "<body/>"+
                        "</note>"+
                    "</notes>";
        String reg1 = "(<.+?>)(.*?<.+>$)";
        String reg2 = "(.+?)(<.+>$)";
        Pattern p1 = Pattern.compile(reg1);
        Pattern p2 = Pattern.compile(reg2);
        Matcher m = p1.matcher(str);
        if (m.matches()) {
          do {              
            part1=m.group(1);
            part2=m.group(2);
            if (part1.matches("^</.+")) System.out.println(part1+" - закрывающий тег");    
             else if (part1.matches(".+/>$")) System.out.println(part1+" - тег без содержимого");    
                   else if (part1.matches("^<.+")) System.out.println(part1+" - открывающий тег"); 
                         else System.out.println(part1+" - содержимое тэга"); 
            
            if(part2.matches("^<.+")) { m = p1.matcher(part2); }               
             else  { m = p2.matcher(part2); }
            
          }while (m.matches());
          if (part2.matches("^</.+")) System.out.println(part2+" - закрывающий тег");    
             else if (part2.matches(".+/>$")) System.out.println(part2+" - тег без содержимого");    
                   else if (part2.matches("^<.+")) System.out.println(part2+" - открывающий тег"); 
                         else System.out.println(part2+" - содержимое тэга"); 
        }
    }
}



