/*
1. Cоздать приложение, разбирающее текст (текст хранится в строке) и позволяющее выполнять с текстом три различных операции: 
отсортировать абзацы по количеству предложений; 
в каждом предложении отсортировать слова по длине; 
отсортировать лексемы в предложении по убыванию количества вхождений заданного символа, а в случае равенства – по алфавиту.
*/

public class StrSort{
    public static void main(String[] args) {       
       String ourText = "Nec labore cetero theophrastus no, ei vero facer veritus nec. Vix paulo sanctus scripserit ex, te iriure insolens voluptatum qui. Sale liber et vel.\n "+
        "Fiat mali eos boni autho effecerit soni. Sensus venturum alios ibi isti! Meos potentiale tribuebam seu respexi. Quomodo ponderibus corpo pati.\n"+ 
        "Vix paulo sanctus scripserit ex, te iriure insolens voluptatum qui. Per cu iracundia splendide."; 
        
        sort(1, ourText);
        System.out.println(); 
        sort(2, ourText);
        System.out.println(); 
        sort(3, ourText);
    }

    public static void sort(int t, String str){
        switch (t)  {
            case 1 : opFirst(str); break;
            case 2 : opSecond(str); break;
            case 3 : opThird(str, 'i');  break;
        }
    }
    public static void opFirst(String inpText){                     //отсортировать абзацы по количеству предложений
        int pos;
        String[] paragraphs = inpText.split("\\s*\n\\s*");          // разбиваем текст на абзацы
        int l=paragraphs.length;
        int[][] lengthArray = new int[l][2];
       
        for (int i=0; i<l; i++){
            String[] sentences = paragraphs[i].split("\\s*(\\.|!|\\?)\\s*");    // разбиваем каждый абзац на предложения
            lengthArray[i][0]=i;                                                //Заносим в массив номер абзаца
            lengthArray[i][1]=sentences.length;                                 //и количество предложений в нем
        }
        sortIntAr(lengthArray);                                                 //сортируем массив с кол.предложений в каждом абзаце
        for (int i=0; i<l; i++){
            pos=lengthArray[i][0];
            System.out.println(paragraphs[pos]);                                // выводим отсортрованные параграфы
        }        
    }

    public static void opSecond(String inpText){        
        String[] paragraphs = inpText.split("\\s*\n\\s*");                                      // разбиваем текст на абзацы        
        for (String paragraph : paragraphs){ 
                String[] sentences = paragraph.split("\\s*(\\.|!|\\?)\\s*");                    // разбиваем каждый абзац на предложения
                for( String sentence : sentences)  {
                    String[] words = sentence.split(",?\\s+");                                  // разбиваем каждое предложение на слова
                        String[] wordsSort=sortItemsLength(words);                              // сортируем слова в предложении по длине
                        StringBuilder newSentence = new StringBuilder();
                        for (String word : wordsSort) { newSentence.append(word+" ") ;  }       // Формируем предложение с отсортированными словами                        
                        System.out.print(newSentence.substring(0, newSentence.length()-1)+".");  // выводим предложение на экран
                        
                }                
                System.out.println();                                                           // конец абзаца
        }                    
    }

    public static void opThird(String inpText, char c){
        String[] paragraphs = inpText.split("\\s*\n\\s*");                                      // разбиваем текст на абзацы        
        for (String paragraph : paragraphs){ 
                String[] sentences = paragraph.split("\\s*(\\.|!|\\?)\\s*");                    // разбиваем каждый абзац на предложения
                for( String sentence : sentences)  {
                    String[] words = sentence.split(",?\\s+");                                  // разбиваем каждое предложение на слова

                        String[] wordsSort=sortByIncluding(words, c);                           // сортируем слова в предложении по встречаемости символа
                        StringBuilder newSentence = new StringBuilder();
                        for (String word : wordsSort) { newSentence.append(word+" ") ;  }       // Формируем предложение с отсортированными словами
                        System.out.print(newSentence.substring(0, newSentence.length()-1)+".");  // выводим предложение на экран
                }                
                System.out.println();                                           // конец абзаца
        }                    
    }
    //Сортируем массив строк по их длинам
    public static String[] sortItemsLength(String [] strAr){
        int l=strAr.length;
        String[] st = new String[l];
        int[][] strL = new int[l][2];                                           // массив с длинам слов
        for (int i=0; i<l; i++){ strL[i][0]=i; strL[i][1]=strAr[i].length();}   // Создаем массив, где первый элемент номер слова в предложении, второй - его длина
        sortIntAr(strL);                                                        //Сортируем
        for (int i=0; i<l; i++) {  st[i]=strAr[strL[i][0]];   }                 //формируем новый массив отсортированный по длине слов 
        return st;
    }            

    // сортировка массива с длинами строк/кол. вхождений
    public static void sortIntAr(int[][] intAr){                                
        int[] exch= new int[2] ;         
        int l=intAr.length;
        for(int i=0; i<l-1; i++){
            for (int j=0; j<l-i-1; j++){
                if (intAr[j][1]>intAr[j+1][1]) { exch=intAr[j]; intAr[j]=intAr[j+1]; intAr[j+1]=exch;}
            }
        }
    }
    //Сортировка массива строк по количеству въхождений заданного символа
    public static String[] sortByIncluding(String [] strAr, char c){
        int l=strAr.length;
        String[] st = new String[l];
        int[][] incl=countSymb(strAr, c);                                       // создаем массив c количеством вхождений символа в каждое слово        
        sortIntAr(incl);                                                        // сортируем созданный массив по возрастанию
        for (int i=0, j=l-1; i<l; i++, j--) {  st[i]=strAr[incl[j][0]];   }     //формируем новый массив строк, где слова будут распологаться по убыванию колич заданного символа с словах
        int start=0;
        for (int i=1, j=l-2; i<l; i++, j--){                                    //Дополнительно сортируем полученный список слов по алфавиту для слов с одинаковым кол. заданного символоа 
            //System.out.println(incl[j][1]+" - "+incl[j+1][1]);
            if(incl[j][1]!=incl[j+1][1]){     
                //System.out.println("На сортировку позиции "+start+" и "+(i-1));
                sortString(st, start, i-1);
                start=i;
            }            
        }   
        sortString(st, start, l-1);     
        return st;
    } 
    //Сортируем массив строк 
    public static void sortString(String[] strs, int start, int end) {
        int l=end-start;
        String st;
        for(int i=0; i<l; i++){
            for(int j=start; j<(end-i); j++){
                if(strs[j].compareTo(strs[j+1])>0) {
                    st=strs[j]; strs[j]=strs[j+1]; strs[j+1]=st; 
                }
            }
        }        
    }

    // считаем и возвращаем массив с количеством вхождений символа в каждое слово
    public static int[][] countSymb(String[] str, char c){      
        int l = str.length;
        int lWord, qt;
        int[][] qtSymb = new int[l][2];
        for (int i=0; i<l; i++){
            lWord=str[i].length();
            qt=0;
            for(int j=0; j<lWord; j++){
                if (c==str[i].charAt(j)) qt++;
            }
            qtSymb[i][0]=i;
            qtSymb[i][1]=qt;
        }
        return qtSymb;
    }
    
}
