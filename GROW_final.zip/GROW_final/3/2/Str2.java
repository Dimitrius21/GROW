import java.lang.ref.Cleaner;

public class Str2 {
    public static void main(String[] args) {
        String str;
        int res;
        str="ab  cde   fg klmn";
        System.out.println("\nЗадача 1");
        System.out.println(str);
        res=spaseNum(str);
        System.out.println("Наибольшее количество подряд идущих пробелов в строке: "+res);

        str="parametr";
        System.out.println("\nЗадача 2 (вставить 'b' после каждого 'a') ");
        System.out.println(str);
        str=insertB(str);        
        System.out.println(str);

        str="потоп";
        System.out.println("\nЗадача 3 (палиндромом)");
        System.out.print(str);               
        System.out.println(" - палиндром? - "+isPalindrom(str));
        
        str="parametr metoda";
        System.out.println("\nЗадача 5");
        System.out.println(str);               
        res=aCount(str);
        System.out.println("буква “а” встречается в строке: "+res+" раз");

        str="asdfghjk";
        System.out.println("\nЗадача 6 (повторить каждый символ дважды) ");
        System.out.println(str);
        str=doubleCharStr(str); 
        System.out.println(str);

        str="abc cde def ghh hk";
        System.out.println("\nЗадача 7 (удалить все повторяющиеся символы и пробелы)");
        System.out.println(str);
        str=doubleCharDel(str);        
        System.out.println(str);

        str="Найти самое длинное слово и вывести его на экран";
        System.out.println("\nЗадача 8 ");
        System.out.println(str);
        str=longWord(str);
        System.out.println("Cамое длинное слово: "+str);

        str="коЛиЧЕство маЛенЬкиХ и БОЛЬШИх бУкв)";
        System.out.println("\nЗадача 9 (Посчитать количество строчных (маленьких) и прописных (больших) букв)");
        System.out.println(str);
        int[] qt=qtDifChar(str);
        System.out.println("Количество строчных (маленьких) букв: "+qt[0]+", количесвто прописных (больших) букв: "+qt[1]);

        str="Вводится строка слов. Найти самое длинное слово! Случай, когда самых длинных слов может быть несколько, не обрабатывать?";
        System.out.println("\nЗадача 10");  
        System.out.println(str);      
        res=qtSentences(str);
        System.out.println("Количество предложений в строке: "+res);                
    }

    // 1. Дан текст (строка). Найдите наибольшее количество подряд идущих пробелов в нем.
    public static int spaseNum(String str){
        char c;
        int max=0, qt=0, l=str.length();
        boolean pr=false;
        for(int i=0; i<l; i++){
            c=str.charAt(i);
            if (c==' '){
                qt++; pr=true;
            } else {
                if (pr) {
                    if (qt>max) { max=qt; qt=0; }
                    pr=false;
                }
            }
        }
        return max;
    }
    //2. В строке вставить после каждого символа 'a' символ 'b'.
    public static String insertB(String str){
        StringBuilder st = new StringBuilder(str);
        char c;
        int l=str.length(), j=0;                
        for(int i=0; i<l; i++){
            c=st.charAt(j);
            if (c=='a') { j++; st.insert(j, 'b'); }            
            j++;
        }
        return new String(st);
    }
    //3. Проверить, является ли заданное слово палиндромом.
    public static boolean isPalindrom(String str){
        char c1, c2;
        int l=str.length();
        int j=l-1;                        
        for(int i=0; i<l; i++, j--){
            c1=str.charAt(i);   
            c2=str.charAt(j);   
            if (c1!=c2) { return false; }            
        }        
        return true;
    }

    //5. Подсчитать, сколько раз среди символов заданной строки встречается буква “а”.
    public static int aCount(String str){
        char c;
        int qt=0, l=str.length();        
        for(int i=0; i<l; i++){
            c=str.charAt(i);
            if (c=='a') qt++;  
        }
        return qt;
    }
    //6. Из заданной строки получить новую, повторив каждый символ дважды.    
        public static String doubleCharStr(String str){
            char c;
            int l=str.length();        
            char st1[] = new char[l*2];
            for(int i=0; i<l; i++){
                c=str.charAt(i);
                st1[2*i]=c; 
                st1[2*i+1]=c;                 
            }
            return new String(st1);
        }
    //7. Вводится строка. Требуется удалить из нее повторяющиеся символы и все пробелы. 
    //Например, если было введено "abc cde def", то должно быть выведено "abcdef".
    public static String doubleCharDel(String str){
        char c, cLast=' ';
        int l=str.length(), j=0;
        char st1[] = new char[l];
        //boolean pr=false;
        for(int i=0; i<l; i++){
            c=str.charAt(i);
            if (c!=' '){
                if (c!=cLast) {
                    st1[j]=c;
                    j++;
                    cLast=c;
                }
            }            
        }
        return new String(st1,0, j);
    }
    //8. Вводится строка слов, разделенных пробелами. Найти самое длинное слово и вывести его на экран. 
    //Случай, когда самых длинных слов может быть несколько, не обрабатывать.
    public static String longWord(String str){
        char c;
        char[] st1;
        int l=str.length();        
        int pos=0, posEnd=0, posStart=0, qt=0, max=0;
        boolean prSp=false;
        for(int i=0; i<l; i++){
            c=str.charAt(i);
            if (c==' '){
                if (prSp) {
                    prSp=false;
                    if (max<qt) {max=qt; posEnd=i-1; posStart=pos;}
                    qt=0;
                }                           
            } else {
                qt++; 
                if (prSp==false) {pos=i;}
                prSp=true;}            
        }
        st1= new char[posEnd-posStart+1];
        for (int i=posStart, j=0; i<=posEnd; i++, j++) st1[j]=str.charAt(i);
        return new String(st1);
    }
    //9. Посчитать количество строчных (маленьких) и прописных (больших) букв в введенной строке. Учитывать только английские буквы.    
    public static int[] qtDifChar(String str){
        char c;
        int l=str.length();        
        int small=0, big=0;        
        int[] qt = new int[2];
        for(int i=0; i<l; i++){
            c=str.charAt(i);
            if (Character.isLetter(c)){
                if (Character.isLowerCase(c)) small++;
                if (Character.isUpperCase(c)) big++;
            }            
        }
        qt[0]=small; qt[1]=big;
        return qt;
    }   
    //10. Строка X состоит из нескольких предложений, каждое из которых кончается точкой, восклицательным или вопросительным знаком. 
    // Определить количество предложений в строке X.
    public static int qtSentences(String str){
        char c;
        int l=str.length();        
        int qt=0;        
        boolean pr=true;                            // Для контроля идущих подряд нескольких знаков 
        for(int i=0; i<l; i++){
            c=str.charAt(i);
            if (c=='.' || c=='!' || c=='?') {
                if(pr) { qt++; pr=false;}
            } else pr=true;                                    
        }        
        return qt;
    }
}
