import java.util.Arrays;

public class Str {
    public static void main(String[] args) {
        String[] arStr = {"camelCaseStr", "helloMyWorld","itIsNotArgum"};
        int k;
        String st1, str;
                
        System.out.println("\n Задача 1");
        for (int j=0; j<arStr.length; j++ ){
            System.out.println(arStr[j]);
            str=transformToShake(arStr[j]);
            System.out.println(str);
            arStr[j]=str;
        }

        System.out.println("\n Задача 2");
        str="This is word. The word means simple a word.";
        String t="word";
        String r="letter";
        str=strReplace(str, t, r);
        System.out.println(str);
       
        System.out.println("\n Задача 3");
        st1="12 июня 2021 было сыграно 3 игры на Евро-2020";
        k=numOfDigit(st1);
        System.out.println(" В строке \""+st1+" "+k+" цифр");

        System.out.println("\n Задача 4");
        k=numOfNumber(st1);
        System.out.println(" В строке \""+st1+" "+k+" чисел");

        System.out.println("\n Задача 5");
        st1="  12 июня 2021 было     сыграно 3 игры на  Евро-2020  ";
        System.out.println(st1);
        st1=spaseEr(st1);
        System.out.print(st1);
        System.out.print("ШШ");                                 // для контроля конца строки, что нет пробелов.
    }

    //1. Дан массив названий переменных в camelCase. Преобразовать названия в snake_case.
    public static String transformToShake(String str){
        //String strNew;
        char c;
        char[] st1=str.toCharArray(); 
        int qt=0, l, k;
        l=st1.length;
        for(int i=1; i<l; i++){                // находим количество больших букв
            if (Character.isUpperCase(st1[i])) qt++;
        }
        st1=Arrays.copyOf(st1, l+qt); 
        k=l+qt-1;
        l--;
        for(int i=1; i<=qt; i++ ) {
            while(true){                
                if (Character.isUpperCase(st1[l])) {    // Если буква большая, преобразуем в маленькую, переносим, вставляем символ '_'
                    c=Character.toLowerCase(st1[l]);
                    st1[k]=c;
                    k--;
                    st1[k]='_';
                    k--;
                    l--;
                    break;
                } else {
                        st1[k]=st1[l];                  // если нет, просто копируем
                        k--; l--;
                    }
            }
        } 
        return new String(st1);
    } 
    // Вариант 2
    public static void transformToShake2(String str){   
            char c1, c2;
            String st1;
            int l=str.length();
            for(int i=0; i<l; i++){
                c1=str.charAt(i);
                if (Character.isUpperCase(c1)) {
                    c2=Character.toLowerCase(c1);
                    st1="_"+c2;
                    str=str.replace(Character.toString(c1), st1);                
                }    
            }
    }
    //2. Замените в строке все вхождения 'word' на 'letter'
    public static String strReplace(String str,String t, String r){
        char c;
        char[] strNew;
        char[] st1 = t.toCharArray();
        int[] pos = new int[100];
        int l=str.length();
        int l1=t.length();
        int l2=r.length();
        boolean prB=false;
        int k, m, qt=0, j=0; 
        for (int i=0; i<l; i++){            // ищем совпадения
            c=str.charAt(i);
            if (c==st1[j]) { 
                j=1; prB=true; k=i;               
                i++; 
                while(j<l1){
                    if(i>=l) {prB=false; break;}
                    c=str.charAt(i);
                    if (c!=st1[j]) {prB=false; break;}
                    i++;j++;
                }
                if (prB) { 
                    pos[qt]=k;                  // Сохранить позцию начала заменяемой подстроки
                    qt++; i--; j=0;
                }                
            }
            j=0;
        }
        if (qt==0) return str;
        int lNew=(l2-l1)*qt+l;                                              // определяем новую длину строки
        strNew= new char[lNew];
        if (l2-l1>=0){                                                      // Если новая подстрока длинее заменяемой или такая же             
            lNew--; l--;                                                    // устанавляиваем указатели на конец первоначальной и новой строки
            for (k=qt-1; k>=0; k--){                            
                j=pos[k]+l1;                                               //сдвигаем в сторону конца
                while( l>=j){                 
                    strNew[lNew]=str.charAt(l); 
                    lNew--; l--;
                }        
                for(int i=l2-1; i>=0; i--) {                                   // вставляем новую подстроку                    
                    strNew[lNew]=r.charAt(i);;                    
                    lNew--;
                }
                l=pos[k]-1;                
            }             
            if (pos[0]>0) {
                while( l>=0){ strNew[lNew]=str.charAt(l);                   //сдвигаем в сторону конца все что перед первой заменой   
                              lNew--; l--;}                     
            }                 
        } else {                                                            // если исходная подстрока короче заменяемой новой
                lNew=0; m=0;                                                // lNew - индекс по новой созданной строке, m - по исходной
                for (k=0; k<qt; k++){
                    j=pos[k]; 
                    while( m<j){                                            // переносим все что до очередной найденной подстроки 
                        strNew[lNew]=str.charAt(m); 
                        lNew++; m++;
                    }   
                    for(int i=0; i<l2; i++) {                                   // вставляем новую подстроку                    
                        strNew[lNew]=r.charAt(i);;                    
                        lNew++;
                    }
                    m=pos[k]+l1;
                }
                while( m<l){ strNew[lNew]=str.charAt(m);                   //присоединяем остаткок после последней заменяемой подстроки   
                             lNew++; m++;}                                     
        }
        return new String(strNew);
    }

    // 3. В строке найти количество цифр.
    public static int numOfDigit(String str){
        int l=str.length();
        int qt=0;
        char c;
        for(int i=0; i<l; i++){
            c=str.charAt(i);
            if (Character.isDigit(c)) qt++;             
        }       
        return qt;
    }
//    4. В строке найти количество чисел.
    public static int numOfNumber(String str){
        int l=str.length();
        int qt=0;
        boolean pr=true;
        char c;
        for(int i=0; i<l; i++){
            c=str.charAt(i);
            if (Character.isDigit(c)) { 
                if (pr) { qt++; pr=false; }
            } else pr=true;
        }       
        return qt;
    }
// 5. Удалить в строке все лишние пробелы, то есть серии подряд идущих пробелов заменить на одиночные пробелы. Крайние пробелы в строке удалить.
    public static String spaseEr(String str){
        String strNew;
        char[] st1=str.toCharArray();             // из строки делаем массив символов
        int start=0, end=st1.length, j=0; 
        char[] st2= new char[end];
        char c;
        boolean pr=true;    
        while(true){                        //выбираем начальные пробелы
            c=str.charAt(start);
            if (c==' ' ) start++;
             else break; 
        }
        end--;
        while(true){                        //выбираем конечные пробелы
            c=str.charAt(end);
            if (c==' ') end--;
             else break; 
        }
        for(int i=start; i<=end; i++){
            c=str.charAt(i);
            if (c!=' ') { st2[j]=c; j++; pr=true; }
             else { 
                 if (pr) { st2[j]=c; j++; pr=false;  }                     
                  }                  
        }
        strNew=new String(st2, 0, j);                 
        return strNew;
    }
}
