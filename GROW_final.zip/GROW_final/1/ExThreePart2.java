import java.util.ArrayList;
import java.util.Scanner;
 
public class ExThreePart2 {
   
    public static void main(String[] args) {
        System.out.println("Task 3.7");
        deliteli();
        System.out.println("Task 3.8");
        is(19275,675189);
    }
        //7. Для каждого натурального числа в промежутке от m до n вывести все делители, кроме единицы и самого числа.
    public static void deliteli() {
        ArrayList<String> l = new ArrayList<String>();
        Scanner in = new Scanner(System.in);
        System.out.print("Input first number: ");
        int m = in.nextInt();
        System.out.print("Input second number: ");
        int n = in.nextInt();
        for (int i=m; i<=n; i++){
            for (int j=2; j<i; j++){                         // ищем все делители и заносим в список l
                if (i%j ==0) { l.add(""+j);}
            }
        System.out.println("Все делители для "+i);
        for (String s : l){ System.out.print(s+" ");  }   //вывести результат
        System.out.println();
        l.clear();                                            // очищаем список 
        }
        in.close();
    }
            //8. Даны два числа. Определить цифры, входящие в запись как первого так и второго числа.
    public static void is (int a, int b){
        ArrayList<String> l1 = new ArrayList<String>();
        ArrayList<String> l2 = new ArrayList<String>();
        ArrayList<String> l3, l4;
        ArrayList<String> l_res = new ArrayList<String>();
        int x;
        while (true) {                   // Разбиваем первое число на символы
            x=a%10;      
            l1.add((""+x));
            a=Math.floorDiv(a, 10);
            if (a==0) break;         
        }
        while (true) {                   // Разбиваем второе число на символы
            x=b%10;
            l2.add((""+x));
            b=Math.floorDiv(b, 10);
            if (b==0) break;         
        }
            if (l1.size()<l2.size()) { l3=l1; l4=l2; }   // Находим меньший по размеру список
             else { l3=l2; l4=l1; }
            
            for (String s : l3) {                        // ищем совпадающие символы
                if (l4.contains(s)) { l_res.add(s); }
            }
            for (String s : l_res){ System.out.print(s+" ");  }   //вывести результат
    }    
}
    