public class ExTwo {
    public static void main (String[] args){
        c1();
        System.out.println(c2(8,5,4,6));
        isOnLine(0,0,5,5,10,10);
    } 
    // 1. Даны два угла треугольника (в градусах). Определить, существует ли такой треугольник, и если да, то будет ли он прямоугольным.
    public static void c1(){
        int ang1=30;
        int ang2=90;
       
        if (ang1+ang2>=180) { 
           System.out.println("Triangle does not exist"); }
         else { 
            System.out.println("Triangle exists");
            if ((ang1==90) || (ang2==90)) { System.out.println("Triangle is rectangular"); }
             else { System.out.println("Triangle is not rectangular"); }
        }
    }
    // 2. Найти max{min(a, b), min(c, d)}.
    public static int c2(int a, int b, int c, int d){     //max{min(a, b), min(c, d)}.
        int min1 = a;
        int min2;
        if (a>b) { min1=b; }
        min2 = c>d ? d : c;
        if (min1>min2) return min1;
         else return min2;                 
    }
    // 3. Даны три точки А(х1,у1), В(х2,у2) и С(х3,у3). Определить, будут ли они расположены на одной прямой.
    public static boolean isOnLine(int x1, int y1, int x2, int y2, int x3, int y3){     // 3 точки
        double k=(y2-y1)/(x2-x1);
        double b=y1-k*x1;
        double y=k*x3+b;
        if (Math.abs(y3-y)<0.0001) { System.out.println("Point on a line"); return true; }
         else { System.out.println("Point is not on one line");  return false; }
    }
    // 4. Заданы размеры А, В прямоугольного отверстия и размеры х, у, z кирпича. Определить, пройдет ли кирпич через отверстие.
    public static boolean c4(int A, int B, int x, int y, int z){
      if ((x<A) && (y<B)) return true; 
        return false;    
    }
    
    //5. Вычислить значение функции:
    public static double c5(double x){   
        if (x<=3)  return x*x-3*x+9; 
         else return 1/(Math.pow(x,3)+6); 
    }
}

