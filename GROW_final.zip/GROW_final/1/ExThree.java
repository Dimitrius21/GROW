import java.util.Scanner;
public class ExThree {
    private static Scanner in; 
    public static void main(String[] args) {
        in = new Scanner(System.in);
        System.out.println("Task 3.1");
        sum();
        System.out.println("Task 3.2");
        func(-5,20,3);
        System.out.println("Task 3.3");
        sumOf2();
        System.out.println("Task 3.4");
        mult();
        System.out.println("Task 3.6"); 
        numOfChar();
        in.close();
    }

    // 1. Напишите программу, где пользователь вводит любое целое положительное число. 
    // А программа суммирует все числа от 1 до введенного пользователем числа.        
    public static int sum() {   
        //Scanner in = new Scanner(System.in);
        int x;
        int res=0;
        System.out.print("Input a number : ");
        x=in.nextInt();
        for (int i=0; i<x; i++) {
            res+=i;
        }
        System.out.println("Сумма чисел равна : "+res);
        //in.close();
        return res;
    }
        //2. Вычислить значения функции на отрезке [а,b] c шагом h:
    public static void func(int a, int b, int h){   
        for (int i=a; i<=b; i+=h) {
            System.out.print("For "+i+" value= ");
            if (i>2) System.out.println(i);
             else System.out.println(-i);
        }
    }     
        // 3. Найти сумму квадратов первых ста чисел.
    public static void sumOf2(){   
        long res=0;
        for (int i=0; i<=100; i++) {
            res+=i*i;    // res+=Math.pow(i,2)
        }
        System.out.println("Сумма квадратов первых ста чисел = "+res);
    }
        // 4. Составить программу нахождения произведения квадратов первых двухсот чисел.
    public static void mult(){   
        double res=1;
        for (int i=1; i<=20; i++) {       // выходим за рамки диапазона double. Конечно можно использовать из пакет BigInteger и BigDecimal но и там не факт что 200 посчитаем
            res*=Math.pow(i,2);
            //System.out.println(res);
        }
        System.out.println("Произведение квадратов первых двухсот чисел = "+res);
    }
        //6. Вывести на экран соответствий между символами и их численными обозначениями в памяти компьютера.
    public static void numOfChar(){
        while (true) {
          System.out.print("Input symbol (1 - for exit): ");
          String st = in.nextLine();
          if (st.isEmpty()) continue;
          char c = st.charAt(0);
          System.out.printf(" Decimal : %d, Hex : %h \n", (int)c, (int)c );
          if (c=='1') break;            // Для выхода из цикла и значения
        }        
    }   


}
