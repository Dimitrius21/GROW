public class ExOne {
        public static void main(String[] args){
        l1();
        l2();
        l3();
        l4();
        l5();
        l6();
    }
    // 1. Найдите значение функции: z = ( (a – 3 ) * b / 2) + c.
    public static void l1(){
        double a=4;
        double b=2;
        double c=1;
        double z=((a-3)*b/2)+c;
        System.out.println("z= "+z);
    }
    //2. Вычислить значение выражения по формуле (все переменные принимают действительные значения): (𝑏+√𝑏2+4𝑎𝑐)/2𝑎−𝑎3𝑐+𝑏−2
    public static void l2(){
        double a=1;
        double b=3;
        double c=4;
        double z;
        z=(b+Math.sqrt(Math.pow(b,2)+4*a*c))/2*a-Math.pow(a,3)*c+Math.pow(b,-2);   
        System.out.println("z= "+z);
    }
    // 3. Вычислить значение выражения по формуле (все переменные принимают действительные значения): (𝑠𝑖𝑛𝑥+𝑐𝑜𝑠𝑦)/(𝑐𝑜𝑠𝑥−𝑠𝑖𝑛𝑦)∗𝑡𝑔 𝑥𝑦
    public static void l3(){
        double x=0;
        double y=90;
        double z=(Math.sin(x)+Math.cos(y))/(Math.cos(x)-Math.sin(y))*Math.tan(x*y);
        System.out.println("z= "+z);
    }
    //4. Дано действительное число R вида nnn.ddd (три цифровых разряда в дробной и целой частях). 
    //Поменять местами дробную и целую части числа и вывести полученное значение числа.
    public static void l4(){
        double a=111.333;
        int n, d;
        n=(int) Math.floor(a);
        d=(int) Math.ceil((a-n)*1000);
        System.out.println(a);
        System.out.println(d+"."+n);

    }
    //5. Дано натуральное число Т, которое представляет длительность прошедшего времени в секундах. 
    // Вывести данное значение длительности в часах, минутах и секундах в следующей форме:
    // ННч ММмин SSc.
    public static void l5() {
        int t, h, m, s;
        t=3665;

        h=(int) Math.floor(t/3600);
        s=h*3600;
        m=(int) Math.floor((t-s)/60);
        s=t-s-m*60;
        System.out.println(h+"h "+m+"min "+s+"s");
    }
    // 6. Для данной области составить линейную программу, которая печатает true, если точка с координатами (х, у) принадлежит закрашенной области, 
    //    и false — в противном случае:
    public static void l6(){
        int pointX = 1;
        int pointY = -1;
        boolean x, y, res;
        
        y=((pointY<4) && (pointY>=0)) && ((pointX<2) && (pointY>-2));
        x=((pointY<0) && (pointY>=-3)) && ((pointX<4) && (pointY>-4));
        res=x || y;
        System.out.println(res);
    }
}
