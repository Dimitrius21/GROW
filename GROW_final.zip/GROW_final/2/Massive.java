public class Massive{
     public static void main(String[] args) {
        int[] ar1 = {-1,-2,-3,0,1,2,3,4,5,6,7,8,9,0};             // для задач 2, 3
        int[] ar2 = {-1,-2,-3,0,1,2,3,11,5,15,7,8,9,0};           // для задач 4, 5
        int[] ar4 = {3, 5, 2, 15, 2, 8, 2, 5, 9, 5 };             // для задач 1,8,9,10
        double[] ar3 = {1.5, 2.33, 3.65, 4.78, 5.21, 6.93, 7.45, 8.14, 9.67};  // для задачи 6
        
        System.out.println("Task 1");
        System.out.println(sum1(ar4, 3));
        System.out.println("Task 2");
        changeZ(ar1, 5);
        System.out.println("Task 3");
        countNumber(ar1);
        System.out.println("Task 4");
        changeMinMax(ar2);
        System.out.println("Task 5");
        printAi(ar2);
        System.out.println("Task 6");
        sum2(ar3);
        System.out.println("Task 8");
        seqCut(ar4);
        System.out.println("Task 9");
        System.out.println(maxFreq(ar4));
        System.out.println("Task 10");
        reduceAr(ar4);
    }

        //1. В массив A [N] занесены натуральные числа. Найти сумму тех элементов, которые кратны данному К.
    public static int sum1(int[] ar, int K){
        int res=0;
        for(int el : ar) {
            if (el%K == 0) {res+=el;}
        }
        return res; 
    }
    // 2. Дана последовательность действительных чисел а1 ,а2 ,..., ап. Заменить все ее члены, большие данного Z, этим числом. Подсчитать количество замен.
    public static int changeZ(int[] ar, int Z){
        int i=0;
        for(int j=0; j<ar.length; j++) {
            if (ar[j] > Z ) {
                ar[j]=Z;
                i++;
             }
        }
        for(int el : ar) System.out.print(el+" ");
        System.out.println();
        System.out.println("Количество сделанных замен : "+i);    //Выводим кличество замен
        return i;
    }
    //3. Дан массив действительных чисел, размерность которого N. Подсчитать, сколько в нем отрицательных, положительных и нулевых элементов.
    public static void countNumber(int[] ar){
        int pos=0;
        int neg=0;
        int nol=0;
        for(int i=0; i<ar.length; i++) {
            if (ar[i] > 0 ) { pos++;}
            else if (ar[i] < 0 ) { neg++;}
                   else nol++;                
             }
             System.out.print("Кол.отрицательных чисел : "+neg+" кол.положительных чисел : "+pos+" кол.нулевых элементов :"+nol);     
        }
        //4. Даны действительные числа а1 ,а2 ,..., аn . Поменять местами наибольший и наименьший элементы.
    public static void changeMinMax(int[] ar){
        int minInd=0;
        int maxInd=0;
        int min=ar[0];
        int max=ar[0];
        System.out.println();
        for (int el : ar) System.out.print(" "+el);
        for(int i=1; i<ar.length; i++) {
            if (min>ar[i]) { min=ar[i]; minInd=i;}
            if (max<ar[i]) { max=ar[i]; maxInd=i;}
        }        
        ar[maxInd]=min;
        ar[minInd]=max;        
        System.out.println();
        System.out.println("измененный массив");
        for (int el : ar) System.out.print(" "+el);        
    }
    // 5. Даны целые числа а1 ,а2 ,..., аn . Вывести на печать только те числа, для которых аi > i.
    public static void printAi(int[] ar){
        for(int i=1; i<ar.length; i++) {
            if (ar[i]>i) System.out.print(ar[i]+", ");
        }
        System.out.println();        
    }
    // 6. Задана последовательность N вещественных чисел. Вычислить сумму чисел, порядковые номера которых являются простыми числами.
    public static void sum2(double[] ar){
        double res=0;
        for(int i=2; i<ar.length; i++) {
            if (simpleNum(i)) { res+=ar[i-1]; }
        }
        System.out.println();        
        System.out.println(res);        
    }
    public static boolean simpleNum(int x){   // метод, определяет является ли число простым - возвращает true or false
        for(int j=2; j<x; j++){
            if (x%j ==0) return false;
        }
        return true;
    }    
    // 8. Дана последовательность целых чисел n. Образовать новую последовательность, выбросив из исходной те члены, которые равны min( , , , ) .
    public static int[] seqCut(int[] ar){
        int min=ar[0];
        for (int el : ar) { if (min>el) min=el; }  // Находим минимальный элемент
        int col=0;
        for (int el : ar) {if (min==el) col++; }   //Находим количество минимальных эелементов
        int l=ar.length-col;                       // определяем длину нового массива     
        int[] arNew = new int[l];
        int j=0;
        for (int i=0; i<ar.length; i++){           // копируем элементы в новый массив согласно условия
            if (ar[i]!=min) {arNew[j]=ar[i]; j++;}
        }
        System.out.println("First array");
        for (int el : ar) {System.out.print(el+", ");}
        System.out.println();
        System.out.println("Second array");
        for (int el : arNew) {System.out.print(el+", ");}
        System.out.println();
        return arNew;
    }
    // 9. В массиве целых чисел с кол. элем. n найти наиболее часто встречающееся число. Если таких чисел несколько, то определить наименьшее из них.
    public static int maxFreq(int[] ar){
        int a, col, max=0;                       // a - наиболее часто встречающееся число, max - кол.такого числа
        a= ar[0]!=0 ? 0 : 1;
        for(int i=0; i<ar.length; i++){
            if (ar[i]==a) continue;         // если проверяемое число равно наиб.часто встреч., пропускаем итерацию проверки 
            col=1;
            for(int j=i+1; j<ar.length; j++){
                if (ar[j]==ar[i]) { col++; }               //находим сколько встречается данный элемент 
            }
            if (col>max) {a=ar[i]; max=col;}
             else if (col==max && ar[i]<a) {a=ar[i]; }        // если частота тек.эл = ранее определенному, смотрим наименьшее значение
        }        
        return a;
    }
    // 10. Дан целочисленный массив с количеством элементов п. Сжать массив, выбросив из него каждый второй элемент (освободившиеся элементы заполнить нулями).
    public static void reduceAr(int[] ar){
        int i;
        int l=(int)Math.ceil(ar.length/2)-1;   // определяем количество замен
        for(i=1; i<=l; i++){
            ar[i]=ar[i*2];
        }
        for(int j=i; j<ar.length; j++){
            ar[j]=0;
        }
        for (int el : ar) {System.out.print(el+", ");}
    }
}    
