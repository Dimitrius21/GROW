import java.util.Arrays;

public class ArSort {
    public static void main(String[] args) {
        int[] ar1, ar2;
        int k;

        System.out.println("\n Задача 1");
        ar1=arrayGen(6, 0, 50);
        showAr(ar1);
        ar2=arrayGen(6, 0, 50);
        showAr(ar2);
        ar1=arUnion(ar1,ar2, 3);
        showAr(ar1);

        System.out.println("\n Задача 2");
        ar1=(arrayGen(5, 0, 50));
        sort(ar1);
        showAr(ar1);
        ar2=arrayGen(5, 0, 50);
        sort(ar2);
        showAr(ar2);
        ar1=arUnion2(ar1,ar2);
        showAr(ar1);

        System.out.println("\n Задача 3");
        ar1=arrayGen(10, 0, 100);
        showAr(ar1);
        sort(ar1);       
        showAr(ar1);  

        System.out.println("\n Задача 4");
        ar1=arrayGen(10, 0, 100);
        showAr(ar1);
        k=sortEx(ar1);   
        showAr(ar1);
        System.out.println("\nКоличество замен : "+k);

        System.out.println("\n Задача 5");
        ar1=arrayGen(10, 0, 100);
        showAr(ar1);
        sortIns(ar1);       
        showAr(ar1);  
        
        System.out.println("\n Задача 6");
        ar1=arrayGen(10, 0, 100);
        showAr(ar1);
        sortShella(ar1);       
        showAr(ar1);    
        
        System.out.println("\n Задача 7");
        ar1=arrayGen(8, 0, 50);
        sortEx(ar1);
        showAr(ar1);
        ar2=arrayGen(8, 0, 50);
        sortShella(ar2);
        showAr(ar2);
        posIndicate(ar1, ar2);        
    }

    public static int[] arrayGen(int n, int min, int max){    //вспомогательная функция для генерации произвольного массива целых чисел 
        int[] ar=new int[n];                                       // диапазон от min до max
        int x=max-min+1;
        for(int i=0; i<n; i++){ ar[i]=(int) Math.floor(Math.random()*x)+min; }                       
        return ar;
    }
    public static void showAr(int[] ar){               //  вспомогательная функция для вывода массива целых чисел        
        System.out.println();
        for (int Ai : ar) System.out.print(Ai+", "); 
    }    
//1. Заданы 2 одномерных массива с разл. кол. элеме. и натур. число k. Объединить их в один массив, включив второй массив между k-м и (k+1) - м элем. первого
    public static int[] arUnion(int[] ar1, int[] ar2, int k){
        int l1=ar1.length; 
        int l2=ar2.length;        
        ar1=Arrays.copyOf(ar1, ar1.length+l2);
        for (int i=k+1; i<l1; i++){ ar1[i+l2]=ar1[i]; }
        for (int i=0; i<l2; i++){ ar1[k+1+i]=ar2[i]; }
        return ar1;
    }
//2. Даны две последовательности a1<=a2...<=an и b1<=b2...<=bm Образовать из них новую последовательность чисел так, чтобы она тоже была неубывающей.
    public static int[] arUnion2(int[] ar1, int[] ar2){
        int k=ar1.length;
        ar1=arUnion(ar1,ar2,k-1);
        sort(ar1);
        return ar1;
    }
//3. Сортировка массива выбором 
    public static void asort(int[] ar){               //  функция для сортировки массива по убыванию
        int l=ar.length;
        int max, index;
        for(int i=0; i<l; i++){
            max=ar[i]; index=i;
            for(int j=i+1; j<l; j++){
                if (ar[j]>max) {max=ar[j]; index=j;}
            }
            ar[index]=ar[i];
            ar[i]=max;
        }
    }  
    public static void sort(int[] ar){               //   функция для сортировки массива по возростанию
        int l=ar.length;
        int min, index;
        for(int i=0; i<l; i++){
            min=ar[i]; index=i;
            for(int j=i+1; j<l; j++){
                if (ar[j]<min) { min=ar[j]; index=j;}
            }
            ar[index]=ar[i];
            ar[i]=min; 
        }
    }  

//4. Сортировка массива обменом ("пузырек")
    public static int sortEx(int[] ar){               //  функция для сортировки массива по возростанию
        int l=ar.length;
        int eX, qt=0;
        for(int i=0; i<l; i++){
            for(int j=0; j<l-i-1; j++){
                if (ar[j]>ar[j+1]) { 
                    eX=ar[j+1]; ar[j+1]=ar[j]; ar[j]=eX; 
                    qt++;
                }
            }
            //showAr(ar);
        }
        return qt; 
    }

// 5. Сортировка вставками.
/* Двоичный поиск
Идея поиска заключается в том, чтобы брать элемент посередине, между границами, и сравнивать его с искомым. 
Если искомое больше(в случае правостороннего — не меньше), чем элемент сравнения, то сужаем область поиска так, 
чтобы новая левая граница была равна индексу середины предыдущей области. В противном случае присваиваем это значение правой границе. 
Проделываем эту процедуру до тех пор, пока правая граница больше левой более чем на 1. */
    public static int binSearch(int[] ar, int ln, int key){   
        int m, l=-1;                      // l, r — левая и правая границы
        int r=ln;  //ar.length;    
        while (l < r-1){                
            m = (int) Math.ceil((l+r)/2);                 // m — середина области поиска
            if (ar[m]<key)
                l = m;                   // Сужение границ
            else 
                r = m;                  
        }
        return r;
    }
    public static void sortIns(int[] ar){
        int j, s;
        if (ar[1]<ar[0]){ s=ar[0];ar[0]=ar[1];ar[1]=s; }   //формируем возрастающую последовательность для первых двух элементов 
        for(int i=2; i<ar.length; i++){
            if (ar[i]<ar[i-1]) {                    //если анализируемый элемент больше/равно стоящего перед ним, ничего делать не надо
                j=binSearch(ar, i, ar[i]);          // находим индекс куда вставлять очередной элемент
                s=ar[i];                            // сохраняем очередной элемент -  который анализируем
                for(int k=i; k>j; k--){             //сдвигаем элементы массива на одну позицию начиная с найденного индекса
                    ar[k]=ar[k-1];  
                }
                ar[j]=s;                            // помещаем в ячейку с найденным индексом сохраненный элемент ()
            }
        }
    }
//6. Сортировка Шелла.
    public static void sortShella(int[] ar){
        int i, s;
        int l=ar.length-1;
        i=0;
        while (i<l){
            if (ar[i]<=ar[i+1]) { i++; }
             else {
                s=ar[i];ar[i]=ar[i+1];ar[i+1]=s;
                i--;
                if (i<0) i=0;
                //showAr(ar);
             }
        }
    }
/* 7. Пусть даны две неубывающие последовательности действительных чисел A1<=A2<=...<=An и B1<=B2<=...<=Bm.
   Требуется указать те места, на которые нужно вставлять элементы последовательности B1<=B2<=...<=Bm в первую
   последовательность так, чтобы новая последовательность оставалась возрастающей. 
   ---
   "Использованием Двоичного поиска находятся места для вставок. Но если между Ai и Ai+1 вставляются несколько элементов Bi 
   то непонятно, как считать эти позиции. 
   */
    public static void posIndicate(int[] ar1,int[] ar2){
        int k, i=0; 
        int l2=ar2.length; 
        int l1=ar1.length;
        System.out.println("\nМеста для вставки :");
        while (i<l2){
            if (ar2[i]>=ar1[l1-1]) { break;}
         else {
            k=binSearch(ar1, l1, ar2[i]);
            System.out.println("Место для вставки B["+i+"]="+ar2[i]+" в массиве A - "+k);
            i++;            
         }
        } 
        if (i<l2) System.out.println("Элементы с B["+i+"] будут вставляться после последнего элемента Ai");
    }
}
    