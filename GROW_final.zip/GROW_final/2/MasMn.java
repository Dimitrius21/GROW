import java.util.Scanner;
public class MasMn {
    public static void main(String[] args) {
        int[][] ar4=null;    
        double[][] ar5=null;    
        int[][] ar1 = {{11,21,31,41},{12,22,32,42},{13,23,33,43},{14,24,34,44}};
        
        System.out.println("\n Задача 1");
        ar4=matrixGen(5,8,0,100);           //формируем матрицу 5х8 с элементами - целыми числами от 0-100
        showAr(ar4);                        //отображаем исходную матрицу
        showCol(ar4);                       // выполняем задачу с матрицей  

        System.out.println("\n Задача 2");
        showD(ar1);                           // выполняем задачу с матрицей  

        System.out.println("\n Задача 3");
        ar4=matrixGen(6,8,0,100);           //формируем матрицу 5х8 с элементами - целыми числами от 0-100
        showAr(ar4);                        //отображаем исходную матрицу
        showLC(ar4, 3, 2);                  // выполняем задачу с матрицей  

        System.out.println("\n Задача 4");
        ar4=makeArN(6);                         // формируем матрицу согласно задачи
        showAr(ar4);                            //отображаем сформированную матрицу
        
        System.out.println("\n Задача 5");
        ar4=makeArN2(8);
        showAr(ar4);
        
        System.out.println("\n Задача 6");
        ar4=makeArN3(8);                        
        showAr(ar4);

        System.out.println("\n Задача 7");
        ar5=makeArN4(8);                        // формируем матрицу согласно задачи
        showArF(ar5, 4);                        //отображаем сформированную матрицу,  4-кол цифр после запятой при отображении

        System.out.println("\n Задача 8");
        ar4=matrixGen(7,8,0,100);                //формируем матрицу 7х8 с элементами - целыми числами от 0-100
        showAr(ar4);                             //отображаем исходную матрицу
        changeCl(ar4);                           // выполняем задачу с матрицей  
        showAr(ar4);                             // отображаем измененную матрицу

        System.out.println("\n Задача 9");
        ar4=matrixGen(5,8,0,100);
        showAr(ar4);       
        colSum(ar4);

        System.out.println("\n Задача 10");
        ar4=matrixGen(8,8,0,100);                   //формируем квадратную матрицу 8х8 с элементами - целыми числами от 0-100
        showAr(ar4);                                //отображаем исходную матрицу
        positivElem(ar4);                           // выполняем задачу с матрицей  
        
        System.out.println("\n Задача 11");
        Ex11();                                     // Все части задачи внутри метода

        System.out.println("\n Задача 12");
        ar4=matrixGen(6,8,0,100);                   //формируем матрицу 6х8 с элементами - целыми числами от 0-100
        sortMatrStr(ar4);                           // сортировка по элементам строк

        System.out.println("\n Задача 13");
        ar4=matrixGen(6,8,0,100);
        showAr(ar4);
        sortMatrStr(ar4);
        System.out.println("\n Сортировка по возрастанию значений в столбце");
        sortMatrCol(ar4);
        showAr(ar4);
        System.out.println("\n Сортировка по убыванию значений в столбце");
        asortMatrCol(ar4);
        showAr(ar4);
        
        System.out.println("\n Задача 14");       // желательно чтобы число строк было больше и равно числа столбцов иначе у части столбцов будут все 1
        ar4=matrixGen10(9, 8);                     
        showAr(ar4);

        System.out.println("\n Задача 15");
        ar4=matrixGen(6,8,0,100);
        replaceMax(ar4);
        showAr(ar4);

    }
    public static void sort(int[] ar){               //  вспомогательная функция для сортировки массива по возростанию
        int l=ar.length;
        int min, index;
        for(int i=0; i<l; i++){
            min=ar[i]; index=i;
            for(int j=i+1; j<l; j++){
                if (ar[j]<min) { min=ar[j]; index=j;}
            }
            ar[index]=ar[i];
            ar[i]=min; 
        }
    }  
    public static void asort(int[] ar){               //  вспомогательная функция для сортировки массива по убыванию
        int l=ar.length;
        int max, index;
        for(int i=0; i<l; i++){
            max=ar[i]; index=i;
            for(int j=i+1; j<l; j++){
                if (ar[j]>max) {max=ar[j]; index=j;}
            }
            ar[index]=ar[i];
            ar[i]=max;
        }
    }  
    public static int[][] matrixGen(int m, int n, int min, int max){    //вспомогательная функция для генерации произвольной матрицы 
        int[][] ar=new int[m][n];                                       // m-число строк, n - число столбцов, диапазон от min до max
        int x=max-min+1;
        for(int i=0; i<m; i++){
            for(int j=0; j<n; j++){
                ar[i][j]=(int) Math.floor(Math.random()*x)+min;
             }              
        } 
        return ar;
    }

    public static void showAr(int[][] ar){               //  вспомогательная функция для вывода матрицы целых чисел
        int l_col=ar[0].length;
        int l_str=ar.length;
        System.out.println();
        for(int i=0; i<l_str; i++){
            for(int j=0; j<l_col; j++){ System.out.print(ar[i][j]+" "); }  
            System.out.println();
        }
    }    
    public static void showArF(double[][] ar, int n){     //  вспомогательная функция для вывода матрицы вещественных чисел, n - кол после запятой
        int l_col=ar[0].length;
        int l_str=ar.length;
        String st="%."+n+"f ";
        System.out.println();
        for(int i=0; i<l_str; i++){
            for(int j=0; j<l_col; j++){ System.out.printf (st, ar[i][j]); }  
            System.out.println();
        }
    }    

    // 1. Дана матрица. Вывести на экран все нечетные столбцы, у которых первый элемент больше последнего.
    public static void showCol(int[][] ar){
        int l_col=ar[0].length;
        int l_str=ar.length;
        int[] prisn = new int[(l_col)];
        for (int i=1; i<l_col; i+=2){               // формируем массив признаков, подлежит ли столбец отображению
            if (ar[0][i]>ar[l_str-1][i]) prisn[i]=1;
        }
        System.out.println();
        for(int i=0; i<l_str; i++){                //выводим столбцы, соответствующие условию
            for(int j=1; j<l_col; j+=2){ 
                if (prisn[j]==1) System.out.print(ar[i][j]+" "); 
            }  
            System.out.println();
        }
    }
    // 2. Дана квадратная матрица. Вывести на экран элементы, стоящие на диагонали.
    public static void showD(int[][] ar){
        int l=ar[0].length; 
        for (int i=0; i<l; i++){
            System.out.print(ar[i][i]+", ");
        }
    }
    // 3. Дана матрица. Вывести k-ю строку и p-й столбец матрицы.
    public static void showLC(int[][] ar, int k, int p){
        int l_col=ar[0].length;
        int l_str=ar.length;

        //  System.out.println("string:"+l_col+"column: "+l_str);
        System.out.print("string "+k+": ");
        for (int i=0; i<l_col; i++){                  // выводим k-ю строку
            System.out.print(ar[k][i]+", "); }
        System.out.print("\nColumn "+p+": ");
        for (int i=0; i<l_str; i++){                  // выводим p-й столбец
            System.out.print(ar[i][p]+", "); }
    }
    // 4. Сформировать квадратную матрицу порядка n по заданному образцу(n - четное):
    public static int[][] makeArN(int n){
        //ar = new int[n][n];
        int[][] ar = new int[n][n];
        for(int i=0; i<n; i++){
            if (i%2 == 0){ 
                for(int j=0; j<n; j++){
                 ar[i][j]=j+1;
                }                
            } else {
                for(int j=0; j<n; j++){
                    ar[i][j]=n-j;
                   }                
            }
        }
        return ar;
    }
    // 5. Сформировать квадратную матрицу порядка n по заданному образцу(n - четное):
    public static int[][] makeArN2(int n){
        int[][] ar = new int[n][n];
        for(int i=0; i<n; i++) {
            for(int j=0; j<n-i; j++){ ar[i][j]=i+1; }                
            for(int j=n-i; j<n; j++) { ar[i][j]=0;  }                
        }        
        return ar;
    }
    // 6. Сформировать квадратную матрицу порядка n по заданному образцу(n - четное):
    public static int[][] makeArN3(int n){
        int[][] ar = new int[n][n];
        int k=n/2;  
          for(int i=0; i<k; i++) {                                //формируем верхнюю половину матрицы
            for(int j=0; j<i; j++){ ar[i][j]=0; }                // при создании массива Java инициализирует его 0,так что можно и не заносить 0 )) 
            for(int j=i; j<n-i; j++){ ar[i][j]=1; }                
            for(int j=n-i; j<n; j++) { ar[i][j]=0;  }                
          }        
          for(int i=0; i<k; i++) {                                  //формируем нижнюю половину матрицы
            for(int j=0; j<k-i-1; j++) { ar[k+i][j]=0;  }                
            for(int j=k-i-1; j<k+i+1; j++){ ar[k+i][j]=1; }                
            for(int j=k+i+1; j<n; j++){ ar[k+i][j]=0; }             
          }   
        return ar;
    }
    // 7. Сформировать квадратную матрицу порядка N по правилу:   и подсчитать количество положительных элементов в ней.
    public static double[][] makeArN4(int n){    
        double[][] ar = new double[n][n];
        int pos=0;
        for(int i=0; i<n; i++) {
            for(int j=0; j<n; j++){ 
                ar[i][j]=Math.sin(i*i-j*j/n); 
                if (ar[i][j]>=0) pos++;
            }              
        }
        System.out.print("Кол. положит. значений = "+pos);
    return ar;      
    }
    // 8. В числовой матрице поменять местами два столбца любых столбца, т.е. все элементы одного столбца поставить на соответствующие им позиции другого, а его элементы второго переместить в первый.
    public static void changeCl(int[][] ar){
        int l_col=ar[0].length;
        int l_str=ar.length;
        int ch;
        Scanner in = new Scanner(System.in);
        System.out.print("Введите номер столбца - от 0 до "+(l_col-1)+" : ");
        int cl1=in.nextInt();
        System.out.print("Введите номер столбца - от 0 до "+(l_col-1)+" : ");
        int cl2=in.nextInt();
        for(int i=0; i<l_str; i++) {
            ch=ar[i][cl1];
            ar[i][cl1]=ar[i][cl2];
            ar[i][cl2]=ch;
            }  
        in.close();
    }
    // 9. Задана матрица неотрицательных чисел. Посчитать сумму элементов в каждом столбце. Определить, какой столбец содержит максимальную сумму.
    public static void colSum(int[][] ar) {
        int max=0;
        int cl=0;
        int l_col=ar[0].length;
        int l_str=ar.length;
        for(int i=0; i<l_col; i++) {
            int sum=0;
            for(int j=0; j<l_str; j++) sum+=ar[j][i];
            System.out.println("Сумма элементов столбца "+i+" равна: "+sum); 
            if (sum>max) {max=sum; cl=i;}
        }
        System.out.println("столбец содержащий максимальную сумму : "+cl);
    }    
    // 10. Найти положительные элементы главной диагонали квадратной матрицы.
    public static void positivElem(int[][] ar) {
        int l=ar[0].length;
        for(int i=0; i<l; i++){
            if (ar[i][i]>=0) System.out.print(ar[i][i]+" "); 
        }                  
    }
    // 11. Матрицу 10x20 заполнить случайными числами от 0 до 15. Вывести на экран саму матрицу и номера строк, в которых число 5 встречается три и более раз.
    public static void Ex11(){
        int ar[][]= matrixGen(10, 20, 0, 15);
        showAr(ar);
        int qt=0;
        System.out.print("\nСтроки, в которых число 5 встречается три и более раз : ");
        for(int i=0; i<10; i++){
            qt=0;
            for(int j=0; j<20; j++){
                if (ar[i][j]==5) qt++;
            }
            if (qt>=3) System.out.print(i+", ");
        }
    }
    // 12. Отсортировать строки матрицы по возрастанию и убыванию значений элементов.
    public static void sortMatrStr(int[][] ar){
        int l=ar.length;
        for(int i=0; i<l; i++){ sort(ar[i]); }   
        System.out.println("сортирвка строк по возрастанию");
        showAr(ar);
        for(int i=0; i<l; i++){ asort(ar[i]); }   
        System.out.println("сортирвка строк по убыванию");
        showAr(ar);
    }
    // 13. Отсотрировать стобцы матрицы по возрастанию и убыванию значений эементов
    public static void sortMatrCol(int[][] ar){         // сортировка по возрастанию элементов в столбце
        int l_col=ar[0].length;
        int l_str=ar.length;
        int min, index;
        for(int k=0; k<l_col; k++){
          for(int i=0; i<l_str; i++){
            min=ar[i][k]; index=i;
            for(int j=i+1; j<l_str; j++){
                if (ar[j][k]<min) { min=ar[j][k]; index=j;}
            }
            ar[index][k]=ar[i][k];
            ar[i][k]=min; 
          }
        } 
    }    
    public static void asortMatrCol(int[][] ar){          // сортировка по убыванию элементов в столбце
            int l_col=ar[0].length;
            int l_str=ar.length;
            int max, index;
            for(int k=0; k<l_col; k++){
              for(int i=0; i<l_str; i++){
                max=ar[i][k]; index=i;
                for(int j=i+1; j<l_str; j++){
                    if (ar[j][k]>max) { max=ar[j][k]; index=j;}
                }
                ar[index][k]=ar[i][k];
                ar[i][k]=max; 
              }
            }         
    }
    // 14. Сформировать случайную матрицу m x n, состоящую из нулей и единиц, причем в каждом столбце число единиц равно номеру столбца.
    public static int[][] matrixGen10(int m, int n){    
        int[][] ar=new int[m][n];                             // m-число строк, n - число столбцов
        int j, k, max;
        for(int i=0; i<n; i++){
            // for(k=0; k<m; k++) { ar[k][i]=0;}        //обнуляем столбец
            j=1; max=i+1;
            if (max>m) max=m;
            while (j<=max){
                k=(int) Math.floor(Math.random()*m);                
                if (ar[k][i]!=1) { 
                    ar[k][i]=1; 
                    j++; 
                }
            } 
        } 
        return ar;
    }
    //15. Найдите наибольший элемент матрицы и заменить все нечетные элементы на него.
    public static void replaceMax(int[][] ar){         // сортировка по возрастанию элементов в столбце
        int l_col=ar[0].length;
        int l_str=ar.length;
        int max=ar[0][0];
        for(int i=0; i<l_str; i++){             //находим максимальный элемент матрицы
            for(int j=0; j<l_col; j++){
                if (ar[i][j]>max) { max=ar[i][j];}
            }            
          }        
        for(int i=0; i<l_str; i++){             //заменяем каждый нечетный элемент на максимальный элемент матрицы
            for(int j=0; j<l_col; j++){
                if (ar[i][j]%2 !=0) { ar[i][j]=max;}
            }            
        }  
        System.out.print("Наибольший элемент матрицы : "+max);
    } 
}

/*
int[] ar11 = {25,6,85,65,7,21,35,99,5,25};
sort(ar11);
for(int i=0; i<ar11.length; i++){
    System.out.print(ar11[i]+", ");            
}
System.out.println();
asort(ar11);
for(int i=0; i<ar11.length; i++){
    System.out.print(ar11[i]+", ");            
}*/