import java.util.Arrays;

public class Algor1 {
    public static void main(String[] args) {

        double s; 
        int a,b,c, d;      

        System.out.println("\n Задача 1"); 
        a=51; b=34;
        System.out.println("Наибольший общий делитель чисел "+a+" и "+b+" равен "+nod(a,b));
        System.out.println("Наименьшее общее кратное чисел "+a+" и "+b+" равен "+nok(a,b));

        System.out.println("\n Задача 2"); 
        a=63; b=36; c=18; d=27;
        System.out.println("Наибольший общий делитель чисел "+a+" "+b+" "+c+" и "+d+" равен "+nod4(a,b,c,d));

        System.out.println("\n Задача 3");
        a=8;
        s=s6angle(a);
        System.out.println("Площадь правильного 6-угольника со стороной "+a+" равна: "+s);

        System.out.println("\n Задача 4");
        int[][] ar2, ar3 = {{0,0},{1,2},{2,2},{4,4}, {6,5}, {5,6}};
        ar2=maxDist(ar3);
        System.out.println(" Максимальное растояние между точками :");
        showAr(ar2[0]); 
        System.out.print(" и ");
        showAr(ar2[1]);

        System.out.println("\n Задача 5");
        int[] ar1={80, 56, 34, 74, 5, 46, 23, 19, 27};
        task5(ar1);

        System.out.println("\n Задача 6"); 
        a=25; b=13; c=41;
        task6(a, b, c);

        System.out.println("\n Задача 7");
        task7();
        
        System.out.println("\n Задача 8");
        task8();

        System.out.println("\n Задача 9");
        s=sQA(3,4, 8, 9);
        System.out.println("Площадь четырехугольника равна: "+s);

        System.out.println("\n Задача 10");
        a=356789;
        ar1=arDigit(a);
        System.out.print("Цифры числа "+a+" : ");
        showAr(ar1);

        System.out.println("\n Задача 11");
        a=759; b=1280;
        System.out.print(maxDigit(a,b));

        System.out.println("\n Задача 12");
        num12(25,1000);

        System.out.println("\n Задача 13");
        num13(20);

        System.out.println("\n Задача 14");
        num14(200);      

        System.out.println("\n Задача 15");
        numb15(4);

        System.out.println("\n Задача 16");
        sum16(753159);

        System.out.println("\n Задача 17");
        b=15;
        a=qt17(15);
        System.out.println("Число "+ b+", произведено "+a+" действий");  
    }

    public static void showAr(int[] ar){               //  вспомогательная функция для вывода массива целых чисел        
        // System.out.println();
        for (int Ai : ar) System.out.print(Ai+", "); 
    }
    public static double distXY(int x1, int y1, int x2, int y2){           //растояние между двумя точками
        double l= Math.pow(Math.abs(x2-x1), 2) + Math.pow(Math.abs(y2-y1), 2);
        return Math.sqrt(l);
    }
    public static int qtDigit(long x){                                        // количество цифр в числе 
        long y;
        int qt=1;        
        while (true){
            y=x/10;
            if (y>=1) { qt++; x=y;}
            else return qt;
        }        
    }
    public static int sumDigit(long x){                                        // сумма цифр в числе 
        long y;
        int sum=0;
        while (true){
            y=x/10;
            sum+=x%10;
            if (y>=1) { x=y;}
            else return sum;
        }        
    }    
    public static double sTreug(double a, double b, double c){         //Площадь треугльника   
        double p=(a+b+c)/2;
        double S=(p-a)*(p-b)*(p-c)*p;
        return Math.sqrt(S);
    }

//1. Написать метод(методы) для нахождения наибольшего общего делителя и наименьшего общего кратного двух натуральных чисел:
    public static int nod (int a, int b){
        int max=a, min=b, x;
        if (a<b) { max=b; min=a;}
        while(true){
            x=max%min;
            if (x==0) break;
            max=min; min=x;
        }
        return min;
    }
    public static int nok (int a, int b){
        return a*b/nod(a,b);
    }
//2. Написать метод(методы) для нахождения наибольшего общего делителя четырех натуральных чисел.
    public static int nod4 (int a, int b, int c, int d){
        int x=nod(nod(nod(a,b),c),d);
        return x;
    }
//3. Вычислить площадь правильного шестиугольника со стороной а, используя метод вычисления площади треугольника.
    public static double s6angle(double a){
        return 6*sTreug(a,a,a);   //для правильного 6-угольника радиус описанной окружности = стороне а
    } 
//4. На плоскости заданы своими координатами n точек. Написать метод(методы), определяющие, между какими из пар точек самое большое расстояние. Коорд. точек занести в массив.
    public static int[][] maxDist(int[][] ar){
        /*int ar[][] = new int[n][2];
        int qt=1000;
        for (int i=0; i<n; i++){                    // формируем массив из n точек
            ar[i][0]=(int) Math.random()*qt;
            ar[i][1]=(int) Math.random()*qt;
        }*/
        int n=ar.length;
        double dist, max=0;
        int[][] arMax = new int[2][2];
        for(int i=0;i<n-1;i++){
            for(int j=i+1;j<n;j++){
                dist=distXY(ar[i][0], ar[i][1], ar[j][0], ar[j][1]);
                if (dist>max) { 
                    max=dist;
                    arMax[0][0]=ar[i][0];arMax[0][1]=ar[i][1];
                    arMax[1][0]=ar[j][0];arMax[1][1]=ar[j][1];
                }
            }
        }
        return arMax;
    }
//5. Составить программу, которая в массиве A[N] находит второе по величине число (вывести на печать число,
//   которое меньше максимального элемента массива, но больше всех других элементов).
    public static void task5(int[] ar){
        int max2=0, max=ar[0], j=0;
        for (int i=1; i<ar.length; i++){                             // находим в массиве максимальное значение
            if (ar[i]>max) max=ar[i]; 
        }
        for (int i=0; i<ar.length; i++){                              // порверяем, не находится ли максим. значение в 0 позиции
            if (ar[i]==max) continue;
             else { max2=ar[i]; j=i; break; }
        }
        for (int i=j+1; i<ar.length; i++){
            if (ar[i]>max2 && ar[i]<max) max2=ar[i];            
        }
        System.out.println("Второе по величине число массива равно "+max2);

    }
//6. Написать метод(методы), проверяющий, являются ли данные три числа взаимно простыми.
    public static boolean task6(int a,int b,int c){
        int x=Math.abs(nod(a,b))+Math.abs(nod(a,c))+Math.abs(nod(b,c));
        if (x==3) {
            System.out.println("Числа "+a+" "+b+" "+c+" являются взаимно простыми");
            return true; 
        }
        System.out.println("Числа "+a+" "+b+" "+c+" не являются взаимно простыми");
        return false;
    }

// 7. Написать метод(методы) для вычисления суммы факториалов всех нечетных чисел от 1 до 9.
    public static int factor(int i, int n){
        if (i==n) return i;
         else return i*factor(i+1, n);
    }
    public static void task7(){
        for(int i=1; i<=9; i+=2){
        System.out.println("Факториал "+i+" равен "+ factor(1,i)); }
    }
// 8. Задан массив D. Определить следующие суммы: D[l] + D[2] + D[3]; D[3] + D[4] + D[5]; D[4] +D[5] +D[6].
//    Пояснение. Составить метод(методы) для вычисления суммы трех последовательно расположенных элементов массива с номерами от k до m.
    public static int sum3(int[] ar, int k){
        return ar[k]+ar[k+1]+ar[k+2];
    }
    public static void task8(){
        int[] ar = {5,15,23,88,57,63,38};
        System.out.println("Сумма 3 элеменов массива 1-3 равна "+sum3(ar,1));
        System.out.println("Сумма 3 элеменов массива 3-5 равна "+sum3(ar,3));
        System.out.println("Сумма 3 элеменов массива 4-6 равна "+sum3(ar,4));
    }

//9. Даны числа X, Y, Z, Т — длины сторон четырехугольника. Написать метод(методы) вычисления его S, если угол между сторонами длиной X и Y— прямой.
    public static double sQA(int x, int y, int z, int t){ 
        double d =Math.sqrt(x*x+y*y);                       //выч. диагональ противоположную прямому углу - имеем 2 треугольника
        return sTreug(x, y, d)+sTreug(z, t, d);
    }
// 10. Дано натуральное число N. Написать метод(методы) для формирования массива, элементами которого являются цифры числа N.
        public static int[] arDigit(long n){                                        // возвр. массив из цифр числа 
            long y; 
            int qt=qtDigit(n);
            int[] ar= new int[qt];
            int i=1;
            while (true){
                ar[qt-i]=(int) n%10;
                y=n/10;
                if (y>=1) { n=y;}
                else return ar;
                i++;
            }         
        }

//11. Написать метод(методы), определяющий, в каком из данных двух чисел больше цифр.
        public static String maxDigit(int a, int b){
            int q1=qtDigit(a);
            int q2=qtDigit(b);
            if (q1==q2) return "числа содержат одинаковое количесвто цифр - "+q1;
             else if (q1>q2) return "число "+a+" содержат большее количесвто цифр - "+q1; 
                   else return "число "+b+" содержат большее количесвто цифр - "+q2; 
            }
/*12. Даны натуральные числа К и N. Написать метод(методы) формирования массива А, элементами которого являются числа,
      сумма цифр которых равна К и которые не большее N.*/
        public static void num12(int k, int n){
        int sum, j=0;
        int[] ar = new int[n];
        for(int i=1; i<=n; i++){
            sum=sumDigit(i);
            if (sum==k){       
                ar[j]=i;
                j++;
                System.out.print(i+", ");}
        }
        ar=Arrays.copyOf(ar, j);
    }

//13. Два простых числа называются «близнецами», если они отличаются друг от друга на 2 (например, 41 и 43).
//Найти и напечатать все пары «близнецов» из отрезка [n,2n], где n - заданное натуральное число больше 2. Для решения задачи использовать декомпозицию.
        public static int twin(int n){
            return n+2;
        }
        public static void num13(int n){
            int tw, max=n*2;
            for(int i=n; i<=max-2; i++){
                tw=twin(i);
                System.out.print(i+"-"+tw+"; ");
            }
        }

//14. Натуральное число, в записи которого n цифр, называется числом Армстронга, если сумма его цифр, возведенная в степень n, равна самому числу. 
//Найти все числа Армстронга от 1 до k. Для решения задачи использовать декомпозицию.
        public static void num14(int k){
            long amsNum;
            int sum, qt;
            System.out.println("Числа Армстронга от 1 до "+k);
            for(int i=1; i<=k; i++){
                sum=sumDigit(i);
                qt=qtDigit(i);
                amsNum=(long) Math.pow(sum, qt);
                if (i==amsNum) System.out.print(i+", ");
            }
        }
//15. Найти все натуральные n-значные числа, цифры в которых образуют строго возрастающую последовательность (например, 1234, 5789). Для решения задачи использовать декомпозицию.
        public static void formI(int n, int i, byte j, byte[] ar){
            if (i==n-1){
                j++;
                for(byte k=j; k<=9; k++){
                    ar[i]=k; print(ar);
                }
            } else {
                j++; 
                for(byte k=j; k<=9; k++){
                    ar[i]=k; formI(n,i+1,k,ar);
                }
            }
    }
    public static void print(byte[] ar) {  // вывести полученное чисоло
        int l=ar.length;
        long num=0;
        for(int i=0; i<l; i++){
            num+=(long) (Math.pow(10,l-i-1)*ar[i]);                
        } 
        System.out.print(num+", ");
    }
    public static void numb15(int n){
        if (n>9) n=9;        
        byte[] ar = new byte[n];
        for (byte i=1; i<=9; i++){
            ar[0]=i;
            formI(n,1,i ,ar);
        }
} 
// 16. Написать программу, определяющую сумму n - значных чисел, содержащих только нечетные цифры. 
// Определить также, сколько четных цифр в найденной сумме. Для решения задачи использовать декомпозицию.
    public static void sum16(int a){
        int[] ar=arDigit(a);
        int sum=0, col=0;
        for(int i=0; i<ar.length; i++){
            if (ar[i]%2==0){ 
                System.out.print("Число содержит четные цифры"); return;
            }    
            sum+=ar[i];        
        }
        ar=arDigit(sum);
        for(int i=0; i<ar.length; i++){
            if (ar[i]%2==0) col++;     
        }
        System.out.println("Сумма нечетный цифр числа "+a+" ровна "+ sum+", в которой "+col+" четных чисел");
    }

// 17. Из заданного числа вычли сумму его цифр. Из результата вновь вычли сумму его цифр и т.д. Сколько таких действий надо произвести, 
//     чтобы получился нуль? Для решения задачи использовать декомпозицию.
    public static int qt17(int a){
        int col=0;
        while (a>0) {
            a-=sumDigit(a);
            col++;
        }
        return col;
    }
}