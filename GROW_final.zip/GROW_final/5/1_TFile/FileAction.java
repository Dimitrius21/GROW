/*
Создать объект класса Текстовый файл, используя классы Файл, Директория. 
Методы: создать, переименовать, вывести на консоль содержимое, дополнить, удалить.
*/

public class FileAction {
    TFile myFile;

    public static void delete(TFile file) {        
        file=null;
    }

    public static void main(String[] args) {
        new FileAction().go();
    }
    public void go() {
        myFile=TFile.createFile("Readme", "txt", "D:", "Example");
        myFile.printText();
        myFile.addText(" adition");
        myFile.printText();
        myFile.rename("D:", "Readme1.txt");
        System.out.println(myFile.getFullName());
        
    }
}
