/*
Создать объект класса Текстовый файл, используя классы Файл, Директория. 
Методы: создать, переименовать, вывести на консоль содержимое, дополнить, удалить.
*/

public class TFile {
    String str;
    File file;
    Path path;
    TFile(String name, String type, String path, String text){
        this.file = new File(name, type);
        this.path = new Path(path);
        str= new String(text);
        file.setSize(text.length());
    }
    public String getFullName() {
        return path.getPath()+"\\"+file.getFullName();        
    }
    //Добавить текст в "файл"
    public void addText(String t) {
        str+=t;
        file.setSize(str.length());
    }
    //Удалить содержимое файла
    public void clearText() {
        str="";
        file.setSize(0);
    }
    public String getText() {
        return str;        
    }
    //Вывести соержимое файла на экран
    public void printText(){
        System.out.println(str);
    }
    //Переименовать файл
    public void rename(String newPath, String newName) {
        String[] fn=newName.split("\\.");
        String type=fn[fn.length-1];
        int end=newName.length()-type.length()-1;
        String name=newName.substring(0, end);
        file.setName(name);
        file.setType(type);
        path.setPath(newPath);
    }
    //Создать новый файл
    public static TFile createFile(String name, String type, String path, String text) {
        return new TFile(name, type, path, text);                
    }
}

class File{
    private String name;
    private String type;
    private long size=0;
    private boolean writable=true;
    File(String name, String type){
        this.name=name;
        this.type=type;
    }
    public void setName(String newName){
        name=newName;
    }        
    public void setType(String newType){
        type=newType;
    }        
    public void setSize(long s){
        size=s;
    }
    public void setWritable(boolean w){
        writable=w;
    }
    public long getSize(){
        return size;
    }
    public String getName(){
        return name;
    }
    public String getType(){
        return name;
    }
    public String getFullName(){
        return name+'.'+type;
    }
}
class Path{
    String path;
    Path(String path){
        this.path=path;
    }
    public void setPath(String path){
           this.path=path;        
    }
    public String getPath(){
         return path;        
    }
}

