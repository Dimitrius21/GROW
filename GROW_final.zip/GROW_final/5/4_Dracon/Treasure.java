public class Treasure {
    String name;                                                //наименование сокровища
    int cost;                                                   //цена единицы сокровища
    int quantity;                                               //количество данного сокровища 
    int sum;                                                    //общая стоимость данного сокровища     
   //String description;                                          

    Treasure(String name, int quantity, int cost){
        this.name=name;
        this.quantity=quantity;
        this.cost=cost;        
        sum=cost;
    }
    public void setQuantity(int qt) {
        this.quantity=qt;
        sum=qt*cost;
    }   

    public int getTotalCost() {
        return sum;        
    }
    public int getCost() {
        return cost;        
    }
    public int getQt() {
        return quantity;        
    }
    public String getName() {
        return name;        
    }    
    public String toString () {
        return String.format("%s, количество - %d, цена за единицу - %d", name, quantity, cost);        
    }
    public String toSave () {
        return String.format("%s;%d;%d\n", name, quantity, cost);        
    }
    public static  Treasure createTreasure(String str) {
        int qt, cost;
        if (str.isEmpty()) return null;
        String[] fields=str.split(";");
        String name=fields[0];
        try {
            qt=Integer.parseInt(fields[1]);
            cost=Integer.parseInt(fields[2]);    
        } catch (Exception e) {
            return null;
        }
        return new Treasure(name, qt, cost);
    }
}
