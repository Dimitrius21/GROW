import java.io.*;
import java.util.*;


public class Cave {
    ArrayList<Treasure> treasures;
    private String fileName="data.scv";

    Cave(){
        Treasure tr;
        treasures=new ArrayList<Treasure>();
        File file = new File(fileName);
        if (file.exists()){                                 //Если существует файл, где храняться записи о "сокровищах"
            try {
                Scanner sc = new Scanner(file);             //читаем построчно файл
                while (sc.hasNext()){
                    String st=sc.nextLine();
                    tr=Treasure.createTreasure(st);         //создаем объект - "сокровище"  из полученной строки
                    if (tr!=null) treasures.add(tr);        //Добавляем "сокровище" в список
                }
                sc.close();
            } catch (Exception e) { 
                System.out.println("Ошибка чтения файла");                
                e.printStackTrace();            
            }           
        }
    }

    //Добавить сведения о сокровищах
    public void addTreasure () {
        Treasure treasure;
        String name;
        int qt, cost;
        name=Input.InpString("Введите название сокровища");                
        cost=Input.InpInt("Введите цену единицы сокровища");        
        qt=Input.InpInt("Введите количество сокровища");                
        treasure = new Treasure(name, qt, cost);                
        treasures.add(treasure);           
        if (saveData(treasure.toSave())) System.out.println("Данные о сокровище успешно сохранены");    
             else System.out.println("Ошибка сохранения данных");    ;                   
    }
        
    //Записать(добавить) данные о "сокровище" в файл
    public boolean saveData(String bk) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(fileName, true));    
            bw.write(bk);
            bw.close();
        } catch (Exception e) {
            e.printStackTrace();            
            return false;
        }       
        return true;
    }
    //Вывести на экран список всех сокровищ
    public void showAllTreasure() {
        if (treasures.isEmpty()) {System.out.println("Список сокровищ пуст"); return; }
        for(Treasure tr : treasures){
            System.out.println(tr.toString());
        }
    }
    public Treasure getMostExpensive() {
        if (treasures.isEmpty()) { System.out.println("Список сокровищ пуст"); return null; }
        Treasure tr=treasures.get(0);
        for (int i=1; i<treasures.size(); i++){
            if (tr.getCost()<treasures.get(i).getCost()) {
                tr=treasures.get(i);
            }
        }    
        System.out.println("Самое дорогое сокровище - "+tr.getName()+". Цена за единицу - "+tr.getCost());
        return tr;
    }

    public void myTreasures() {
        ArrayList<Treasure> myTreasures=new ArrayList<Treasure>();
        Treasure tr;
        int choise, choise2, sum, total=0;
        Input.InpStop("Выбор сокровищ на сумму. Нажмите ввод для продолжения");        
        int l=treasures.size();        
        String[] list = new String[l+1];
        ArrayList<Integer> chosenNum = new ArrayList<Integer>();        
        for (int i=0; i<l;i++){
            list[i]=(i+1)+" - "+treasures.get(i).getName()+". Цена единицы - "+treasures.get(i).getCost();
        }
        list[l]="Введите номер сокровища из списка, 0 - завершить выбор";
        while (true){               
            choise=Input.InpInt(list);            
            if (choise==0) break;
            choise--;
            if (choise>=0 && choise<l) {
                tr=treasures.get(choise);
                choise2=Input.InpInt("В наличии "+tr.getQt()+" единиц сокровища. Введите желаемое количество");
                if (choise2>0 && choise2<=tr.getQt()) {
                    myTreasures.add(tr);
                    sum=choise2*tr.getCost(); 
                    total+=sum;
                    chosenNum.add(choise2);
                    Input.InpStop("Выбрано сокровище "+ " на сумму "+sum+". Общая сумма выбранных сокровищ составляет "+total+". Нажмите ввод для продолжения");
                }else Input.InpStop("Введено невозможное количесвто, нажмите ввод для продолжения");
            }
        }
        System.out.println("Итого вами выбрано:");
        for(Treasure t : myTreasures) System.out.println(t.getName());
        Input.InpStop(" Общая сумма - "+total+". Нажмите ввод для продолжения");

    }

    public void go() {
        int choise;
        while(true){
            choise=Input.InpInt("Выберите действие:", "0 - Выйти из программы", "1 - Добавить сокровище", "2 - Просмотреть все сокровища", 
            "3 - Найти самое дорогое сокровище", "4 - Выбрать сокровища");
            switch (choise){
                case 0 : System.exit(0);
                case 1 : addTreasure(); break;
                case 2 : showAllTreasure(); break;
                case 3 : getMostExpensive(); break;
                case 4 : myTreasures(); break;
            }            
        }
    }
    public static void main(String[] args) {
        new Cave().go();
    }
}
