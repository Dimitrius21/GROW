import java.util.ArrayList;

public class Present {
    ArrayList<Sweets> sweets;                   //Список сладостей  
    Pack packing;                               //тип упаковки
    
    Present(){
        this.sweets = new ArrayList<Sweets>();    
    }
    //Добавление сладостей в подарок
    public void addSweets() {
        int choise;
        System.out.println("Выбор сладостей:");
        while(true){
            choise=Input.InpInt("Выберите действие:", "0 - Завершить добавление", "1 - Добавить шоколад", 
            "2 - Добавить конфеты", "3 - Добавить печенье");
            switch (choise){
                case 0 : return;              
                case 1 : sweets.add(Chocolate.create()); break;
                case 2 : sweets.add(Сandies.create()); break;                
                case 3 : sweets.add(Cookies.create()); break;                
            }            
        }
        
    }
    //Выбор типа упаковки
    public void addPack() {
        int choise;
        while (true) {
        System.out.println("Выберите тип упаковки:");
        String[] pack=Pack.typeOfPacking();
        for (int i=0; i<pack.length; i++){
            System.out.println((i+1)+" - "+pack[i]);
        }
        choise=Input.InpInt("Введите номер");
        packing=Pack.createPack(choise);
        if (packing!=null) break;
         else System.out.println("Введен неправильный номер");
        }
    }
    //Вывести на экран состав подарка
    public void showPresent() {
        System.out.println("Состав подарка:");
        System.out.println(" Сладости:");
        for (Sweets sw : sweets){
            System.out.println(" - "+sw.getData());
        }
        System.out.println(" Упаковка - "+packing.getPacking());   
    }
    //Создание подарка
    public void createPresent() {
        addSweets();
        addPack();
        
    }
    public void go() {
        int choise;
        while(true){
            choise=Input.InpInt("Выберите действие:", "0 - Выйти из программы", "1 - Просмотреть подарок", 
            "2 - Сформировать подарок");
            switch (choise){
                case 0 : System.exit(0);              
                case 1 : showPresent(); break;
                case 2 : createPresent();break;                
            }            
        }
    }
    public static void main(String[] args) {
        new Present().go();
    }
}
