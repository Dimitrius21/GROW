public class Pack {
    private static String[] descr = {"Картонная коробка", "Бумажный пакет", "Пластиковый пакет"};
    int type;
    
    Pack(int type){
        this.type=type;
    }
    public static String[] typeOfPacking() {
        return descr;        
    }

    public String getPacking() {
        return descr[type];
    }

    public static Pack createPack(int type) {
        if (type >0 && type <=descr.length) {
            return new Pack(type-1);
        } else return null;        
    }
}
