public class Cookies extends Sweets {
    private static String[] descr={"песочное","заварное","бисквитное"};
    int type;

    Cookies(int type, int weight){
        super("Печенье", descr[type], weight);
        this.type=type;        
    }

    public static Cookies create() {
        System.out.println("Выберите тип печенья:");
        int type=Sweets.types(descr)-1;
        int weight=Input.InpInt("Введите необходимый вес печенья, грамм.");
        return new Cookies(type, weight);
    }    
}