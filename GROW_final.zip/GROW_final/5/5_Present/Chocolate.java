public class Chocolate extends Sweets{
    private static String[] descr={"горький","молочный","белый"};    
    int type;
    private static int weigtPerOne=100;
    int quantity;

    Chocolate(int type, int weight){
        super("Шоколад", descr[type], weight);
        quantity=weight/weigtPerOne;
        this.type=type;        
    }

    public String getData() {
        return String.format("%s %s, количество - %d, (общий вес - %d)", name, description, quantity, weight);    
    }

    public String toString() {
        return String.format("Шоколад %s, название - %s. %s", descr[type], getName(), getData());        
    }
    public static Chocolate create() {
        System.out.println("Выберите тип шоколада:");
        int type=Sweets.types(descr)-1;
        int quantity=Input.InpInt("Введите количество шоколадок, шт. Одна шоколадка - "+weigtPerOne+"г.");
        return new Chocolate(type, quantity*weigtPerOne);
    }

}
