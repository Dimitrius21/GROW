public class Sweets {
    String name;                        //Название сладости  -шоколад, конфеты, печенье
    String description;                 // описание типа сладости
    //double cost;
    int weight;                         //вес

    Sweets(String name, String descr, int weight){
        this.name=name;       
        this.description=descr;
        this.weight=weight;
    }

    public String getName() {
        return name;        
    }
    public String getData() {
        return String.format("%s %s, вес - %d", name, description, weight);    
    }

    public static int types(String[] descr) {        
        int choise;
        for (int i=0; i<descr.length; i++){
            System.out.println((i+1)+" - "+descr[i]);
        }
        choise=Input.InpInt("Введите номер");      
        while (true)
        if (choise >0 && choise <=descr.length) {
            return choise;
        } 
        else System.out.println("Введен неправильный номер");
    }
    public int inpQuantity(String st) {        
        int choise;        
        choise=Input.InpInt("Введите "+st);                      
            return choise;
    }
}
