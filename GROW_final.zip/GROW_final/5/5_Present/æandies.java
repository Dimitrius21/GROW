public class Сandies extends Sweets {
    private static String[] descr={"Шоколадные","Карамель","Леденцы"};
    int type;
        
    Сandies(int type, int weight){
        super("Конфеты", descr[type], weight);
        this.type=type;        
    }


    public static Сandies create() {
        System.out.println("Выберите тип конфет:");
        int type=Sweets.types(descr)-1;
        int weight=Input.InpInt("Введите необходимый вес конфет, грамм.");
        return new Сandies(type, weight);
    }    
}
