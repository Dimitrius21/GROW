// Задача 2. Создать класс Payment с внутренним классом, с помощью объектов которого можно сформировать покупку из нескольких товаров.
import java.util.ArrayList;

public class Payment {
    private ArrayList<Goods> gds = new ArrayList<Goods>();

    public void addGoods(String description, Double price, int qt){
        Goods item = new Goods(description, price, qt);
        gds.add(item);
    }
    public Double getOrederSum(){
        Double totalSum=0.0;
        for(Goods it : gds){
            totalSum+=it.getSum();            
        }
        return totalSum;
    }
    public void printAllGoods(){
        for(Goods it : gds){
            System.out.println(it.getGoods());
        }
    }

        class Goods{
            Double price;
            int quantity;
            String description;
            public Goods(String description, Double price, int qt){
                this.price=price;
                this.description = description;
                this.quantity=qt;
            }
            public Double getPrice(){
                return price;
            }
            public Double getSum(){
                return price*quantity;
            }
            public String getGoods(){                
                return "Goods - "+description+" , prise: "+price+", sum = "+getSum();
            }
        }
        
    public static void main(String[] args) {        
    Payment p = new Payment();
    p.addGoods("Oil filter", 30.0, 1);
    p.addGoods("Fuel filter", 40.0, 1);
    p.addGoods("Oil", 30.0, 4);
    p.addGoods("Air filter", 35.0, 1);

    p.printAllGoods();
    System.out.println("Total sum of purchasing = "+p.getOrederSum());
    }

}
