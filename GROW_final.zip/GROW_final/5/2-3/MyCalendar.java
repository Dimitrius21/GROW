// Задача 3. Создать класс Календарь с внутренним классом, с помощью объектов которого можно хранить информацию о выходных и праздничных днях.
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class MyCalendar {
    private ArrayList<DayOff> dayDescription = new ArrayList<DayOff>();

    public void addDateDescripton(String date, String description){
        DayOff item = new DayOff(date, description);
        dayDescription.add(item);
    }

    public String getTodayDate(){
        Date today= new Date();
        String date=today.toString();
        String[] daypart = date.split(" ");        
        return "Today is "+daypart[2]+" "+daypart[1]+" "+daypart[5];
    }
    public void printAllDescription(){
        for( DayOff day : dayDescription){
            System.out.println(day.getDescription());
        }
    }

        class DayOff{
            String date;
            String description;
            public DayOff(String date, String description){
                this.date=date;
                this.description = description;                
            }
            public String getDescription(){
                return date+" - "+description;
            }            
        }
        
    public static void main(String[] args) {        
    MyCalendar calendar = new MyCalendar();
    calendar.addDateDescripton ("January 1", "New Year");
    calendar.addDateDescripton ("March 8 ", "Womans Day");
    calendar.addDateDescripton ("May 1", "Labour Day");  
    calendar.addDateDescripton ("May 9", "Victory Day");  

    
    System.out.println(calendar.getTodayDate());
    System.out.println("Hollidays: ");
    calendar.printAllDescription();
    }

}
